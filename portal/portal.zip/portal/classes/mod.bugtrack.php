<?php
if( !defined("IN_PORTAL") )
	die("Hacking attempt.");

// Set these to the value in phpbb_forums.forum_id for your server, content, tools bugs forums
define("SERVER_BUG_FORUM_ID", "13");
define("CONTENT_BUG_FORUM_ID", "23");
define("TOOLS_BUG_FORUM_ID", "76");
// Default server ID to display bugs
define("DEFAULT_SERVER_ID", "1"); // eq2emulator public server


/**
 * TODO: 
 *		Cache phpBB3 Users - it's hitting the DB a billion times
 *		
 */

class MODBugs {
	
	// public properties
	
	// private properties
	private $ModuleTitle = "EQ2 Bug Tracker";
	private $Filters	= array();
	private $Servers	= array('EQ2Emulator','Other'); // if we do a Hub, we'll read these from the database instead
	private $Category	= array();
	private $System		= array();
	private $Status 	= array('New','Invalid','Fixed','Server Specific','Assigned','Duplicate','Closed','Need Info','Not Implemented','Deleted','Not a Bug','Cannot Reproduce','By Design','Fixed in Dev','Unresolved'); // unresolved = all open
	private $Priority 	= array();
	private $Severity 	= array(1=>'Blocker',2=>'Exploit',3=>'Standard',4=>'Minor',5=>'Cosmetic');
	private $Reproduce	= array(1=>'Always',2=>'Sometimes',3=>'Once');
	private $Age		= array(1=>'1 Day',7=>'7 Days',14=>'2 Weeks',30=>'1 Month',90=>'3 Months',180=>'6 Months',360=>'1 Year',720=>'2 Years');
	private $Type		= array('Server Bug'=>SERVER_BUG_FORUM_ID,'Content Bug'=>CONTENT_BUG_FORUM_ID,'Tools Bug'=>TOOLS_BUG_FORUM_ID);
	private $TypeByID	= array('Server Bug','Content Bug','Tools Bug');
	private $Limit		= array(25,50,100,250,500,1000); // set Results per Page limit options
	private $BugData 	= array();
	private $UnresolvedStatuses = "'New','Fixed','Assigned','Need Info','Fixed in Dev'"; // edit this to select what Status is considered "Unresolved" for filters
	private $SchemaMap	= array(); // maps app fields to database fields for custom schemas
	//
	// Constructor
	//
	public function __construct() {
		global $MOD;

		$this->is_admin = $MOD->is_admin;
		$this->is_dev 	= $MOD->is_dev;
		$this->is_team 	= $MOD->is_team;

		// alternate DB creds -- not sure I want to do this unless I replicate RunQuery locally?
		$this->db_host = $_SESSION['modules']['database'][1]['db_host'];
		$this->db_user = $_SESSION['modules']['database'][1]['db_user'];
		$this->db_pass = $_SESSION['modules']['database'][1]['db_pass'];
		$this->db_name = $_SESSION['modules']['database'][1]['db_name'];
		$this->db_port = $_SESSION['modules']['database'][1]['db_port'];
		
		//printf('%s, %s, %s, %s, %s', $this->db_host, $this->db_user, $this->db_pass, $this->db_name, $this->db_port);
		include_once("mysql.class.php");
		$this->db = new MODMysql($this->db_host, $this->db_user, $this->db_pass, $this->db_name, false);

		// see notes in Schema class below
		$this->SchemaMap = new Schema();
		
		// sets up category/system pickers
		$this->InitCategories();
		
		$this->Category 	= $this->GetCategories(); //$MOD->GetEnum('eveportal', 'project_manager', 'pm_category');
		//$this->System		= $this->GetSystems();
		$this->Assignee		= $MOD->GetAssignee();
		$this->Priority		= $this->SetPriorityArrayData();
		$this->Servers		= $this->GetServers();
		$this->BugID		= ( strlen($_GET['id']) > 0 ) ? intval($_GET['id']) : 0;
		$this->BugAdd		= ( strlen($_GET['add']) > 0 ) ? true : false;
		$this->Container();	// this draws the container for Bugs
	}


	// why is this not in common?
	private function LookupForumUser($id) {
		global $MOD;
		
		if( $id == 0 )
			return "Unassigned";
			
		$MOD->SQLQuery = sprintf("SELECT username FROM " . $MOD->PHPBBTablePrefix. "users WHERE user_id = %s", $id);
		$data = $MOD->RunQuerySingle();
		
		return ( count($data) > 0 ) ? $data['username'] : "Unassigned";
	}	


	private function SetPriorityArrayData() {
		return array(
					 
					  0=>array(
							   'text'=>'Not Set',
							   'color'=>'#333',
							   'icon'=>'<img src="/portal/images/icons/unknown.png" />'
							   ),
					  1=>array(
							   'text'=>'Low',
							   'color'=>'#0c0',
							   'icon'=>'<img src="/portal/images/icons/low.png" />'
							   ),
					  2=>array(
							   'text'=>'Medium',
							   'color'=>'#cc0',
							   'icon'=>'<img src="/portal/images/icons/medium.png" />'
							   ),
					  3=>array(
							   'text'=>'High',
							   'color'=>'#c00',
							   'icon'=>'<img src="/portal/images/icons/high.png" />'
							   ),
					  4=>array(
							   'text'=>'Critical',
							   'color'=>'#909',
							   'icon'=>'<img src="/portal/images/icons/critical.png" />'
							   ),
					  5=>array(
							   'text'=>'Immediate',
							   'color'=>'#c0c',
							   'icon'=>'<img src="/portal/images/icons/immediate.png" />'
							   )
					  );
	}


	private function InitCategories() {
		$this->CatArray = array('Gameplay'=>'coming soon');
	}


	private function CategoryOptions() {
		global $MOD;
		if( count($this->Category) == 0 )
			$this->Category = $this->GetCategories();
		foreach($this->Category as $option) {
			printf("<option%s>%s</option>", ( $option === $this->Filters['category'] ) ? " selected" : "", $option);
		}
	}


	/*private function SystemOptions() {
		if( count($this->System) == 0 )
			$this->System = $this->GetSystems();
		foreach($this->System as $option) {
			printf("<option%s>%s</option>", ( $option['pm_system'] === $this->Filters['system'] ) ? " selected" : "", $option['pm_system']);
		}
	}*/


	/**
	 * This function is specific to Filters Assignee; need another one for Bug Assignee :/
	 */
	private function AssigneeOptions() {
		global $MOD; 
		if( count($this->Assignee) == 0 )
			$this->Assignee = $MOD->GetAssignee();
		foreach($this->Assignee as $option) {
			printf("<option%s>%s</option>", ( $option === $this->Filters['assignee'] ) ? " selected" : "", $option);
		}
	}


	/**
	 * This function is specific to Filters Assignee; need another one for Bug Assignee :/
	 */
	private function BugAssigneeOptions( $assigned_to ) {
		global $MOD;
			
		foreach($MOD->GetAssigneeIDList() as $key=>$val) {
			printf('<option value="%s"%s>%s</option>', $key, ( $key === $assigned_to ) ? " selected" : "", $val);
		}
	}


	private function GetCategories() {
		if( is_array($this->CatArray) ) {
			foreach( $this->CatArray as $cat=>$sys ) {
				if( is_array($sys) ) {
					foreach($sys as $system)
						$ret[] = sprintf("%s::%s", $cat, $system);
				}
			}
		}
		return $ret;
	}
	
	
	private function GetServers() {
		global $MOD;
		$this->SQLQuery = "SELECT DISTINCT s.id, s.name FROM " . LOGIN_DATABASE . ".login_worldservers s JOIN " . LOGIN_DATABASE . ".bugs b ON s.id = b.world_id WHERE b.world_id <> 100 ORDER BY s.name";
		return $this->RunQueryMulti();
	}


	/*private function GetSystems() {
		global $MOD;
		$MOD->SQLQuery = "SELECT DISTINCT CONCAT(pm_system, '::', pm_subsystem) AS pm_system FROM " . PORTAL_DATABASE . ".project_manager ORDER BY pm_system, pm_subsystem";
		return $MOD->RunQueryMulti();
	}*/


	private function GetBugText($id) {
		global $MOD;
		$MOD->SQLQuery = sprintf("SELECT `".$this->SchemaMap->bugs['Summary']."` AS summary FROM " . LOGIN_DATABASE . ".bugs WHERE `".$this->SchemaMap->bugs['BugID']."` = %s", $id);
		$result = $MOD->RunQuerySingle();
		return ( strlen($result['summary']) > 0 ) ? $result['summary'] : "Unknown";
	}



	/****************************************************************************
	 * Container UI Functions
	 ****************************************************************************/

	/*
	 * 2017 Bug Tracker Module now has a container to wrap the content in for easier (re)styling -- in theory
	 * This 'container' should be used by all portal modules - if it works out, maybe make it global?
	 */
	private function Container() {
		global $MOD;

		if( $this->BugID > 0 ) {	// update/delete here
			?>
			
			<ul>
				<li class="title">
					<img src="<?php print( PORTAL_RELATIVE_PATH ) ?>images/icons/edit.png" border="0" />
					<?php print( $this->ModuleTitle ) ?> - Details
					<button class="mod-instruct" onclick="goBack()">Back</button>
				</li>
			</ul>
			<?php 
			$this->Detail();
			
		} elseif( $this->BugAdd ) {	// insert here
		
			$this->Add();
			
		} else {					// results here
		
			?>
			<ul>
				<li class="title">
					<img src="<?php print( PORTAL_RELATIVE_PATH ) ?>images/icons/unknown.png" border="0" />
					<?php print( $this->ModuleTitle ) ?>
				</li>
			</ul>
			<div class="post bg1">
				<div class="inner">
				<?php $this->Filters(); ?>
				</div>
			</div>
			<?php 
			$this->GetFilteredData(); // get master bug list
			$this->Results(); 

		}
	}


	/*
	 * Filter results
	 */
	private function Filters() {
$this->Search();
?>
				<script language="javascript">
				<!--
				function goNew() {
					window.open('./index.php?p=bugs&add=new#content', target='_self');
				}
				-->
				</script>
<?php /*?>might want to figure out how to DIV this so it stays responsive<?php */?>
				<!-- <table width="100%" border="0" cellspacing="0">
<tr height="30">
						<td class="mod-instruct">Click ID or Summary link to see details of an entry. To add a new bug, click &quot;Add New&quot;.</td>
						<td width="20%" align="right"><button class="mod-instruct" onclick="goNew()">Add New</button></td>
					</tr>
				</table> -->
<?php
	}


	/*
	 * Show results of Filtered search
	 * Or, results of Bugs By Account
	 */
	private function Results() {
		
		if( is_array($this->BugData) ) {
			// build type blocks
			// 		then build rows
			$Type = NULL;
			$TypeCount = 0; // for new document
			$SysCount = 0; // for new section
			$this->row_count = 0;
			foreach($this->BugData as $bug) {

				if( $Type != $bug[$this->SchemaMap->bugs['BugType']] ) {
					$Type = $bug[$this->SchemaMap->bugs['BugType']];
					if( $TypeCount > 0 )
						$this->EndType();
					$this->StartType($this->TypeByID[$Type]);
					$TypeCount++;
					$this->row_count = 0;// section total for styling
				}
				
				$this->AddBugRow($bug);
				
				$this->row_count++; // section total for styling
				$this->total_count++; // page total
			} // end foreach
			$this->FinalType(); // last Type to close, print footer
		} 
		$this->GridFooter();
		
	}
	

	/****************************************************************************
	 * Search UI Functions
	 ****************************************************************************/

	public function SetFilters() {
		unset($_SESSION['modules']['filters']['bugtrack']);
		$_SESSION['modules']['filters']['bugtrack']['server']	= $_POST['server-filter'];
		$_SESSION['modules']['filters']['bugtrack']['category']	= $_POST['category-filter'];
		$_SESSION['modules']['filters']['bugtrack']['status']	= $_POST['status-filter'];
		$_SESSION['modules']['filters']['bugtrack']['assignee'] = $_POST['assignee-filter'];
		$_SESSION['modules']['filters']['bugtrack']['text'] 	= $_POST['text-filter'];
		
		$_SESSION['modules']['filters']['bugtrack']['age']		= $_POST['age-filter'];
		$_SESSION['modules']['filters']['bugtrack']['type']		= $_POST['type-filter'];
		$_SESSION['modules']['filters']['bugtrack']['priority']	= $_POST['priority-filter'];
		$_SESSION['modules']['filters']['bugtrack']['limit']	= $_POST['limit-filter'];
	}
	
	public function GetFilters() {
		// if there are no filters set, set some default ones
		if( count($_SESSION['modules']['filters']['bugtrack']) == 0 ) {
			$this->Filters['server'] 	= DEFAULT_SERVER_ID;
			$this->Filters['status'] 	= "Unresolved";
			$this->Filters['age'] 		= ""; // unresolved, for all time
			$this->Filters['limit']		= $_SESSION['modules']['config']['max_grid_rows'];
		} else {
			$this->Filters['server'] 	= $_SESSION['modules']['filters']['bugtrack']['server'];
			$this->Filters['category'] 	= $_SESSION['modules']['filters']['bugtrack']['category'];
			$this->Filters['status'] 	= $_SESSION['modules']['filters']['bugtrack']['status'];
			$this->Filters['assignee'] 	= $_SESSION['modules']['filters']['bugtrack']['assignee'];
			$this->Filters['text']		= $_SESSION['modules']['filters']['bugtrack']['text'];
			
			$this->Filters['age'] 		= $_SESSION['modules']['filters']['bugtrack']['age'];
			$this->Filters['type'] 		= $_SESSION['modules']['filters']['bugtrack']['type'];
			$this->Filters['priority'] 	= $_SESSION['modules']['filters']['bugtrack']['priority'];
			$this->Filters['limit'] 	= $_SESSION['modules']['filters']['bugtrack']['limit'];
		}
	}

	public function ClearFilters() {
		$_SESSION['modules']['filters']['bugtrack'] = null;
	}

	public function Search() {
		global $MOD;
		
		if( $_POST['cmd'] == "Filter" ) {
			$this->SetFilters();
		} elseif( $_POST['cmd'] == "Default" ) {
			$this->ClearFilters();
		}

		$this->GetFilters();
		
		/*if( count($_SESSION['modules']['filters']['bugtrack']) > 0 ) {
			$filter_display = '';
			$filter_active = true;
		} else {
			$filter_display = 'style="display:none;"';
			$filter_active = false;
		}*/
		
		// This starts immediately after the header tag: <div id="page-body" role="main">, 
		// and is display: none until shown
		?>
<div class="panel" id="search_panel"<?php // print( $filter_display ) ?>>
	<h2 class="solo">Filter Bugs
		<?php ( $filter_active ) ? print('<span class="alert-text">*</style>') : NULL ?>
	</h2>
	<form method="post" id="search_memberlist">
		<div class="panel">
			<div class="inner">
				<p>Use this form to filter bug entries. If no filters are selected, default filters will be applied to show the most recent, open, unassigned bugs.</p>
				<fieldset class="fields1 column1">
					<dl style="overflow: visible;">
						<dt>
							<label>Server</label>
						</dt>
						<dd>
							<div class="dropdown-container dropdown-right">
								<select name="server-filter" style="width:200px;">
									<option value="">All Servers</option>
									<?php
											foreach($this->Servers as $option)
												printf("<option value='%s'%s>%s</option>", 
													$option['id'], 
													( $option['id'] === $this->Filters['server'] ) ? " selected" : "", 
													$option['name']);
											?>
								</select>
							</div>
						</dd>
					</dl>
					<dl>
						<dt>
							<label>Category</label>
						</dt>
						<dd>
							<select name="category-filter" style="width:200px;">
								<option value="">All Categories</option>
								<?php 
											$this->CategoryOptions(); 
										?>
							</select>
						</dd>
					</dl>
					<!--<dl>
								<dt>
									<label>System::Subsystem</label>
								</dt>
								<dd>
									<select name="system-filter" style="width:200px;">
										<option value="">Select System</option>
										<?php 
											//$this->SystemOptions(); 
										?>
									</select>
								</dd>
							</dl>-->
					<dl>
						<dt>
							<label>Status</label>
						</dt>
						<dd>
							<select name="status-filter" style="width:120px;">
								<option value="">All Statuses</option>
								<?php 
										foreach($this->Status as $option)
											printf("<option%s>%s</option>", ( $option === $this->Filters['status'] ) ? " selected" : "", $option);
										?>
							</select>
						</dd>
					</dl>
					<dl>
						<dt>
							<label>Assignee</label>
						</dt>
						<dd>
							<select name="assignee-filter" style="width:200px;">
								<option value="">All Assignees</option>
								<?php
										$this->AssigneeOptions(); 
										?>
							</select>
						</dd>
					</dl>
					<dl>
						<dt>
							<label>Text</label>
						</dt>
						<dd>
							<input class="inputbox" name="text-filter" value="<?php print( $this->Filters['text'] ) ?>" type="text">
						</dd>
					</dl>
				</fieldset>
				<fieldset class="fields1 column2">
					<dl>
						<dt>
							<label>Age</label>
						</dt>
						<dd>
							<select name="age-filter" style="width:120px;">
								<option value="">All Ages</option>
								<?php
										foreach($this->Age as $key=>$option)
											printf('<option value="%s"%s>%s</option>', $key, ( $key == $this->Filters['age'] ) ? " selected" : "", $option);
										?>
							</select>
						</dd>
					</dl>
					<dl>
						<dt>
							<label>Type</label>
						</dt>
						<dd>
							<select name="type-filter" style="width:120px;">
								<option value="">All Types</option>
								<?php
										foreach($this->Type as $type=>$key)
											printf('<option value="%s"%s>%s</option>', $key, ( $key == $this->Filters['type'] ) ? " selected" : "", $type);
										?>
							</select>
						</dd>
					</dl>
					<dl>
						<dt>
							<label>Priority</label>
						</dt>
						<dd>
							<select name="priority-filter" style="width:120px;">
							<?php
							printf('<option value=""%s>All Priorities</option>', 
								( strlen($this->Filters['priority']) == 0 ) ? " selected":"");
							foreach($this->Priority as $key=>$val)
								printf('<option value="%s"%s>%s</option>', 
									$key, 
									( isset($this->Filters['priority']) && $key == $this->Filters['priority'] ) ? " selected" : "", 
									$val['text']);?>
							</select>
						</dd>
					</dl>
					<!--<dl>
								<dt>
									<label>Severity</label>
								</dt>
								<dd>
									<select name="severity-filter" style="width:120px;">
										<option value="">Select Severity</option>
										<?php
										//foreach($this->Severity as $key=>$val)
										//	printf('<option value="%s"%s>%s</option>', $key, ( $key == $this->Filters['severity'] ) ? " selected" : "", $val);
										?>
									</select>
								</dd>
							</dl>-->
					<dl>
						<dt>
							<label>Max Results</label>
						</dt>
						<dd>
							<select name="limit-filter" style="width:70px;">
								<option value="0">--</option>
								<?php
										foreach($this->Limit as $option)
											printf('<option%s>%s</option>', ( $option == $this->Filters['limit'] ) ? " selected" : "", $option);
										?>
							</select>
						</dd>
					</dl>
				</fieldset>
				<div class="clear"></div>
				<hr>
				<fieldset class="submit-buttons">
					<input name="cmd" value="Filter" class="button1" type="submit" tabindex="0">
					&nbsp;
					<input value="Default" name="cmd" class="button2" type="submit" tabindex="1">
				</fieldset>
			</div>
		</div>
	</form>
</div>
<a name="content" id="content"></a>
<!-- <h2 class="solo">Bug Tracker</h2> -->
<!-- <div class="action-bar top">
	<div class="member-search panel"> <a id="searchbox" href="#"><strong> Click to toggle Filters panel.</strong></a></div>
	<div class="pagination">&nbsp;</div>
</div> -->
<?php 
	}
	
	
	private function GetFilteredData() {
		global $user;
		
		// fetch (filtered) data
		$select = "SELECT *, UNIX_TIMESTAMP(".$this->SchemaMap->bugs['BugCreated'].") AS bug_created FROM " . LOGIN_DATABASE . ".bugs WHERE ".$this->SchemaMap->bugs['BugID']." > 0"; // bogus clause in case we have no ANDs below

		// column 1 filters
		if( strlen($this->Filters['server']) > 0 )
			$where .= "(".$this->SchemaMap->bugs['ServerID']." = '".$this->Filters['server']."')";
		if( strlen($this->Filters['category']) > 0 )
			$where .= "(".$this->SchemaMap->bugs['Category']." = '".$this->Filters['category']."')";
		//if( strlen($this->Filters['system']) > 0 )
		//	$where .= "(bug_system = '".$this->Filters['system']."')";
		//if( strlen($this->Filters['reporter']) > 0 )
		//	$where .= "((account_name = '".$this->Filters['reporter']."') OR (char_name = '".$this->Filters['reporter']."'))";
		if( strlen($this->Filters['assignee']) > 0 ) {
			if( $this->Filters['assignee'] == "Me" ) {
				$where .= "(".$this->SchemaMap->bugs['AssignedTo']." = '".$user->data['user_id']."')";
			} else {
				$where .= "(".$this->SchemaMap->bugs['AssignedTo']." = '".$this->Filters['assignee']."')";
			}
		}
		if( strlen($this->Filters['text']) > 0 )
			$where .= "((".$this->SchemaMap->bugs['Category']." RLIKE '".$this->Filters['text']."') OR " .
					   "(".$this->SchemaMap->bugs['Subcategory']." RLIKE '".$this->Filters['text']."') OR " .
					   "(".$this->SchemaMap->bugs['Summary']." RLIKE '".$this->Filters['text']."') OR " .
					   "(".$this->SchemaMap->bugs['Description']." RLIKE '".$this->Filters['text']."'))";
		
		// column 2 filters
		if( strlen($this->Filters['type']) > 0 )
			$where .= "(".$this->SchemaMap->bugs['BugType']." = '".$this->Filters['type']."')";
		if( intval($this->Filters['age']) > 0 ) {
			$timebase = 86400; // 1 day
			$timediff = time() - ($timebase * $this->Filters['age']);
			$where .= "(UNIX_TIMESTAMP(".$this->SchemaMap->bugs['BugCreated'].") >= '".$timediff."')";
		}
		if( strlen($this->Filters['status']) > 0 ) {
			if( $this->Filters['status'] == "All Statuses" ) {
				// do not set a bug_status filter
			} elseif( $this->Filters['status'] == "Unresolved" ) {
				$where .= "(".$this->SchemaMap->bugs['Status']." IN (".$this->UnresolvedStatuses."))";
			} else {
				$where .= "(".$this->SchemaMap->bugs['Status']." = '".$this->Filters['status']."')";
			}
		}
		if( intval($this->Filters['priority']) > 0 )
			$where .= "(".$this->SchemaMap->bugs['Priority']." = '".$this->Filters['priority']."')";
		//if( intval($this->Filters['severity']) > 0 )
		//	$where .= "(bug_severity = '".$this->Filters['severity']."')";
			
		$order_by = " ORDER BY ".$this->SchemaMap->bugs['BugType'].", " .
					"UNIX_TIMESTAMP(".$this->SchemaMap->bugs['BugCreated'].") DESC, " .
					$this->SchemaMap->bugs['Priority']." DESC";
					
		$limit = ( intval($this->Filters['limit']) == 0 ) ? sprintf(" LIMIT 0,%s", intval($_SESSION['modules']['config']['max_grid_rows'])) : sprintf(" LIMIT 0,%s", $this->Filters['limit']);
		
		
		// temp for dev debugging
		//$group_by = " GROUP BY " . $this->SchemaMap->bugs['BugType'] . ", " . $this->SchemaMap->bugs['Status'];
		
		
		
		if( strlen($where) > 0 ) {
			$this->SQLQuery = $select . " AND " . preg_replace("/\)\(/", ") AND (", $where) . $group_by . $order_by . $limit;
		} else {
			$this->SQLQuery = $select . $group_by . $order_by . $limit;
		}

		// different sql connection, use local $this->db
		$this->BugData = $this->RunQueryMulti();
	}


	private function GetBugsByAccount($account_id) {
		// exclude the current BugID
		$this->SQLQuery = "SELECT *, UNIX_TIMESTAMP(".$this->SchemaMap->bugs['BugCreated'].") AS bug_created FROM " . LOGIN_DATABASE . ".bugs WHERE ".$this->SchemaMap->bugs['AccountID']." = ".$account_id." AND ".$this->SchemaMap->bugs['BugID']." <> ".$this->BugID;
		$this->BugData = $this->RunQueryMulti();
	}
	
	
	public function Screen() {
		
		$this->GetFilteredData();
		
		?>
		<script language="javascript">
				<!--
				function goNew() {
					window.open('./index.php?p=bugs&add=new#content', target='_self');
				}
				-->
				</script>
		<table width="100%" border="0" cellspacing="0">
			<tr height="30">
				<td class="mod-instruct">Click ID or Summary link to see details of an entry. To add a new bug, click &quot;Add New&quot;.</td>
				<td width="20%" align="right"><button class="mod-instruct" onclick="goNew()">Add New</button></td>
			</tr>
		</table>
		<br />
		<?php /*?>leaving class=diffuse in here since I may want to use it eventually<?php */?>
		<div class="panel diffuse">
			<div class="inner">
				<div style="width: 100%;">
					<!-- build list here -->
					<?php
					if( is_array($this->BugData) ) {
						
						// build type blocks
						// 		then build rows
						$Type = NULL;
						$TypeCount = 0; // for new document
						$SysCount = 0; // for new section
						$this->row_count = 0;
						foreach($this->BugData as $bug) {

							if( $Type != $bug[$this->SchemaMap->bugs['BugType']] ) {
								$Type = $bug[$this->SchemaMap->bugs['BugType']];
								if( $TypeCount > 0 )
									$this->EndType();
								$this->StartType($this->TypeByID[$Type]);
								$TypeCount++;
								$this->row_count = 0;// section total for styling
							}
							
							$this->AddBugRow($bug);
							
							$this->row_count++; // section total for styling
							$this->total_count++; // page total
						} // end foreach
						$this->FinalType(); // last Type to close, print footer
					} 
					?>
					<?php $this->GridFooter(); ?>
				</div>
			</div>
		</div>
		<?php
		$this->Footer();
	}

	/**
	  * Opens a new type container
	  */
	private function StartType($type) {
?>
		<!-- START Type -->
		<ul>
			<li class="title"><?php print( $type ) ?></li>
		</ul>
		<div class="panel">
			<!-- collapser here? -->
			<div class="inner">
				<ul class="topiclist">
					<li class="header">
						<dl>
							<!-- START BugList -->
							<table class="table1 responsive">
								<col width="30" /><!-- id -->
								<col /><!-- summary -->
								<col width="130" /><!-- category -->
								<col width="120" /><!-- status -->
								<col width="120" /><!-- assigned -->
								<col width="100" /><!-- created date -->
								<col width="30" /><!-- icon -->
								<thead>
									<tr>
										<th title="Bug ID">ID</th>
										<th>Summary</th>
										<th title="Category of bug">Category</th>
										<th title="Status of bug">Status</th>
										<th title="Who the bug is assigned to">Assigned</th>
										<th title="Date Created">Date</th>
										<th title="Priority">P</th>
									</tr>
								</thead>
								<tbody>
<?php
	}
	
	
	/**
	  * Closes existing category container
	  */
	private function EndType() {
	?>
								</tbody>
							</table>
							<!-- END BugList -->
						</dl>
					</li>
				</ul>
			</div>
		</div>
		<!-- END Type -->
<?php
	}


	/**
	  * Closes existing category container
	  */
	private function FinalType() {
	?>
								</tbody>
							</table>
							<!-- END BugList -->
						</dl>
					</li>
				</ul>
			</div>
		</div>
		<!-- END Type -->
	<?php
	}


	/**
	  * Injects a task row into the grid
	  */
	private function AddBugRow($row) {
		global $user;
		
		$RowColor = ( $this->row_count % 2 ) ? 'bg1' : 'bg3';
		
		// only draw row if there is data
		if( count($row) > 0 ) {
			// set a few local vars for table/checks
			$id			= $row[$this->SchemaMap->bugs['BugID']];
			$summary 	= $row[$this->SchemaMap->bugs['Summary']];
			$priority	= $this->Priority[$row[$this->SchemaMap->bugs['Priority']]];
			$category	= $row[$this->SchemaMap->bugs['Category']];
			$status		= $row[$this->SchemaMap->bugs['Status']];
			// Note: 'bug_created' is defined in the SQL query, so refer to it or you get that silly long datetime value
			$created	= ( $row['bug_created'] > 0 ) ? date('Y-m-d', $row['bug_created']) : "[unknown]";
			$description = $row[$this->SchemaMap->bugs['Description']];
			
			// only show assignee if user is not anon
			if( $user->data['user_id'] > 1 ) {
				$assignee = ( $row[$this->SchemaMap->bugs['AssignedTo']] > 1 ) ? $this->LookupForumUser($row[$this->SchemaMap->bugs['AssignedTo']]) : '[unassigned]';
			} else {
				$assignee = '[hidden]';
			}

		?>
		<tr class="<?php print( $RowColor ) ?>">
			<!--<td><a href="./index.php?p=bugs&id=<?php print( $id ) ?>#content" class="bug"><span style="color:<?php print( $priority['color'] ); ?>;"><?php print( $id ) ?></span></a></td>
			<td title="<?php print( $description ) ?>"><a href="./index.php?p=bugs&id=<?php print( $id ) ?>#content" class="bug"><span style="color:<?php print( $priority['color'] ); ?>;"><?php print( $summary ) ?></span></a></td>-->
			<td><a href="./index.php?p=bugs&id=<?php print( $id ) ?>"><?php print( $id ) ?></a></td>
			<td title="<?php print( $description ) ?>"><a href="./index.php?p=bugs&id=<?php print( $id ) ?>"><strong><?php print( $summary ) ?></strong></a></td>
			<td nowrap="nowrap"><?php print( $category ) ?></td>
			<td nowrap="nowrap"><?php print( $status ) ?></td>
			<td nowrap="nowrap"><? print( $assignee ) ?></td>
			<td><?php print( $created ); ?></a></td>
			<!--<td><a href="./index.php?p=bugs&id=<?php print( $id ) ?>#content" style="color:<?php print( $priority['text'] ); ?>;" class="username-coloured"><?php print( $summary ) ?></a></td>-->
			<!--<td width="50"><button class="mod-detail" onclick="goDetail()">Detail</button></td>-->
			<td width="20" title="<?php print( $priority['text'] ); ?>"><?php print( $priority['icon'] ); ?></td>
		</tr>
		<?php
		}
	}
	
	
	private function Detail() {
		
		$this->GetBugDetail();
		
		// make friendly some vars
		//$World = $this->GetWorld();
		
	?>
		<div class="post bg1">
			<div class="inner">
				<p class="postbody"><strong>Summary:</strong> <?php print( $this->BugDetail[$this->SchemaMap->bugs['Summary']] ); ?></p>
				<p class="postbody"><strong>Description:</strong> <?php print( $this->BugDetail[$this->SchemaMap->bugs['Description']] ); ?></p>
			</div>
		</div>
		
		<? if( $this->is_team) { ?>
		<ul>
			<li class="title">Controls</li>
		</ul>
		<div class="post bg1">
			<div class="inner">
				<!-- START Controls -->
				<table class="table1 responsive" border="0">
					<col width="160" />
					<col width="160" />
					<col width="180" />
					<col width="180" />
					<col width="150" />
					<col />
					<thead>
						<tr>
							<th align="left">Status</th>
							<th align="left">Assigned To</th>
							<th align="left">Bug Type</th>
							<th align="left">Priority</th>
							<th align="left">Fixed By</th>
							<th>&nbsp;</th>
						</tr>
					</thead>
					<tbody valign="top">
						<tr>
							<td>
							<select name="bug_status" class="bug" id="status" onchange="CheckStatus()">
							<?php
							foreach( $this->Status as $status ) {
								$selected = ( $this->BugDetail[$this->SchemaMap->bugs['Status']] === $status ) ? " selected" : "";											
								printf('<option%s>%s</option>', $selected, $status);
							}
							?>
							</select>
							&nbsp;
							</td>
							<td>
							<select name="assigned_to" class="bug" id="assignee" onchange="CheckStatus()">
								<option value="0">Unassigned</option>
								<?php $this->BugAssigneeOptions( $this->BugDetail[$this->SchemaMap->bugs['AssignedTo']] ) ?>
							</select><br />
							</td>
							<td>
							<select name="forum_id" class="bug">
							<?php
							foreach( $this->Type as $key=>$val ) {
								$selected = ( $this->BugDetail[$this->SchemaMap->bugs['ForumID']] === $val ) ? " selected" : "";											
								printf('<option value="%s"%s>%s</option>', $val, $selected, $key);
							}
							?>
							</select>
							<?php if( $this->BugDetail[$this->SchemaMap->bugs['PostID']] == 0 ) { ?>
							<input type="checkbox" name="forum_post" value="1" title="Create forum post based on Bug Type" id="forum" />
							<?php } ?>
							</td>
							<td>
							<select name="priority" class="bug">
							<?php
							foreach( $this->Priority as $key=>$val ) {
								$selected = ( $this->BugDetail[$this->SchemaMap->bugs['Priority']] == $key ) ? " selected" : "";											
								printf('<option value="%s"%s>%s</option>', $key, $selected, $val['text']);
							}
							?>
							</select>
							 &nbsp;<?php print( $this->Priority[$this->BugDetail[$this->SchemaMap->bugs['Priority']]]['icon'] ) ?>
							</td>
							<td>
							<select name="fixed_by_forum_id" class="bug" id="fixedby">
								<option value="0">---</option>
								<?php $this->BugAssigneeOptions($this->BugDetail[$this->SchemaMap->bugs['FixedBy']]) ?>
							</select>
							</td>
							<td><input type="submit" name="cmd" value="Update" class="bug" id="update" /></td>
						</tr>
					</tbody>
				</table>
				<script>CheckStatus()</script>
				<!-- END Controls -->
			</div>
		</div>
		<?php } ?>
		
		<ul>
			<li class="title">Bug Detail (Bug ID: <?php print( $this->BugDetail['id'] ) ?>)</li>
		</ul>
		<div class="panel">
			<div class="inner">
				<ul class="topiclist">
					<li class="header">
						<dl>
							<!-- START Detail -->
							<table class="table1 responsive">
								<col width="300" /><!-- label -->
								<col /><!-- detail -->
								<thead>
									<tr>
										<th>Field</th>
										<th>Value</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td class="Field">Bug ID</td>
										<td class="Value"><?php print( $this->BugDetail[$this->SchemaMap->bugs['BugID']] ); ?></td>
									</tr>
									<tr>
										<td class="Field">Bug Created</td>
										<td class="Value"><?php print( $this->BugDetail[$this->SchemaMap->bugs['BugCreated']] ); ?></td>
									</tr>
									<tr>
										<td class="Field">Status</td>
										<td class="Value"><?php print( $this->BugDetail[$this->SchemaMap->bugs['Status']] ); ?></td>
									</tr>
									<tr>
										<td class="Field">Type</td>
										<td class="Value"><?php print( $this->TypeByID[$this->BugDetail[$this->SchemaMap->bugs['BugType']]] ); ?></td>
									</tr>
									<tr>
										<td class="Field">Category</td>
										<td class="Value"><?php print( $this->BugDetail[$this->SchemaMap->bugs['Category']] ); ?></td>
									</tr>
									<tr>
										<td class="Field">Subcategory</td>
										<td class="Value"><?php print( $this->BugDetail[$this->SchemaMap->bugs['Subcategory']] ); ?></td>
									</tr>
									<tr>
										<td class="Field">Severity</td>
										<td class="Value"><?php print( $this->BugDetail[$this->SchemaMap->bugs['Severity']] ); ?></td>
									</tr>
									<tr>
										<td class="Field">Dev Priority</td>
										<td class="Value">
											<?php print( $this->Priority[$this->BugDetail[$this->SchemaMap->bugs['Priority']]]['icon'] ); ?>&nbsp;
											<?php print( $this->Priority[$this->BugDetail[$this->SchemaMap->bugs['Priority']]]['text'] ); ?>
										</td>
									</tr>
									<tr>
										<td class="Field">Is Reproducible?</td>
										<td class="Value"><?php print( $this->BugDetail[$this->SchemaMap->bugs['Reproducible']] ); ?></td>
									</tr>
									<tr>
										<td class="Field">Spawn Name (ID)</td>
										<td class="Value">
											<?php print( $this->BugDetail[$this->SchemaMap->bugs['EntityName']] ); ?> 
											(<?php print( $this->BugDetail[$this->SchemaMap->bugs['EntityID']] ); ?>)
										</td>
									</tr>
									<tr>
										<td class="Field">Zone</td>
										<td class="Value"><?php print( $this->BugDetail[$this->SchemaMap->bugs['LocationID']] ); ?></td>
									</tr>
									<tr>
										<td class="Field">Assigned To</td>
										<td class="Value"><?php print( $this->LookupForumUser($this->BugDetail[$this->SchemaMap->bugs['AssignedTo']]) ); ?></td>
									</tr>
									<tr>
										<td class="Field">Fixed By</td>
										<td class="Value"><?php print( $this->LookupForumUser($this->BugDetail[$this->SchemaMap->bugs['FixedBy']]) ); ?></td>
									</tr>
									<?php 
									if( $this->BugDetail[$this->SchemaMap->bugs['PostID']] > 0 ) { 
										$forum_link = sprintf('<a href="/phpBB3/viewforum.php?f=%s">%s&nbsp;<img src="%simages/icons/link.png" border="0" /></a>', 
															 $this->BugDetail[$this->SchemaMap->bugs['ForumID']],
															 $this->BugDetail[$this->SchemaMap->bugs['ForumID']],
															 PORTAL_RELATIVE_PATH);
										$post_link = sprintf('<a href="/phpBB3/viewtopic.php?p=%s#p%s">%s&nbsp;<img src="%simages/icons/link.png" border="0" /></a>', 
															 $this->BugDetail[$this->SchemaMap->bugs['PostID']],
															 $this->BugDetail[$this->SchemaMap->bugs['PostID']],
															 $this->BugDetail[$this->SchemaMap->bugs['PostID']],
															 PORTAL_RELATIVE_PATH);
									?>
									<tr>
										<td class="Field">Posted to Forum</td>
										<td class="Value"><?php print( $post_link ); ?></td>
									</tr>
									<tr>
										<td class="Field">Forum ID</td>
										<td class="Value"><?php print( $forum_link ); ?></td>
									</tr>
									<?php } ?>
									<tr>
										<td class="Field">Last Updated</td>
										<td class="Value"><?php print( date('Y-m-d h:i:s', $this->BugDetail[$this->SchemaMap->bugs['LastUpdated']]) ); ?></td>
									</tr>
									
									<?php /*?> only show these details to Team Members <?php */?>
									<?php if( $this->is_team ) { ?>
									<tr>
										<td class="Field">World</td>
										<td class="Value"><?php print( $this->BugDetail[$this->SchemaMap->bugs['ServerID']] ); ?></td>
									</tr>
									<tr>
										<td class="Field">Player Account</td>
										<td class="Value"><?php print( $this->BugDetail[$this->SchemaMap->bugs['AccountID']] ); ?></td>
									</tr>
									<tr>
										<td class="Field">Player Name</td>
										<td class="Value"><?php print( $this->BugDetail[$this->SchemaMap->bugs['Player']] ); ?></td>
									</tr>
									<tr>
										<td class="Field">EQ2 Client Version</td>
										<td class="Value"><?php print( $this->BugDetail[$this->SchemaMap->bugs['Version']] ); ?></td>
									</tr>
									<?php } ?>
								</tbody>
							</table>
							<!-- END Detail -->
						</dl>
					</li>
				</ul>
			</div>
		</div>
		<?php if( is_array($this->BugNotes) ) { ?>
		<ul>
			<li class="title">Bug Notes (Bug ID: <?php print( $this->BugDetail['id'] ) ?>)</li>
		</ul>
		<div class="panel">
			<div class="inner">
				<ul class="topiclist">
					<li class="header">
						<dl>
						<!-- START Notes -->
						<?php 
						foreach( $this->BugNotes as $note ) {
							?>
							<p class="postbody">
							<strong><?php print( $note['author'] ) ?></strong> on <?php print( date('M d Y', $note['note_date']) ) ?><br />
							<?php print( $note['note']); ?>
							</p>
							<?php
						}
						?>
						<!-- END Notes -->
						</dl>
					</li>
				</ul>
			</div>
		</div>
		<?php } ?>
		<?php 
		// get all bugs submitted by this account_id, put in $this->BugData and call $this->Results();
		$this->BugData = array();
		$this->GetBugsByAccount( $this->BugDetail[$this->SchemaMap->bugs['AccountID']] );
		if( count( $this->BugData ) > 0 ) {
		?>
		<ul>
			<li class="title">Other Bugs by this account</li>
		</ul>
		<div class="panel">
			<div class="inner">
				<ul class="topiclist">
					<li class="header">
						<dl>
						<!-- START Notes -->
						<p class="postbody">List of bugs submitted by this account across all servers/characters</p>
						<!-- END Notes -->
						</dl>
					</li>
				</ul>
			</div>
		</div>
		<?php
		$this->Results();
		}
	}

	private function GetBugDetail() {
		
		$this->SQLQuery = sprintf("SELECT *, UNIX_TIMESTAMP(%s) AS bug_created FROM " . LOGIN_DATABASE . ".bugs WHERE %s = %s", 
															 $this->SchemaMap->bugs['BugCreated'],
															 $this->SchemaMap->bugs['BugID'],
															 $this->BugID);
		
		$this->BugDetail = $this->RunQuerySingle();
		
		// get bug notes
		$this->SQLQuery = sprintf("SELECT * FROM " . LOGIN_DATABASE . ".bug_notes WHERE %s = %s ORDER BY %s", 
								 $this->SchemaMap->bugs['BugNoteID'], 
								 $this->BugID,
								 $this->SchemaMap->bugs['BugNoteDate']);
		
		$this->BugNotes = $this->RunQueryMulti();
		
	}


	public function Add() {
		global $MOD;
		
		$MOD->NotImplemented();
	}


	private function GridFooter() {
		
		if( $this->total_count == 0 ) {
			print('<div class="row-count">No records match the current criteria.</div>');
			return;
		}
			
		if( intval($this->Filters['limit']) === 0 && $this->total_count >= $_SESSION['modules']['config']['max_grid_rows'] )
			printf('<div class="row-count">Max rows displayed (%s) - apply additional filters</div>', $_SESSION['modules']['config']['max_grid_rows']);
		else
			printf('<div class="row-count">%s rows returned</div>', $this->total_count);
	}

	/**
	  * Adds necessary javascript code to the bottom of container
	  */
	private function Footer() {
		//This was very useful: http://stackoverflow.com/questions/21070101/show-hide-div-using-javascript
		?>
		<div class="action-bar bottom">
			<div class="pagination">&nbsp;</div>
		</div>
		<script type="text/javascript">
		document.getElementById('searchbox').addEventListener('click', function () {
			toggle(document.getElementById('search_panel'));
		});
		
		function toggle (elements, specifiedDisplay) {
		  var element, index;
		  
		  elements = elements.length ? elements : [elements];
		  for (index = 0; index < elements.length; index++) {
			element = elements[index];
		
			if (isElementHidden(element)) {
			  element.style.display = '';
			  // If the element is still hidden after removing the inline display
			  if (isElementHidden(element)) {
				element.style.display = specifiedDisplay || 'block';
			  }
			} else {
			  element.style.display = 'none';
			}
		  }
		  function isElementHidden (element) {
			return window.getComputedStyle(element, null).getPropertyValue('display') === 'none';
		  }
		}
		</script>
	<?php
	}

	private function DetailFooter() {
		//This was very useful: http://stackoverflow.com/questions/21070101/show-hide-div-using-javascript
		?>
		<script type="text/javascript">
		<!--
		-->
		</script>
	<?php
	}

	// temp function for me to build tables
	private function GenerateTable() {
		
		foreach( $this->BugDetail as $key=>$val ) {
			if( $key == 'summary' || $key == 'description' )
				continue;
		?>
		<tr>
			<td class="Field"><?php print( $key ) ?></td>
			<td class="Value"><?php print( $val ) ?></td>
		</tr>
		<?php }
	}
	


	/**
	 * Override SQL functions from Common
	 * REALLY dislike doing it this way, but I need separate creds/servers for gameservers?
	 */
	/****************************************************************************
	 * SQL Database Functions
	 ****************************************************************************/
	private function GetBacktrace()
	{
		$output = '<div style="font-family: monospace; font-size:15px;">';
		$backtrace = debug_backtrace();
		
		// We skip the first one, because it only shows this file/function
		unset($backtrace[0]);
		
		foreach ($backtrace as $trace)
		{
			// Strip the current directory from path
			$trace['file'] = (empty($trace['file'])) ? '(not given by php)' : htmlspecialchars($trace['file']);
			$trace['line'] = (empty($trace['line'])) ? '(not given by php)' : $trace['line'];
		
			// Only show function arguments for include etc.
			// Other parameters may contain sensible information
			$argument = '';
			if (!empty($trace['args'][0]) && in_array($trace['function'], array('include', 'require', 'include_once', 'require_once')))
			{
				$argument = htmlspecialchars($trace['args'][0]);
			}
		
			$trace['class'] = (!isset($trace['class'])) ? '' : $trace['class'];
			$trace['type'] = (!isset($trace['type'])) ? '' : $trace['type'];
		
			$output .= '<br />';
			$output .= '<b>FILE:</b> ' . $trace['file'] . '<br />';
			$output .= '<b>LINE:</b> ' . ((!empty($trace['line'])) ? $trace['line'] : '') . '<br />';
		
			$output .= '<b>CALL:</b> ' . htmlspecialchars($trace['class'] . $trace['type'] . $trace['function']);
			$output .= '(' . (($argument !== '') ? "'$argument'" : '') . ')<br />';
		}
		$output .= '</div>';
		return $output;
	}


	public function DBError() {
		global $MOD;
		
		$error = $this->db->sql_error();
		?>
		<div id="error-box">
		<table cellspacing="0" align="center">
			<tr>
				<td colspan="2" class="title">SQL Error: <?php print($error['code']); ?></td>
			</tr>
			<tr>
				<td class="label">Message:</td>
				<td class="detail"><?php print($error['message']); ?></td>
			</tr>
			<tr>
				<td class="label">Trace:</td>
				<td class="detail">
					<?php 
					print($this->GetBacktrace());
					?>
				</td>
			</tr>
			<tr>
				<td class="label">Query:</td>
				<td><?php print($this->SQLQuery); ?></td>
			</tr>
		</table>
		</div>
		<?php 
		if( $_SESSION['modules']['config']['debug'] == 1 && $_SESSION['modules']['user']['id'] == 2 ) 
			$MOD->DisplayDebug();
		include(PORTAL_ROOT_PATH."common/inc_footer.php");
		die();
	}

	/* SELECT: Use this RunQuery to return a single-row result set */
	public function RunQuerySingle($sql = '') {
		global $MOD;
		
		/*** Override $this with passed parameters ***/
		if( is_null($this->SQLQuery) && strlen($sql) > 6 )
			$this->SQLQuery = $sql;
		/**********************************************/
			
		// add ; to end of query, if missing, just for logging to screen
		if( strpos($this->SQLQuery, ";") == 0 )
			$this->SQLQuery = trim($this->SQLQuery) . ";";
			
		if( $_SESSION['modules']['config']['debug'] ) {
			$start_time = time();
			$MOD->AddDebugFunction(__FUNCTION__, "Enter");
			$MOD->AddDebugQuery(__FUNCTION__, $this->SQLQuery);
		}
		
		if( !$result = $this->db->sql_query($this->SQLQuery) ) {
			$this->DBError();
		} else {
			$num_rows = $this->db->sql_affectedrows($result);
			$rtn = $this->db->sql_fetchrow($result);
		}
		
		if( $_SESSION['modules']['config']['debug'] ) {
			$MOD->AddDebugData("RunQuerySingle", $rtn);
			$MOD->AddDebugFunction(__FUNCTION__, $num_rows." row(s)");
			if( $Elapsed > 1 )
				$Exit = sprintf("Exit - Elapsed: %s<br />Slow Query: %s", $Elapsed, $this->SQLQuery);
			else
				$Exit = "Exit";
			$MOD->AddDebugFunction(__FUNCTION__, $Exit);
		}

		unset($this->SQLQuery);  // nuke the query so it isn't used again
		
		return $rtn;
	}
	
	
	/* SELECT: Use this RunQuery to return a multiple-row result set */
	public function RunQueryMulti($sql = '') {
		global $MOD;
		
		/*** Override $this with passed parameters ***/
		if( is_null($this->SQLQuery) && strlen($sql) > 6 )
			$this->SQLQuery = $sql;
		/**********************************************/
			
		// add ; to end of query, if missing, just for logging to screen
		if( strpos($this->SQLQuery, ";") == 0 )
			$this->SQLQuery = trim($this->SQLQuery) . ";";
			
		if( $_SESSION['modules']['config']['debug'] ) {
			$start_time = time();
			$MOD->AddDebugFunction(__FUNCTION__, "Enter");
			$MOD->AddDebugQuery(__FUNCTION__, $this->SQLQuery);
		}
		
		if( !$result = $this->db->sql_query($this->SQLQuery) ) {
			$this->DBError();
		} else {
			$num_rows = $this->db->sql_affectedrows($result);
			while( $data = $this->db->sql_fetchrow($result) ) 
				$rtn[] = $data;
		}
		
		if( $_SESSION['modules']['config']['debug'] ) {
			$MOD->AddDebugData("RunQueryMulti Data", $rtn);
			$MOD->AddDebugFunction(__FUNCTION__, $num_rows." row(s)");
			$Elapsed = time() - $start_time;
			if( $Elapsed > 1 )
				$Exit = sprintf("Exit - Elapsed: %s<br />Slow Query: %s", $Elapsed, $this->SQLQuery);
			else
				$Exit = "Exit";
			$MOD->AddDebugFunction(__FUNCTION__, $Exit);
		}

		unset($this->SQLQuery);  // nuke the query so it isn't used again
		
		return $rtn;
	}
	

	public function RunQuery($sql = '') {
		global $MOD;
		
		$num_rows = 0;
		
		/*** Override $this with passed parameters ***/
		if( is_null($this->SQLQuery) && strlen($sql) > 6 )
			$this->SQLQuery = $sql;
		/**********************************************/

		// Check if SQLQuery has a valid query
		if( strlen($this->SQLQuery) === 0 )
			die("Invalid SQLQuery: '" . $this->SQLQuery . "'");
			
		// this should set the QueryType always
		$this->QueryType = substr($this->SQLQuery, 0, 6);
		
		// add ; to end of query, if missing, just for logging to screen
		if( strpos($this->SQLQuery, ";") == 0 )
			$this->SQLQuery = trim($this->SQLQuery) . ";";
			
		if( $_SESSION['modules']['config']['debug'] ) {
			$start_time = time();
			$MOD->AddDebugFunction(__FUNCTION__, "Enter");
			if( $_SESSION['modules']['config']['readonly'] )
				$MOD->AddDebugQuery(__FUNCTION__, "READ-ONLY: ".$this->SQLQuery);
			else
				$MOD->AddDebugQuery(__FUNCTION__, $this->SQLQuery);
		}
		
		switch($this->QueryType) {
			
			case "SELECT":
				if( !$result=$this->db->sql_query($this->SQLQuery) )
					$this->DBError();
				else {
					// temp: checking to see if I call RunQuery directly for any select statements
					die("Do not call RunQuery for Selects directly. Use RunQuerySingle, RunQueryMulti");
					$data = $this->db->sql_fetchrow($result);
				}
					
				break;
				
			case "INSERT":
			case "UPDATE":
			case "DELETE":
				if( $_SESSION['modules']['config']['readonly'] ) {
					$MOD->AddStatus("READ-ONLY MODE (".$this->QueryType.") - No data updated!", 1);
				} else {
					if( !$result = $this->db->sql_query($this->SQLQuery) )
						$this->DBError();
					else {
						$num_rows = $this->db->sql_affectedrows($result);
						
						$this->AffectedRows = $num_rows;
						$MOD->AddDebugGeneral("Affected Rows", $this->AffectedRows);
						$this->LastInsertID = $this->db->sql_nextid();
						$MOD->AddDebugGeneral("Last Insert ID", $this->LastInsertID);
					}
				}
				break;
		}
		
		if( $_SESSION['modules']['config']['debug'] )
		{
			$MOD->AddDebugData("RunQuery Data", $data);
			$MOD->AddDebugFunction(__FUNCTION__, $num_rows." row(s)");
			if( $Elapsed > 1 ) // i don't think I'm calculating Elapsed?
				$Exit = sprintf("Exit - Elapsed: %s<br />Slow Query: %s", $Elapsed, $this->SQLQuery);
			else
				$Exit = "Exit";
			$MOD->AddDebugFunction(__FUNCTION__, $Exit);
		}
		
		unset($this->QueryType); // nuke the type so it isn't used again
		unset($this->SQLQuery);  // nuke the query so it isn't used again
		
		return $num_rows;
	}

	public function LogQuery() {
		global $MOD;
		
		// Check if SQLQuery has a valid query
		if( strlen($this->SQLQuery) === 0 )
			die("Invalid SQLQuery: '" . $this->SQLQuery . "'");
			

		// add ; to end of query, if missing, just for logging to screen
		if( strpos($this->SQLQuery, ";") == 0 )
			$this->SQLQuery = trim($this->SQLQuery) . ";";
			
		if( $_SESSION['modules']['config']['debug'] ) {
			$MOD->AddDebugFunction(__FUNCTION__, "Enter");
			if( $_SESSION['modules']['config']['readonly'] )
				$MOD->AddDebugQuery(__FUNCTION__, "READ-ONLY: ".$this->SQLQuery);
			else
				$MOD->AddDebugQuery(__FUNCTION__, $this->SQLQuery);
		}
		
		if( $_SESSION['modules']['config']['readonly'] ) {
			$MOD->AddStatus("READ-ONLY MODE (".$this->QueryType.") - No data updated!", 1);
		} else {
			if( !$result = $this->db->sql_query($this->SQLQuery) )
				$this->DBError();
			// no LastInserID or AffectedRows on Log inserts!
		}
		
		if( $_SESSION['modules']['config']['debug'] )
			$MOD->AddDebugFunction(__FUNCTION__, "Exit");
		
		unset($this->QueryType); // nuke the type so it isn't used again
		unset($this->SQLQuery);  // nuke the query so it isn't used again
		
		return $num_rows;
	}

	public function GetTotalRows($database, $table) {
		$this->SQLQuery = sprintf("SELECT count(*) AS num FROM %s.%s;", $database, $table);
		$data = $this->RunQuerySingle();
		return ( !empty($data) ) ? $data['num'] : 0;
	}

	private function SQLLog() {
		global $MOD, $user;
		
		// stuff insert, update, delete queries into VGOeditor.log table
		if( $_SESSION['modules']['config']['debug'] )
			$MOD->AddDebugFunction(__FUNCTION__, "Enter");
		
		/*
		 * Logging Stuff goes Here
		 */
		if( $_SESSION['modules']['config']['sql_log'] )
		{
			$pattern[0] = "/".DEV_DB."\./i";
			$replace[0] = "";
			
			$log_query = preg_replace($pattern, $replace, $this->SQLQuery);
			
			// can't use RunQuery because we're getting the wrong LastInsertID!
			$log_insert = sprintf("INSERT INTO log (user_id, username, table_name, object_id, update_query, update_date) VALUES ('%s','%s','%s','%s','%s','%s')",
								$data->user['user_id'],
								$this->SQLEscape($data->user['username']),
								$this->SQLEscape($this->TableName),
								$this->SQLEscape($this->ObjectID),
								$this->SQLEscape($log_query),
								time());
			
			if( !$result = $this->db->sql_query($log_insert) )
				$this->DBError();
		}

		/*
		 * File Logging
		 */
		// 2016.10.23 - this needs to be refactored for portal apps
		if( $_SESSION['modules']['config']['sql_log_file'] )
		{
			$logfile = sprintf("logs/session_%s_%s_week%s.txt", 
												 strtolower($_SESSION['modules']['user']['username']), 
												 date("Y", time()), 
												 date("W", time()));

			$log_query .= "\n";
			
			if( $_SESSION['modules']['config']['readonly'] )
				$MOD->AddStatus("READ-ONLY MODE - ".$logfile." not saved!");
			else
			{
				if( file_exists($logfile) ) 
				{
					if( !$f = fopen($logfile, 'a') ) 
						die("Cannot open existing filename: $logfile");
		
					if( !fwrite($f, $log_query) )
						die("Cannot write to existing filename: $logfile");
		
					fclose($f);
				} 
				else 
				{
					if( !$f = fopen($logfile, 'x') ) 
						die("Cannot create new file: $logfile");
						
					if( !fwrite($f, $log_query) )
							die("Cannot write to new filename: $logfile");
							
					fclose($f);
				}
			}
			
		}

		if( $_SESSION['modules']['config']['debug'] )
			$MOD->AddDebugFunction(__FUNCTION__, "Exit");
	}

	public function SQLEscape($str) {
		return $this->db->sql_escape($str);
	}


	public function NoResults() {
		print("No Results in " . __FUNCTION__ . ", " . __LINE__);
	}


} // END Class

class Schema extends MODBugs {
	
	public $bugs = array();
	public $bug_notes = array();
	
	
	/*
	 * Thoughts on how to implement schema mapping:
	 * 		array 'key' is the editor field name
	 *		array 'value' is the actual database field name
	 * 		Use the array 'key' for the editor, and when updating data, 
	 * 		translate it to the array 'value' in the INSERT/UPDATE queries
	 *
	 * 		Or, use name="key[value]" in the form elements?
	 */
	public function __construct() {
		
		// return array of table in format of array(editor_field=>database_field);
		$this->bugs = array(
							'BugID'=>'id',
							'Status'=>'Status',
							'ServerID'=>'world_id',
							'AccountID'=>'account_id',
							'Player'=>'player',
							'Category'=>'category',
							'Subcategory'=>'subcategory',
							'Severity'=>'causes_crash',
							'Reproducible'=>'reproducible',
							'Summary'=>'summary',
							'Description'=>'description',
							'Version'=>'version',
							'EntityName'=>'spawn_name',
							'EntityID'=>'spawn_id',
							'BugCreated'=>'bug_datetime',
							'LocationID'=>'zone_id',
							'AssignedTo'=>'assign_to_forum_id',
							'FixedBy'=>'fixed_by_forum_id',
							'ForumID'=>'forum_id',
							'PostID'=>'post_id',
							'Priority'=>'priority',
							'LastUpdated'=>'bug_updated',
							'BugType'=>'bug_type',
							'BugNoteID'=>'bug_id',
							'BugNoteAuthor'=>'author',
							'BugNoteDate'=>'note_date'
							);
		
		$this->bug_notes = array(
								'id'=>'id',
								'bug_id'=>'bug_id',
								'note'=>'note',
								'author'=>'author',
								'note_date'=>'note_date'
								 );
	}
}
?>
