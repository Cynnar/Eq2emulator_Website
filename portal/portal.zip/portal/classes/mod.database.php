<?php
if( !defined("IN_PORTAL") )
	die("Hacking attempt.");

/*
 * TODO: Add $_SESSION to track new tables added, schema changed, and data entered - instead of constantly having to pick
 * Maybe a New Table Wizard that goes through table name, schema, data submissions all at once?
 * During testing, it's become cumbersome to keep re-selecting things...
 */
class MODDatabase {
	
	// public properties
	
	// private properties
	private $mode			= 1; // 0 = dev local
	private $max_cache_time	= 900; // # of seconds until cache expires
	
	private $Tables			= array();
	private $DataVers		= array(); // holds the max data version for each table
	private $QStatus 		= "OK";
	private $QCount			= 0;
	private $QueryArray 	= array(); // holds the query after being validated
	
	// new time display? date( "l, F d, Y g:i:s A", dateval ) = Monday, September 29, 2014 5:54:32 PM
	private $temp_date_str = "1999-01-01 00:00:00"; // unix_timestamp('1999-01-01 00:00:00');
	private $temp_user_str = "Unknown";
	private $temp_rev_str = 0;

	//
	// Constructor
	//
	public function __construct() 
	{
		global $user;
		
		// dev stuff
		if( intval( $this->mode ) === 1 )
		{
			$this->max_cache_time = 1; // do not cache while developing
			$this->temp_date_str = date( "Y-m-d h:i:s", time() );
			$this->temp_user_str = $user->data['username'];
			$this->temp_rev_str = 0; // no rev for normal inserts?
			// these fields will eventually be available in the new page layout
		}
		
		$this->db_host = $_SESSION['modules']['database'][1]['db_host']; // [1] assumes same DB server as LOGIN_DATABASE
		$this->db_user = $_SESSION['modules']['database'][1]['db_user'];
		$this->db_pass = $_SESSION['modules']['database'][1]['db_pass'];
		$this->db_name = $_SESSION['modules']['database'][1]['db_name'];
		$this->db_port = $_SESSION['modules']['database'][1]['db_port'];
		
		//printf('%s, %s, %s, %s, %s', $this->db_host, $this->db_user, $this->db_pass, $this->db_name, $this->db_port);
		include_once("mysql.class.php");
		$this->db = new MODMysql($this->db_host, $this->db_user, $this->db_pass, $this->db_name, false);

		// don't accidentally run this a second time!
		//$this->AutoBuildTables(); exit; 
		// don't accidentally run this a second time!
		
		$this->CachePatchData();
		//print_r($_SESSION['modules']['patch_data']);
		
		// what were we doing here?
		//if( $_GET['id'] > 0 )
		//	$_SESSION['modules'];
	}



	/** 
	 * This function loads the PatchServer data and caches it for 'n' seconds (max_cache_time). 
	 * Since the data doesn't change that often, we can trigger reloading the cache when/if a
	 * table, schema or data change occurs. Otherwise, prevent continuous reloading on page refreshes
	 */
	private function CachePatchData() {
		global $MOD;
		
		if( count($_SESSION['modules']['patch_data']) == 0 || $_SESSION['modules']['patch_data']['cachetime'] <= (time() - $this->max_cache_time) ) 
		{
			$MOD->Trace(__FUNCTION__, 'start');
			unset($_SESSION['modules']['patch_data']); // clear previous values
			$_SESSION['modules']['patch_data']['cachetime'] = time();
			
			$this->LoadPatchData();
			// send to debug
			$MOD->AddDebugGeneral('Patcher', sprintf('Patch cache refreshed (time: %s)', date('Y-m-d h:i:s', $_SESSION['modules']['patch_data']['cachetime'])));
			$MOD->Trace(__FUNCTION__, 'stop');
		}
		
		$MOD->AddDebugGeneral('Patcher', sprintf('Patch Max Cached (time: %ss)', $this->max_cache_time));
		$MOD->AddDebugGeneral('Patcher', sprintf('Patch Est cache refresh @ %s', date('Y-m-d h:i:s', $_SESSION['modules']['patch_data']['cachetime'] + $this->max_cache_time)));
		
	}

	private function LoadPatchData() 
	{
		$_SESSION['modules']['patch_data']['tables'] = $this->LoadTables();
		
		// now loop through all tables and get all schema and data changes for each one, if any
		if( count( $_SESSION['modules']['patch_data']['tables'] ) > 0 ) 
		{
			foreach( $_SESSION['modules']['patch_data']['tables'] as $table ) 
			{
				$_SESSION['modules']['patch_data']['tables'][$table['table_id']]['schema'] = $this->LoadSchemaChanges( $table['table_id'] );
				// we do nto want to load all table data changes as they are enormous, so just load an array of data version values for use with pickers
				$_SESSION['modules']['patch_data']['tables'][$table['table_id']]['data'] = $this->LoadDataVersions( $table['table_id'] );
			}
		}
	}
	
	
	// reset cache and reload if something was changed
	private function ResetCache()
	{
		$_SESSION['modules']['patch_data']['cachetime'] = 0;
		$this->CachePatchData();
	}


	private function LoadTables() 
	{
		$this->SQLQuery = sprintf("SELECT * FROM ".PATCH_DATABASE.".tables WHERE `name` <> 'table_versions' ORDER BY `name`");
		$data = $this->RunQueryMulti();
		
		if( count($data) > 0 ) 
		{
			foreach( $data as $table )
				$table_arr[$table['table_id']] = $table;
		}
		
		return $table_arr;
	}


	private function LoadSchemaChanges( $table_id = 0 ) 
	{
		$this->SQLQuery = sprintf("SELECT * FROM ".PATCH_DATABASE.".table_versions WHERE table_id = %s ORDER BY `version`", $table_id);
		$data = $this->RunQueryMulti();
		
		if( count($data) > 0 ) 
		{
			foreach( $data as $version )
				$version_arr[$version['version']] = $version;
		}
		
		return $version_arr;
	}


	private function LoadDataVersions( $table_id = 0 ) 
	{
		$this->SQLQuery = sprintf("SELECT id, table_id, data_version, date_created, last_updated, submitted_by, svn_rev FROM ".PATCH_DATABASE.".table_data WHERE table_id = %s ORDER BY `data_version`", $table_id);
		$data = $this->RunQueryMulti();
		
		if( count($data) > 0 ) 
		{
			foreach( $data as $data_version )
				$version_arr[$data_version['data_version']] = $data_version;
		}
		
		return $version_arr;
	}
	
	
	// This function scans the tables array to see if $table_name exists, if not return false
	private function TableExists( $table_name )
	{
		if( count( $_SESSION['modules']['patch_data']['tables'] ) > 0 )
		{
			foreach( $_SESSION['modules']['patch_data']['tables'] as $table ) 
			{
				if( $table['name'] === $table_name )
					return true;
			}
		}
		
		return false;
	}
	
	private function GetTableDataVersions()
	{
		$this->SQLQuery = sprintf("SELECT * FROM ".PATCH_DATABASE.".table_data WHERE table_id = %s ORDER BY `data_version`", $_GET['id']);
		return $this->RunQueryMulti();
	}


	private function GetTableDataVersionsByVersion( $version )
	{
		$this->SQLQuery = sprintf("SELECT * FROM ".PATCH_DATABASE.".table_data WHERE table_id = %s AND data_version = %s", $_GET['id'], $version);
		return $this->RunQueryMulti();
	}


	private function GetMaxSchemaVersion() 
	{
		$this->SQLQuery = "SELECT MAX(`version`) AS ver FROM " . PATCH_DATABASE . ".table_versions";
		$ret = $this->RunQuerySingle();
		return $ret['ver'];
	}
	
	
	private function GetMaxDataVersion() 
	{
		$this->SQLQuery = "SELECT MAX(`data_version`) AS ver FROM " . PATCH_DATABASE . ".table_data WHERE table_id = " . $_GET['id'];
		$ret = $this->RunQuerySingle();
		return $ret['ver'];
	}
	
	
	private function SetOverviewStats() 
	{
		$this->OverviewData = array();
		$this->OverviewData['EQ2_DB_VERSION'] = $this->GetMaxSchemaVersion();
		
		$this->SQLQuery = "SELECT COUNT(*) AS t1 FROM " . PATCH_DATABASE . ".tables";
		$data = $this->RunQuerySingle();
		$this->OverviewData['TABLES'] = $data['t1'];
		
		$this->SQLQuery = "SELECT COUNT(*) AS t2 FROM " . PATCH_DATABASE . ".table_versions";
		$data = $this->RunQuerySingle();
		$this->OverviewData['SCHEMA'] = $data['t2'];
		
		$this->SQLQuery = "SELECT COUNT(*) AS t3 FROM " . PATCH_DATABASE . ".table_data";
		$data = $this->RunQuerySingle();
		$this->OverviewData['DATA'] = $data['t3'];
		
		$this->SQLQuery = "SELECT COUNT(*) AS s1 FROM " . PATCH_DATABASE . ".sessions";
		$data = $this->RunQuerySingle();
		$this->OverviewData['SESSIONS'] = $data['s1'];
		
		$this->SQLQuery = "SELECT COUNT(*) AS l1 FROM " . PATCH_DATABASE . ".lockouts";
		$data = $this->RunQuerySingle();
		$this->OverviewData['LOCKOUTS'] = $data['l1'];
		
		$this->SQLQuery = "SELECT MAX(svn_rev) AS v1 FROM " . PATCH_DATABASE . ".table_versions";
		$data = $this->RunQuerySingle();
		$this->OverviewData['SVNSCHEMA'] = $data['v1'];
		
		$this->SQLQuery = "SELECT MAX(svn_rev) AS v2 FROM " . PATCH_DATABASE . ".table_data";
		$data = $this->RunQuerySingle();
		$this->OverviewData['SVNDATA'] = $data['v2'];
		
		$this->SQLQuery = "SELECT t.name, COUNT(*) AS num, 0 AS `data` FROM " . PATCH_DATABASE . ".table_versions tv " .
							"LEFT JOIN " . PATCH_DATABASE . ".`tables` t ON t.table_id = tv.table_id " .
							"GROUP BY tv.table_id " .
							"UNION " .
							"SELECT t.name, 0 AS num, COUNT(*) AS `data` FROM " . PATCH_DATABASE . ".table_data td " .
							"LEFT JOIN " . PATCH_DATABASE . ".`tables` t ON t.table_id = td.table_id " .
							"GROUP BY td.table_id";
							
		$rows = $this->RunQueryMulti();
		
		foreach( $rows as $data ) {
			if( $data['num'] > 0 )
				$schema[$data['name']]['num'] = $data['num'];
			if( $data['data'] > 0 )
				$schema[$data['name']]['data'] = $data['data'];
		}

		$this->OverviewData['S_DETAIL'] = $schema;
		
	}
	
	
	public function Screen() 
	{
		global $MOD;
		?>
		<div id="section">
			<ul>
				<li class="section-title">DB Updates</li>
			</ul>
		</div>
		<div class="post bg1">
			<div class="inner">
                <div id="mmtabs">
                    <ul>
						<li<?php if(empty($_GET['tab']) ) print(' id="activetab"') ?>><a href="<?= $MOD->FullPage ?>" style="width:100px; text-align:center;"><span>Statistics</span></a></li>
						<!-- <li<?php if($_GET['tab']=="detail" ) print(' id="activetab"') ?>><a href="<?= $MOD->FullPage ?>&tab=detail" style="width:100px; text-align:center;"><span>Detail View</span></a></li> -->
						<li<?php if($_GET['tab']=="tables" ) print(' id="activetab"') ?>><a href="<?= $MOD->FullPage ?>&tab=tables" style="width:100px; text-align:center;"><span>Tables</span></a></li>
						<li<?php if($_GET['tab']=="schema" ) print(' id="activetab"') ?>><a href="<?= $MOD->FullPage ?>&tab=schema" style="width:120px; text-align:center;"><span>Schema</span></a></li>
						<li<?php if($_GET['tab']=="data" ) print(' id="activetab"') ?>><a href="<?= $MOD->FullPage ?>&tab=data" style="width:100px; text-align:center;"><span>Data</span></a></li>
						<li<?php if($_GET['tab']=="sessions" ) print(' id="activetab"') ?>><a href="<?= $MOD->FullPage ?>&tab=sessions" style="width:100px; text-align:center;"><span>Sessions</span></a></li>
						<li<?php if($_GET['tab']=="lockouts" ) print(' id="activetab"') ?>><a href="<?= $MOD->FullPage ?>&tab=lockouts" style="width:100px; text-align:center;"><span>Lockouts</span></a></li>
						<!-- <li<?php if($_GET['tab']=="logs" ) print(' id="activetab"') ?>><a href="<?= $MOD->FullPage ?>&tab=logs" style="width:100px; text-align:center;"><span>Logs</span></a></li> -->
                    </ul>
                </div>
				<div class="postbody">
					<div class="content">
					<?php 
					switch( $_GET['tab'] ) {
						case "detail"	: $this->DetailView(); break;
						case "tables"	: $this->Tables(); break;
						case "schema"	: $this->Schema(); break;
						case "data"		: $this->Data(); break;
						case "sessions"	: $this->Sessions(); break;
						case "lockouts"	: $this->Lockouts(); break;
						case "logs"		: $this->Logs(); break;
						default			: $this->Statistics(); break;
					}
					?>
					</div>
				</div>
			</div>
		</div>
		<?php
		//$this->Footer();
	}


	private function Statistics() {
		global $MOD;
		
		// build stats data
		$this->SetOverviewStats();
		
		?>
		<div id="section">
			<ul style="margin-left:0px;">
				<li class="section-title">Overview of DB Patcher Schema and Data</li>
			</ul>
		</div>
        <table class="table1 responsive">
        	<col width="300" />
            <col />
            <tbody>
            	<tr>
                	<td colspan="2">
				        <p>Commit Schema changes or data updates, review previous updates, manage connections to Patch Server.</p>
                    </td>
                </tr>
                <tr>
                    <td class="DBVer" align="right">Current EQ2_DB_VERSION:</td>
                    <td class="DBVer"><?php print( $this->OverviewData['EQ2_DB_VERSION'] ); ?></td>
                </tr>
                <tr>
                    <td align="right"><strong># Tables:</strong></td>
                    <td><?php print( $this->OverviewData['TABLES'] ); ?></td>
                </tr>
                <tr>
                    <td align="right"><strong># Schema Changes:</strong></td>
                    <td><?php print( $this->OverviewData['SCHEMA'] ); ?></td>
                </tr>
                <tr>
                    <td align="right"><strong># Data Changes:</strong></td>
                    <td><?php print( $this->OverviewData['DATA'] ); ?></td>
                </tr>
                <tr>
                    <td align="right"><strong># Sessions:</strong></td>
                    <td><?php print( $this->OverviewData['SESSIONS'] ); ?></td>
                </tr>
                <tr>
                    <td align="right"><strong># Active Lockouts:</strong></td>
                    <td><?php print( $this->OverviewData['LOCKOUTS'] ); ?></td>
                </tr>
                <tr>
                    <td align="right"><strong>Latest SVN for Schema:</strong></td>
                    <td><?php print( $this->OverviewData['SVNSCHEMA'] ); ?></td>
                </tr>
                <tr>
                    <td align="right"><strong>Latest SVN for Data:</strong></td>
                    <td><?php print( $this->OverviewData['SVNDATA'] ); ?></td>
                </tr>
            </tbody>
        </table>
		<br />
		<div id="section">
			<ul style="margin-left:0;">
				<li class="section-title">Summary O' Updates</li>
			</ul>
		</div>
        <table class="table1 responsive">
            <col width="300" />
            <col width="200" />
            <col width="200" />
            <col />
            <thead>
                <tr>
                    <th align="left">table name</th>
                    <th align="left"># schema per table</th>
                    <th align="left"># data per table</th>
                    <th>&nbsp;</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                foreach($this->OverviewData['S_DETAIL'] as $table=>$detail) {
                ?>
                <tr>
                    <td><strong><?php print($table) ?></strong></td>
                    <td><?php print($detail['num']) ?></td>
                    <td><?php print($detail['data']) ?></td>
                    <td>&nbsp;</td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
		<?php 
	}
	
	
	private function DetailView() 
	{
		global $MOD;
		?>
		<div id="section">
			<ul style="margin-left:0px;">
				<li class="section-title">Table and Data Details</li>
			</ul>
		</div>
        <p>Displays the selected table, all schema and data changes as they relate to each other.</p>
        <table class="table1 responsive">
            <col width="200" /><!-- table selector column -->
            <col /><!-- display container -->
            <thead>
				<tr>
					<td>
						<select id="table-selector" onChange="dosub(this.options[this.selectedIndex].value)">
							<option value="index.php?p=patcher&tab=detail">-- Select a Table --</option>
							<?php 
							if( count( $_SESSION['modules']['patch_data']['tables'] ) > 0 )
							{
								foreach( $_SESSION['modules']['patch_data']['tables'] as $table )
								{
									printf('<option value="index.php?p=patcher&tab=detail&id=%s"%s>%s</option>', $table['table_id'], ( $_GET['id'] == $table['table_id'] ) ? " selected" : "", $table['name']);
								}
							}
							
							?>
						</select>
						<script>
						<!-- size select box to fit content dynamically https://stackoverflow.com/a/31537994 -->
						var select = document.getElementById('table-selector');
						select.size = select.length;
						</script>
					</td>
					<td valign="top">
						<div id="patcher-details"<?php ( strlen( $_GET['id'] ) === 0 ) ? print('style="display:none"') : print('') ?>>
						<table width="100%">
							<tr>
								<td>
								<div id="section">
									<ul style="margin-left:0px;">
										<li class="section-title">Displaying details for table: </li>
									</ul>
								</div>
								</td>
							</tr>
						</table>
						</div>
					</td>
				</tr>
			</thead>
		</table>
	<?php
	}
	
	
	private function Logs() 
	{

	}
	
	
	private function Tables() 
	{
		global $MOD, $user;
		
		switch($_POST['cmd']) 
		{
			case 'Delete':
			
				if( strlen( $_POST['table_id'] ) > 0 ) 
				{
					$this->SQLQuery = sprintf( "DELETE FROM " . PATCH_DATABASE . ".tables WHERE `table_id` = '%s'", $_POST['table_id'] );
					$this->RunQuery();
					$MOD->AddStatus("Table '" . $_POST['table_name'] . "' deleted!");
		
					// update log
					$log_array['log_type'] 		= 'EQ2Updates';
					$log_array['log_operation'] = 'PATCHER_TABLES_DELETE';
					$log_array['log_data']		= sprintf( "id:%s;\nname:%s;\nuser:%s", 
														  intval( $_POST['table_id'] ), 
														  $this->SQLEscape( $_POST['table_name'] ), 
														  $this->SQLEscape( $user->data['username'] ) );
					$MOD->Log( $log_array );
					
					$this->ResetCache();
				}
				break;
				
			case 'Add':

				if( strlen( $_POST['table_new'] ) > 0 ) 
				{
					// separate IF for error handling
					if( !$this->TableExists( $_POST['table_new'] ) ) 
					{
						$this->SQLQuery = sprintf("INSERT INTO " . PATCH_DATABASE . ".tables (name, date_created, submitted_by) VALUES ('%s','%s','%s')", 
																					$this->SQLEscape( $_POST['table_new'] ),
																					strtotime( $_POST['date_created'] ),
																					$this->SQLEscape( $_POST['submitted_by'] )
																					);
						$this->RunQuery();
						$MOD->AddStatus("Table '" . $_POST['table_new'] . "' added!");
			
						// update log
						$log_array['log_type'] 		= 'EQ2Updates';
						$log_array['log_operation'] = 'PATCHER_TABLES_ADD';
						$log_array['log_data']		= sprintf( "id:new:%s;\ntable:%s;\nuser:%s", 
															  $this->LastInsertID, 
															  $this->SQLEscape( $_POST['table_new'] ), 
															  $this->SQLEscape( $_POST['submitted_by'] ) );
						$MOD->Log( $log_array );
						
						$this->ResetCache();
					} 
					else 
					{
						$MOD->AddStatus("Table '" . $_POST['table_new'] . "' already exists!");
					}
				}
				else
				{
					$MOD->AddStatus("Table name '" . $_POST['table_new'] . "' is invalid!");
				}
				
				break;
		}

		?>
		<div id="section">
			<ul style="margin-left:0px;">
				<li class="section-title">Current configured Tables on Patch Server</li>
			</ul>
		</div>
        <strong>Special Instructions:</strong> <em>Deleting a `tables` entry is extremely destructive. It will destroy all table/data updates for that table, irreversible.<br><br />
                        Because of this, only a Super Admin can delete a `tables` entry.</em>
        <table class="table1 responsive">
            <col width="100" />
            <col />
            <col width="150" />
            <col width="200" />
            <col width="100" />
            <thead>
                <tr>
                    <td colspan="5" height="30" style="text-align:center; color:#F00; font-weight:bold;">
					<?php
                    // Error handler
                    if( strlen($MOD->Status) > 0 )
                        print($MOD->Status);
                    ?>
                    </td>
                </tr>
                <tr>
                    <th align="left">table_id</th>
                    <th align="left">name</th>
                    <th align="left">created by</th>
                    <th align="left">created on</th>
                    <th>&nbsp;</th>
                </tr>
            </thead>
            <tbody>
            <?php 
			if( count( $_SESSION['modules']['patch_data']['tables'] ) > 0 ) 
			{
				foreach( $_SESSION['modules']['patch_data']['tables'] as $table ) 
				{
					$created_on = ( intval( $table['date_created'] ) > 0 ) ? date( 'Y-m-d H:i:s', $table['date_created'] ) : "Not Set";
					?>
					
					<form method="post" name="tables_<?php print( $table['table_id'] ); ?>">
					<tr>
						<td><?php print( $table['table_id'] ); ?></td>
						<td><a href="index.php?p=patcher&tab=schema&id=<?php print( $table['table_id'] ); ?>"><?php print( $table['name'] ); ?></a></td>
						<td><?php print( $table['submitted_by'] ); ?></td>
						<td><?php print( $created_on ); ?></td>
						<td align="right">
							<?php if( $MOD->is_admin ) { ?>
							<input type="hidden" name="table_name" value="<?php print( $table['name'] ); ?>" />
							<input type="hidden" name="table_id" value="<?php print( $table['table_id'] ); ?>" />
                            <input type="submit" name="cmd" value="Delete">
							<?php } ?>
						</td>
					</tr>
					</form>
					<?php
					$this->total_count++;
				} // end for
				?>
			<?php
			} // end is count
			?>

            <form method="post" name="tables_add">
            <tr>
                <td><strong>NEW</strong></td>
                <td><input type="text" name="table_new" value="" /></td>
				<?php if( $this->mode == 0 ) { ?>
                <td><input type="text" name="submitted_by" value="<?php print( $this->temp_user_str ) ?>" size="12" /></td>
                <td><input type="text" name="date_created" value="<?php print( $this->temp_date_str ) ?>" size="20" /></td>
                <td align="right"><input type="submit" name="cmd" value="Add" /></td>
				<?php } else { ?>
                <td colspan="3" align="right">
				<input type="submit" name="cmd" value="Add" />
				</td>
				<?php } ?>
            </tr>
			<?php if( $this->mode === 1 ) { ?>
			<!-- work these into the new page design -->
			<input type="hidden" name="date_created" value="<?php print( $this->temp_date_str ) ?>" />
			<input type="hidden" name="submitted_by" value="<?php print( $this->temp_user_str ) ?>" />
			<!-- -->
			<?php } ?>
            </form>
            </tbody>
        </table>
        <br />
		<?php 
		$this->GridFooter();
	}
	
	/** Some concepts;
	  *	Validation must occur on every query submitted; check for semi-colons, check for table_name matches the selected table (or New)
	  * If adding NEW schema, also insert into `tables`? or will we need the table_id first?
	  */
	private function Schema() 
	{
		global $MOD, $user;

		$ok = true;
		
		switch($_POST['cmd']) 
		{
			case 'Add':
			
				$table_name = $this->SQLEscape($_POST['table_name']);
			
				if( $this->ValidateSchemaQuery($_POST['query']) ) 
				{
					$table_id = $_GET['id'];
					
					// if this is a CREATE but there is no preceeding DROP, add one
					if( stripos( $_POST['query'], "CREATE" ) !== false && stripos( $_POST['query'], "DROP") === false ) {
						$drop_query = sprintf('DROP TABLE IF EXISTS `%s`;\n', $table_name);
					}
					
					$fixed_query = $drop_query . $this->SQLEscape( $_POST['query'] );
					
					// using the existing table_id, insert the versions data
					$this->SQLQuery = sprintf("INSERT INTO " . PATCH_DATABASE . ".table_versions (table_id, query, version, date_created, submitted_by, svn_rev) VALUES ('%s','%s','%s','%s','%s','%s')", 
													$table_id, 
													$fixed_query, 
													$_POST['next_version'], 
													( strlen( $_POST['date_created'] ) > 0 ) ? strtotime($_POST['date_created']) : time(), 
													( strlen( $_POST['submitted_by'] ) > 0 ) ? $this->SQLEscape($_POST['submitted_by']) : $user->data['username'],
													( strlen( $_POST['svn_rev'] ) > 0 ) ? intval($_POST['svn_rev']) : 0
													);
					$this->RunQuery();
					// assuming success
					$MOD->AddStatus("Add Schema for table '" . $table_name . "' submitted! QStatus: " . $this->QStatus . ", QCount: " . $this->QCount);
		
					// update log
					$log_array['log_type'] 		= 'EQ2Updates';
					$log_array['log_operation'] = 'PATCHER_SCHEMA_ADD';
					$log_array['log_data']		= sprintf( "id:new:%s;\ntable:%s;\nuser:%s;\nquery:%s", 
														  $this->LastInsertID, 
														  $this->SQLEscape( $table_name ), 
														  $this->SQLEscape( $user->data['username'] ), 
														  $fixed_query );
					$MOD->Log( $log_array );
					
					$this->ResetCache();
				}
				else 
				{
					$MOD->AddStatus("Add Schema for table '" . $table_name . "' FAILED! QStatus: " . $this->QStatus . ", QCount: " . $this->QCount);
				}
				
				break;
				
			case 'Update':	// update query
			
				$table_version_idx = intval( $_POST['id'] ); // table PK
				$table_name = $_POST['table_name'];
				$table_version = $_POST['version_num'];
				$table_query_old = $_POST['orig_query'];
				$table_query_new = $_POST['query'];
				
				if( $this->ValidateSchemaQuery( $table_query_new ) ) 
				{
					$this->SQLQuery = sprintf("UPDATE " . PATCH_DATABASE . ".table_versions SET query = '%s', last_updated = '%s' WHERE `id` = '%s'", 
											  $this->db->sql_escape($_POST['query']), 
											  time(), 
											  $table_version_idx);
					$this->RunQuery();
					// assuming success
					$MOD->AddStatus("Schema update for table '" . $table_name . "' submitted! QStatus: " . $this->QStatus . ", QCount: " . $this->QCount);
		
					// update log
					$log_array['log_type'] 		= 'EQ2Updates';
					$log_array['log_operation'] = 'PATCHER_SCHEMA_UPDATE';
					$log_array['log_data']		= sprintf( "id:%s;\ntable:%s;\nversion:%s;\nuser:%s;\noldval:%s;\nnewval:%s", 
														  $table_version_idx, 
														  $this->SQLEscape( $table_name ), 
														  $table_version, 
														  $this->SQLEscape( $user->data['username'] ), 
														  $this->SQLEscape( $table_query_old ),
														  $this->SQLEscape( $table_query_new ) 
														  );
					$MOD->Log( $log_array );

					$this->ResetCache();
				}
				else
				{
					// failed validation
					$MOD->AddStatus("Schema update for table '" . $table_name . "' FAILED! QStatus: " . $this->QStatus . ", QCount: " . $this->QCount);
				}
				
				break;
				
			case 'Commit':
			
				$this->SQLQuery = sprintf("UPDATE " . PATCH_DATABASE . ".table_versions SET committed = 1, last_updated = '%s' WHERE `id` = '%s'", time(), $_POST['id']);
				$this->RunQuery();
				
				$MOD->AddStatus("Table '" . $_POST['table_name'] . "' committed! No further changes allowed.");
	
				// update log
				$log_array['log_type'] 		= 'EQ2Updates';
				$log_array['log_operation'] = 'PATCHER_SCHEMA_COMMIT';
				$log_array['log_data']		= sprintf( "id:%s;\ntable:%s;\nuser:%s", 
													  $_POST['id'], 
													  $this->SQLEscape( $_POST['table_name'] ), 
													  $this->SQLEscape( $user->data['username'] )
													  );
				$MOD->Log( $log_array );
					
				$this->ResetCache();
				break;
				
			case 'Delete':
				
				if( $MOD->is_admin )
				{
					$table_name = $_POST['table_name'];
					$table_version = $_POST['version_num'];
					$table_version_idx = $_POST['id'];
					
					$this->SQLQuery = sprintf("DELETE FROM " . PATCH_DATABASE . ".table_versions WHERE `id` = '%s'", $table_version_idx);
					$this->RunQuery();
					
					$MOD->AddStatus("Schema changes for table '" . $table_name . "' (version: " . $table_version . ") deleted.");
		
					// update log
					$log_array['log_type'] 		= 'EQ2Updates';
					$log_array['log_operation'] = 'PATCHER_SCHEMA_DELETE';
					$log_array['log_data']		= sprintf( "id:%s;\ntable:%s;\nversion=%s;\nuser:%s;\nquery=%s", 
														  $table_version_idx, 
														  $this->SQLEscape( $table_name ), 
														  $table_version, 
														  $this->SQLEscape( $user->data['username'] ), 
														  $this->SQLEscape( $_POST['query'] ) 
														  );
					$MOD->Log( $log_array );

					$this->ResetCache();
				}
				else
				{
					$MOD->AddStatus("Must be project admin to delete data.");
				}
				break;
				
			case 'Set':
			
				$table_version_idx = $_POST['id'];
				$table_name = $_POST['table_name'];
				$table_version = $_POST['version_num'];
				// check if disabled is selected
				$table_max_data_version = ( $_POST['max_data_version'] === "NULL" ) ? "NULL" : intval( $_POST['max_data_version'] );
				
				// it's important that max_data_version = %s is not 'quoted' because we need NULL to be NULL, not "NULL" string inserted into an int(10) field
				$this->SQLQuery = sprintf("UPDATE " . PATCH_DATABASE . ".table_versions SET max_data_version = %s, last_updated = '%s' WHERE `id` = '%s'", 
										  $table_max_data_version, 
										  time(), 
										  $table_version_idx);
				$this->RunQuery();
				
				$MOD->AddStatus("Table '" . $table_name . "' max_data_version set to ". $table_max_data_version ."!");
	
				// update log
				$log_array['log_type'] 		= 'EQ2Updates';
				$log_array['log_operation'] = 'PATCHER_SCHEMA_SET_DATAVER';
				$log_array['log_data']		= sprintf( "id:%s;\ntable:%s;\nversion=%s;\ndataver:%s;\nuser:%s", 
													  $table_version_idx, 
													  $this->SQLEscape( $table_name ), 
													  $table_version,
													  $table_max_data_version,
													  $this->SQLEscape( $user->data['username'] )
													  );
				$MOD->Log( $log_array );
				
				$this->ResetCache();
				
				break;
		}

		if( count( intval( $_SESSION['modules']['patch_data']['tables'] ) ) === 0 )
		{
			$MOD->AddStatus("There are no tables! Add some.");
			$ok = false;
		}
		?>
		<div id="section">
			<ul style="margin-left:0px;">
				<li class="section-title">Review Existing Schema Changes</li>
			</ul>
		</div>
        <table class="table1 responsive">
            <tr>
                <td colspan="3" height="30" style="text-align:center; color:#F00; font-weight:bold;">
                <?php
                // Error handler
                if( strlen($MOD->Status) > 0 )
                    print($MOD->Status);
                ?>
                </td>
            </tr>
			<?php if( $ok ) { ?>
            <tr>
                <td colspan="5">
                    <strong>Review Instructions:</strong> Use the combo box below to filter the list of schema updates you wish to review --<br>
                    <ul>
                        <li>Filter: <strong>SHOW UNCOMMITTED</strong> - list all schema updates pending finalization</li><br />
                        <li>Filter: [<strong>table_name</strong>] - pick an individual table to view all of it's schema updates</li><br />
						<li>Action: <strong>UPDATE</strong> - You can alter a query record until you <strong>COMMIT</strong> it; then subsequent changes require a new schema change record</li><br />
						<li>Action: <strong>DELETE</strong> - Likewise, you can delete a schema entry as long as it is not yet <strong>COMMIT</strong>ed.</li><br />
						<li>Action: <strong>COMMIT</strong> - Finalize the entry by <strong>COMMIT</strong>ing the record, allowing you to <strong>SET</strong> a data version for the schema change</li><br />
						<li>Data: <strong>SET</strong> - 
						<ul>
							<li><strong>INFINITE</strong>: Table allows all data versions - usually for schemas that rarely change, like `opcodes`</li><br />
							<li><strong>DISABLED</strong>: Table does NOT allow data downloads, only schema updates</li><br />
							<li><strong>{max_data_version}</strong>: This specific Schema change only supports data versions UP TO this data version number</li><br />
						</ul>
						</li>
						<li>Note: The <strong>data version</strong> is not the "Version" column on this page; it is on the Data tab for the given table.</li>
                    </ul>
                    Once you pick a table, you will see it's name, table_id, the query, the version assigned to the update and it's max data version that matches this schema
                    <hr />
                    <select name="table_id" onChange="dosub(this.options[this.selectedIndex].value)">
                        <option value="./index.php?p=patcher&tab=schema">-- Table Filter --</option>
                        <option value="./index.php?p=patcher&tab=schema&id=commit"<?php if( $_GET['id'] == 'commit' ) print(' selected') ?>>-- SHOW UNCOMMITTED --</option>
                        <?php
                        foreach( $_SESSION['modules']['patch_data']['tables'] as $table ) 
						{
                            printf('<option value="./index.php?p=patcher&tab=schema&id=%s"%s>%s</option>', $table['table_id'], ($_GET['id'] == $table['table_id']) ? " selected" : "", $table['name']);
                        }
                        ?>
                    </select>&nbsp;
                </td>
            </tr>
			<?php } ?>
        </table>
		<?php 
		// doing this so if there are no tables, stop showing anything except $status
		if( !$ok || strlen( $_GET['id'] ) === 0 )
			return;
		?>
		<table class="table1 responsive">
			<col />
			<col width="80" />
			<col width="80" />
			<col width="80" /> <!-- the Delete/Commit column -->
			<thead>
				<tr>
					<th align="left">query</th>
					<th>version</th>
					<th>data</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody class="version">
			<?php
			// need to show all uncommitted changes, if id=commit
			if( strlen( $_GET['id'] ) > 0 && strcmp( $_GET['id'], "commit" ) === 0 ) 
			{
				if( count( $_SESSION['modules']['patch_data']['tables'] ) > 0 ) 
				{
					foreach( $_SESSION['modules']['patch_data']['tables'] as $table_id => $table_data ) 
					{
						$this->SchemaRow( $_SESSION['modules']['patch_data']['tables'][$table_id] );
					}
				}
			}
			// else show the selected table schema changes
			elseif( intval( $_GET['id'] ) > 0 ) 
			{
				if( count( $_SESSION['modules']['patch_data']['tables'][$_GET['id']]['schema'] ) > 0 && strlen($_GET['id']) > 0 ) 
				{
					$this->SchemaRow( $_SESSION['modules']['patch_data']['tables'][$_GET['id']] );
				}
			} // end if-stack
			?>
			</tbody>
		</table>
		<?php
		$this->GridFooter();

		if( $_GET['id'] > 0 ) 
		{
			$next_version = $this->GetMaxSchemaVersion() + 1;
			$header_text = sprintf("existing `%s`", $_SESSION['modules']['patch_data']['tables'][$_GET['id']]['name']);
			$new_display = ' style="display:none;"';
			?>
			<br />
			<div id="section">
				<ul style="margin-left:0px;">
					<li class="section-title">Add New Table Schema Changes</li>
				</ul>
			</div>
			<table class="table1 responsive">
				<tr>
					<td><p class="status">ADDING SCHEMA CHANGE TO <?php print($header_text) ?> TABLE</p></td>
				</tr>
				<?php /*?><tr>
					<td style="font-size:1.2em;">
						<strong>Special Instructions:</strong> When submitting new table schema or changes, there are a few very important rules to follow --<br>
						<ul>
							<li><strong>All queries must be for the selected table name!</strong> You cannot mix table names in a query</li><br />
							<li>Tables with foreign key constraints should have their constraints dropped before an ALTER, then re-applied after the ALTER, if the update pertains to the FK itself</li><br />
							<li>New schema changes can be UPDATEd or DELETEd until they are COMMITted; after that, the only way to change it is to submit another schema change</li><br />
							<li>The &quot;VERSION&quot; generated after your commit is the EQ2_DB_VERSION you must set in version.h to receive the new schema (or it's data)<br><br />
							<em>Each table commit should be a new DB Version</em>. The only time multiple changes are the same version is with BULK UPDATES by the Administrator</li><br />
						</ul>
					</td>
				</tr><?php */?>
			</table>
			<br />
			<table class="table1 responsive">
				<col width="100" />
				<col />
				<form method="post" name="schema_add">
				<?php /*?><tr<?php print( $new_display ) // hide the New options if we selected a table to modify ?>>
					<td align="right"><strong>Table:</strong></td>
					<td><input type="text" name="new_table_name" value="" id="newtable" /> [enter new table name here]</td>
				</tr><?php */?>
				<tr>
					<td align="right"><strong>Query:</strong></td>
					<td><strong>The only thing allowed here are CREATE, ALTER, DROP queries!</strong><br>
						<textarea name="query" id="query" rows="15" cols="76" class="inputbox" wrap="off"></textarea>
					</td>
				</tr>
				<tr>
					<td align="right"><strong>New Version:</strong></td>
					<td><?php print($next_version) ?></td>
				</tr>
				<?php if( $this->mode === 0 ) { ?>
				<tr>
					<td colspan="2">Temp Tools:<br />
					Last Updated: <input type="text" name="last_updated" value="<?php print( $this->temp_date_str ) ?>" /><br />
					By: <input type="text" name="submitted_by" value="<?php print( $this->temp_user_str ) ?>" /><br />
					Rev: <input type="text" name="svn_rev" value="<?php print( $this->temp_rev_str ) ?>" /><br /></td>
				</tr>
				<?php } ?>
				<tr>
					<td colspan="2" align="center"><input type="submit" name="cmd" value="Add" /></td>
				</tr>
				<input type="hidden" name="table_name" value="<?php print( $_SESSION['modules']['patch_data']['tables'][$_GET['id']]['name'] ); ?>" />
				<input type="hidden" name="next_version" value="<?php print( $next_version ) ?>" />
				<input type="hidden" name="date_created" value="<?php print( $this->temp_date_str ) ?>" />
				<?php if( $this->mode === 1 ) { ?>
				<!-- work these into the new page design -->
				<input type="hidden" name="last_updated" value="<?php print( $this->temp_date_str ) ?>" />
				<input type="hidden" name="submitted_by" value="<?php print( $this->temp_user_str ) ?>" />
				<input type="hidden" name="svn_rev" value="<?php print( intval($this->temp_rev_str) ) ?>" />
				<!-- -->
				<?php } ?>
				</form>
			</table>	
			<?php
		} // end if id
	}
	
	
	// displays all the schema records for 1 table (at a time)
	// also handles id=commit, which only shows records for uncommitted changes
	private function SchemaRow( $table ) 
	{
		$table_name = $table['name'];
		$table_schema_array = $table['schema'];
		$table_data_array = $table['data'];
		
		// if the user selected SHOW UNCOMMITTED, then skip display of any tablle schemas that are commit==1
		$skip_committed = ( strcmp( $_GET['id'], "commit" ) === 0 ) ? true : false;
		
		foreach( $table_schema_array as $data ) 
		{
			if( $skip_committed && intval( $data['committed'] ) === 1 )
				continue;
				
			$disable_update = ' disabled title="Table must be committed before max_data_version can be set"';
			$last_updated = ( intval( $data['last_updated'] ) > 0 ) ? date( "l, F d, Y g:i:s A", $data['last_updated'] ) : date( "l, F d, Y g:i:s A", $data['date_created'] );
			?>
			<form method="post" name="versions_<?php print( $data['id'] ); ?>">
			<tr>
				<td>
					Table: <strong><?php print( $table_name ) ?></strong> (table_id: <?php print( $data['table_id'] ) ?>)<br />Last updated: <?php print( $last_updated ) ?>, by <?php print( $data['submitted_by'] ) ?>, for rev <?php print( $data['svn_rev'] ) ?><br />
					<textarea name="query" id="query" class="inputbox" wrap="off"><?php print( $data['query'] ) ?></textarea>
				</td>
				<td align="center"><?php print( $data['version'] ); ?></td>
				<td align="center">
					<input type="submit" name="cmd" value="Set"<?php if( $data['committed'] == 0 ) print(' disabled') ?> />
					<select name="max_data_version">
						<option value="NULL"<?php if( strlen($data['max_data_version']) == 0 ) print(' selected') ?>>Disabled</option>
						<option value="0"<?php if( $data['max_data_version'] == '0' ) print(' selected') ?>>Infinite</option>
						<?php 
						// read table_data table, get all possible versions for this table and build options
						foreach($table_data_array as $table_data) {
							printf('<option%s>%s</option>', ($table_data['data_version'] == $data['max_data_version'] ) ? " selected" : "", $table_data['data_version']);
						}
						?>
					</select>
				</td>
				<td align="right">
					<?php
					if( $data['committed'] == 0 )
						print('<input type="submit" name="cmd" value="Update" /><br /><input type="submit" name="cmd" value="Delete" /><br /><input type="submit" name="cmd" value="Commit" />');
					else
						print('<strong>Committed</strong>');
					?>
				</td>
			</tr>
			<input type="hidden" name="id" value="<?php print( $data['id'] ); ?>">
			<input type="hidden" name="table_name" value="<?php print( $table_name ); ?>">
			<input type="hidden" name="version_num" value="<?php print( $data['version'] ); ?>">
			<input type="hidden" name="orig_query" value="<?php print( $data['query'] ); ?>">
			</form>
			<?php
			$this->total_count++;
		} // end foreach
	}
	

	/** Some concepts;
	  *	Offer option to SET schema max_data_version to >this ?
	  * 
	  * 
	  */
	private function Data() 
	{
		global $MOD, $user;

		switch($_POST['cmd']) 
		{
			case 'Add':
			
				$table_id = $_POST['table_id'];
				$table_name = $_POST['table_name'];
				
				// ensure it is only a INSERT, UPDATE, REPLACE or DELETE query
				if( $this->ValidateDataQuery( $_POST['data'] ) ) 
				{
					$last_updated =  ( strlen( $_POST['last_updated'] ) > 0 ) ? strtotime( $_POST['last_updated'] ) : time();
					
					// then insert the query(s)
					$this->SQLQuery = sprintf("INSERT INTO " . PATCH_DATABASE . ".table_data (table_id, data_version, data, date_created, last_updated, submitted_by, svn_rev) VALUES ('%s','%s','%s','%s','%s','%s','%s')", 
											   $table_id, 
											   $_POST['next_version'],
											   $this->SQLEscape( $_POST['data'] ),
											   $last_updated, // both date fields set to the same on Add
											   $last_updated, // if no $tmp_date_str, use now()
											   $this->SQLEscape( $_POST['submitted_by'] ),
											   $this->SQLEscape( $_POST['svn_rev'] )
											   );
					$this->RunQuery();
					
					$MOD->AddStatus("Data update for table '" . $table_name . "' submitted! QStatus: " . $this->QStatus . ", QCount: " . $this->QCount);
		
					// update log
					$log_array['log_type'] 		= 'EQ2Updates';
					$log_array['log_operation'] = 'PATCHER_DATA_ADD';
					$log_array['log_data']		= sprintf( "id:new:%s;\ntable:%s;\ndataver:%s;\nuser:%s;\nquery:%s", 
														  $this->LastInsertID, 
														  $this->SQLEscape( $table_name ),
														  $_POST['next_version'],
														  $this->SQLEscape( $user->data['username'] ),
														  $this->SQLEscape( $_POST['data'] )
														  );
					$MOD->Log( $log_array );

					$this->ResetCache();
				} 
				else 
				{
					// failed validation
					$MOD->AddStatus("Data update for table '" . $table_name . "' FAILED! QStatus: " . $this->QStatus . ", QCount: " . $this->QCount);
				}
				
				break;
			case 'Update':
			
				$table_id = $_POST['table_id'];
				$table_name = $_POST['table_name'];
				
				// re-validate query, in case update is gonna mess it up
				if( $this->ValidateDataQuery($_POST['data']) ) 
				{
					$id = $_POST['id'];
					$query_new = $_POST['data'];
					$query_old = $_POST['orig_query']; // for Log
					$data_version_to_update = $_POST['data_version'];
					
					$this->SQLQuery = sprintf("UPDATE " . PATCH_DATABASE . ".table_data SET data = '%s', last_updated = '%s' WHERE `id` = '%s'", 
											  $this->SQLEscape( $query_new ), 
											  time(), 
											  $id
											  );
					$this->RunQuery();
					
					$MOD->AddStatus("Update for table '" . $table_name . "' data version '" . $data_version_to_update. "' submitted!");
		
					// update log
					$log_array['log_type'] 		= 'EQ2Updates';
					$log_array['log_operation'] = 'PATCHER_DATA_UPDATE';
					$log_array['log_data']		= sprintf( "id:%s;\ntable:%s;\nversion:%s;\nuser:%s;\nnewval:%s\noldval:%s", 
														  $id, 
														  $this->SQLEscape( $table_name ),
														  $data_version_to_update,
														  $this->SQLEscape( $user->data['username'] ),
														  $this->SQLEscape( $query_new ),
														  $this->SQLEscape( $query_old )
														  );
					$MOD->Log( $log_array );

					$this->ResetCache();
					
				} 
				else 
				{
					$MOD->AddStatus("Data update for table '" . $table_name . "' FAILED! QStatus: " . $this->QStatus . ", QCount: " . $this->QCount);
				}
				
				break;
				
			case 'Set':
				$MOD->AddStatus("Not implemented yet.");
				/*$id = $_POST['id'];
				$table_name = $_POST['table_name'];
				$query = sprintf("UPDATE " . PATCH_DATABASE . ".table_data SET committed = 1, last_updated = '%s' WHERE `id` = '%s'", time(), $id);
				$MOD->AddDebugQuery(__FUNCTION__, $query);
				$this->db->sql_query($query);
				$MOD->AddStatus("Data changes for table '" . $table_name . "' committed! No further changes allowed.");*/
				break;
			case 'Delete':
			
				$id = $_POST['id'];
				$table_id = $_POST['table_id'];
				$table_name = $_POST['table_name'];
				$data_version_to_delete = $_POST['data_version'];
				
				$this->SQLQuery = sprintf("DELETE FROM " . PATCH_DATABASE . ".table_data WHERE `id` = '%s'", $id);
				$this->RunQuery();
				
				$MOD->AddStatus("Data changes for table '" . $table_name . "' data version '" . $data_version_to_delete . "' deleted.");
				
				// update log
				$log_array['log_type'] 		= 'EQ2Updates';
				$log_array['log_operation'] = 'PATCHER_DATA_DELETE';
				$log_array['log_data']		= sprintf( "id:%s;\ntable:%s;\nversion:%s;\nuser:%s;\nquery:%s", 
													  $id, 
													  $this->SQLEscape( $table_name ),
													  $data_version_to_delete,
													  $this->SQLEscape( $user->data['username'] ),
													  $this->SQLEscape( $_POST['data'] )
													  );
				$MOD->Log( $log_array );

				$this->ResetCache();
				
				break;
		}

		?>
		<div id="section">
			<ul style="margin-left:0px;">
				<li class="section-title">Review Existing Data Updates</li>
			</ul>
		</div>
        <table class="table1 responsive">
            <tr>
                <td colspan="3" height="30" style="text-align:center; color:#F00; font-weight:bold;"><?php print($MOD->Status) ?></td>
            </tr>
            <tr>
                <td>
                    <strong>Instructions:</strong> Use the combo box below to filter the list of data updates you wish to review --<br>
                    <ul>
                        <li>[<strong>table_name</strong>] - pick an individual table to view all of it's data updates</li><br />
                        <li>To <strong>ADD NEW</strong> or to <strong>CHANGE existing</strong> data, first pick the table to change, then use the form at the bottom of the page to submit data updates</li>
                    </ul>
                    Once you pick a table, you will see it's name, table_id, the data query and the data version that is assigned to this data update.
                    <hr />
                    Filters: 
					<select name="table_id" onChange="dosub(this.options[this.selectedIndex].value)">
                        <option value="./index.php?p=patcher&tab=data">-- Pick a Table --</option> 
                        <?php
                        foreach( $_SESSION['modules']['patch_data']['tables'] as $table ) 
						{
                            printf('<option value="./index.php?p=patcher&tab=data&id=%s"%s>%s</option>', $table['table_id'], ($_GET['id'] == $table['table_id']) ? " selected" : "", $table['name']);
                        }
                        ?>
                    </select>&nbsp;
					<?php if( strlen($_GET['id']) > 0 ) { ?>
					<select name="data_version" onChange="dosub(this.options[this.selectedIndex].value)">
                        <option value="./index.php?p=patcher&tab=data&id=<?php print( $_GET['id'] ) ?>">-- Version --</option> 
					<?php
						// always get them all, vs the filtering function below
						$table_data_array = $this->GetTableDataVersions();
                        foreach( $table_data_array as $data ) 
						{
                            printf('<option value="./index.php?p=patcher&tab=data&id=%s&v=%s"%s>%s</option>', 
								   $_GET['id'], $data['data_version'], ( $_GET['v'] == $data['data_version'] ) ? " selected" : "", $data['data_version']);
                        }
					?>
					</select>
					&nbsp;
					<?php } ?>
					<?php if( strlen($_GET['id']) > 0 && intval( $_GET['h'] ) === 0 ) { ?>
					<input type="checkbox" value="1" name="show_history" onclick="dosub('./index.php?p=patcher&tab=data&id=<?php print( $_GET['id'] ) ?>&h=1')" />&nbsp;Show All
					<?php } elseif( strlen($_GET['id']) > 0 && intval( $_GET['h'] ) === 1 ) { ?>
					<input type="checkbox" value="0" name="show_history" onclick="dosub('./index.php?p=patcher&tab=data&id=<?php print( $_GET['id'] ) ?>')" <?php if( $_GET['h'] == 1 ) print( 'checked' ) ?> />&nbsp;Hide All
					<?php } ?>
                </td>
            </tr>
        </table>
        <br />
		<?php 
		
		if( strlen( $_GET['id'] ) > 0 ) 
		{
			$table_name = $_SESSION['modules']['patch_data']['tables'][$_GET['id']]['name'];
			
			// once we pick a table, fetch all it's data updates (top 100?)
			// note if Version filter is set, the function only grabs that 1 version for display
			if( intval( $_GET['v'] ) > 0 )
			{
				$table_data_array = $this->GetTableDataVersionsByVersion( intval( $_GET['v'] ) );
			}
			else
			{
				// may not need, if this is always called above?
				//$table_data_array = $this->GetTableDataVersions();
			}
			
			$end_count = count($table_data_array);
			
			if( $end_count > 15 && intval( $_GET['h'] ) === 0 ) // arbitrary value for now
			{
				$start_count = $end_count - 1;
			}
			else
			{
				$start_count = 0;
			}
			
			
			if( $end_count > 0 ) 
			{ 
			?>
			<table class="table1 responsive">
				<col />
				<col width="80" />
				<col width="80" /> <!-- the Delete/Commit column -->
				<thead>
					<tr>
						<th align="left">Query</th>
						<th>DataVer</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody class="version">
				<?php
				for( $i = $start_count; $i < $end_count; $i++ )
				{
					$data = $table_data_array[$i];
					$last_updated = ( intval( $data['last_updated'] ) > 0 ) ? date( "l, F d, Y g:i:s A", $data['last_updated'] ) : date( "l, F d, Y g:i:s A", $data['date_created'] );
				?>
					<form method="post" name="data_<?php print( $data['id'] ); ?>">
					<tr>
						<td>
							Table: <strong><?php print( $table_name ) ?></strong> (table_id: <?php print( $data['table_id'] ) ?>)<br />Last updated: <?php print( $last_updated ) ?>, by <?php print( $data['submitted_by'] ) ?>, for rev <?php print( $data['svn_rev'] ) ?><br />
							<textarea name="data" id="data" class="inputbox" wrap="off" style="min-height:100px;"><?php print( $data['data'] );  ?></textarea>
						</td>
						<td align="center"><?php print( $data['data_version'] ) ?></td>
						<td align="right">
							<?php
							if( $data['committed'] == 0 ) 
							{
								print('<input type="submit" name="cmd" value="Update" /><br /><input type="submit" name="cmd" value="Delete" />');
								//print('<br /><input type="submit" name="cmd" value="Set" title="Set latest version of this table to this max_data_version?" />');
							}
							else
							{
								print('<strong>Committed</strong>');
							}
							?>
						</td>
					</tr>
					<input type="hidden" name="id" value="<?php print( $data['id'] ); ?>">
					<input type="hidden" name="table_name" value="<?php print( $_SESSION['modules']['patch_data']['tables'][$data['table_id']]['name'] ); ?>" />
					<input type="hidden" name="table_id" value="<?php print( $data['table_id'] ); ?>" />
					<input type="hidden" name="data_version" value="<?php print( $data['data_version'] ); ?>" />
					<input type="hidden" name="orig_query" value="<?php print( $data['data'] ); ?>" />
					</form>
					<?php
					$this->total_count++;
				} // end for
				?>
				</tbody>
			</table>
			<?php
			$this->GridFooter(); 
			} // end if end count
			
			$next_version = $this->GetMaxDataVersion() + 1;
			$header_text = sprintf("existing `%s`", $table_name);
			?>
			<div id="section">
				<ul style="margin-left:0px;">
					<li class="section-title">Add New Table Data Updates</li>
				</ul>
			</div>
			<table class="table1 responsive">
				<tbody class="version">
					<tr>
						<td><p class="status">INSERT/UPDATE/DELETE/REPLACE/TRUNCATE DATA TO <?php print($header_text) ?> TABLE</p></td>
					</tr>
					<tr>
						<td>
							<strong>Special Instructions:</strong> When submitting table data changes, there are a few very important rules to follow --<br>
							<ul>
								<li><strong>All queries must be for the selected table name!</strong> You cannot mix table names in a query</li><br />
								<li>New queries can be UPDATEd or DELETEd, but there is no tracking of old/new changes - data is too big, most times</li><br />
								<li>The &quot;VERSION&quot; generated after your commit is the MAX DATA VERSION you can set in the Schema (table) editor</li>
							</ul>
						</td>
					</tr>
				</tbody>
			</table>
			<br />
			<table class="table1 responsive">
				<col />
				<col width="80" />
				<col width="80" /> <!-- the Delete/Commit column -->
				<thead>
					<tr>
						<th align="left">Query</th>
						<th>DataVer</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody class="version">
					<form method="post">
					<tr>
						<td>Table: <strong><?php print( $table_name ) ?></strong> (table_id: <?php print( $data['table_id'] ) ?>)<br />
							<strong>The only thing allowed here are INSERT, UPDATE, DELETE, REPLACE and TRUNCATE queries!</strong><br>
							<textarea name="data" id="newdata" rows="15" cols="76" class="inputbox" wrap="off"></textarea>
							<p id="message"></p>
						</td>
						<td align="center"><?php print( $next_version ) ?></td>
						<td align="right"><input type="submit" name="cmd" value="Add" id="add_data" style="visibility: hidden;" /><?php /*?> need the id/style for the validation text <?php */?></td>
					</tr>
					<?php if( $this->mode === 0 ) { ?>
					<tr>
						<td colspan="2">Temp Tools:<br />
						Last Updated: <input type="text" name="last_updated" value="<?php print( $this->temp_date_str ) ?>" /><br />
						By: <input type="text" name="submitted_by" value="<?php print( $this->temp_user_str ) ?>" /><br />
						Rev: <input type="text" name="svn_rev" value="<?php print( $this->temp_rev_str ) ?>" /><br /></td>
					</tr>
					<?php } ?>
					<tr>
						<td colspan="2" align="center"></td>
					</tr>
					<input type="hidden" name="next_version" value="<?php print( $next_version ) ?>" />
					<input type="hidden" name="table_name" value="<?php print( $table_name ) ?>" />
					<input type="hidden" name="table_id" value="<?php print( $_GET['id'] ); ?>" />
					<?php if( $this->mode === 1 ) { ?>
					<!-- work these into the new page design -->
					<input type="hidden" name="last_updated" value="<?php print( $this->temp_date_str ) ?>" />
					<input type="hidden" name="submitted_by" value="<?php print( $this->temp_user_str ) ?>" />
					<input type="hidden" name="svn_rev" value="<?php print( intval($this->temp_rev_str) ) ?>" />
					<!-- -->
					<?php } ?>
					</form>
				</tbody>
				<script language="javascript">
				<!--
				<?php /*?> this is such a cool script!! >:D <?php */?>
				var area = document.getElementById("newdata");
				var message = document.getElementById("message");
				var maxLength = <?php print( intval($_SESSION['modules']['config']['max_textarea_length']) ); ?>;
				var checkLength = function() {
					if(area.value.length <= maxLength) {
						message.innerHTML = (maxLength-area.value.length) + " characters remaining";
						area.style.backgroundColor='#FFFFFF';
						document.getElementById("add_data").style.visibility = 'visible';
					} else {
						message.innerHTML = "QUERY TOO LONG! Must be less than " + <?php print( intval($_SESSION['modules']['config']['max_textarea_length']) ); ?> + " characters! (length: " + area.value.length + ")";
						area.style.backgroundColor='#FFCCCC';
						document.getElementById("add_data").style.visibility = 'hidden';
					}
				}
				setInterval(checkLength, 300);
				-->
				</script>
			</table>
			<?php
			
			
		}
		
		if( $_GET['id'] > 0 ) 
		{
		} // end if
	}
	

	private function Sessions() 
	{
		global $MOD, $user;
		
		switch( $_POST['cmd'] ) 
		{
			case "Clear All":
				
				$this->SQLQuery = "TRUNCATE TABLE " . PATCH_DATABASE . ".sessions";
				$this->RunQuery();
			
				// update log
				$log_array['log_type'] 		= 'EQ2Updates';
				$log_array['log_operation'] = 'PATCHER_SESSIONS_CLEAR';
				$log_array['log_data']		= sprintf( "user:%s", $user->data['username'] );
				$MOD->Log( $log_array );
				
				break;
		}

		$this->SQLQuery = "SELECT * FROM " . PATCH_DATABASE . ".sessions";
		$sessions = $this->RunQueryMulti();
		
		?>
		<table class="table1 responsive">
			<thead>
				<tr>
					<td colspan="6" height="30" style="font-size:1.2em;">Current active sessions on Patch Server</td>
				</tr>
				<tr>
					<th align="left">session_id</th>
					<th align="left">ip</th>
					<th align="left">login</th>
					<th align="left">logout</th>
					<th align="left">download</th>
					<th width="20%">&nbsp;</th>
				</tr>
			</thead>
			<?php 
			if( is_array($sessions) ) {
				foreach( $sessions as $data ) {
					// do we want to be able to delete just 1 session?
				?>
				<form method="post" name="session_<?php print( $data['session_id'] ); ?>">
				<tr>
					<td><?php print( $data['session_id'] ); ?></td>
					<td><?php print( $data['ip'] ); ?></td>
					<td><?php print( date("M d, Y h:i:s", $data['login']) ); ?></td>
					<td><?php print( date("M d, Y h:i:s", $data['logout']) ); ?></td>
					<td><?php print( $data['download'] ); ?></td>
					<td>&nbsp;</td>
				</tr>
				</form>
				<?php
					$this->total_count++;
				}
				?>
                <form method="post">
                <tr>
                    <td colspan="6" align="center"><input type="submit" name="cmd" value="Clear All" />&nbsp;</td>
                </tr>
                </form>
			<?php
			}
			?>
		</table>
		<?php $this->GridFooter(); ?>
		<?php
	}
	
	
	private function Lockouts() 
	{
		global $MOD, $user;
		
		switch( $_POST['cmd'] ) 
		{
			case "Clear All":
				
				// needs to be a local var so it can be logged, since RunQuery nukes $this->SQLQuery
				$this->SQLQuery = "TRUNCATE TABLE " . PATCH_DATABASE . ".lockouts";
				$this->RunQuery();
			
				// update log
				$log_array['log_type'] 		= 'EQ2Updates';
				$log_array['log_operation'] = 'PATCHER_LOCKOUTS_CLEAR';
				$log_array['log_data']		= sprintf( "user:%s", $user->data['username'] );
				$MOD->Log( $log_array );
				
				break;
		}
		
		$this->SQLQuery = "SELECT * FROM " . PATCH_DATABASE . ".lockouts";
		$lockouts = $this->RunQueryMulti();

		?>
		<table class="table1 responsive">
			<thead>
				<tr>
					<td colspan="5" height="30" style="font-size:1.2em;">Current active lockouts on Patch Server</td>
				</tr>
				<tr>
					<th align="left">lockout_id</th>
					<th align="left">ip</th>
					<th align="left">start</th>
					<th align="left">end</th>
					<th width="30%">&nbsp;</th>
				</tr>
			</thead>
			<?php 
			if( is_array($lockouts) ) {
				foreach( $lockouts as $data ) {
					// do we want to be able to delete just 1 lockout?
				?>
				<form method="post" name="lockout_<?php print( $data['lockout_id'] ); ?>">
				<tr>
					<td><?php print( $data['lockout_id'] ); ?></td>
					<td><?php print( $data['ip'] ); ?></td>
					<td><?php print( date("M d, Y h:i:s", $data['start']) ); ?></td>
					<td><?php print( date("M d, Y h:i:s", $data['end']) ); ?></td>
					<td>&nbsp;</td>
				</tr>
				</form>
				<?php
					$this->total_count++;
				}
				?>
				<form method="post">
				<tr>
					<td colspan="5" align="center"><input type="submit" name="cmd" value="Clear All" />&nbsp;</td>
				</tr>
				</form>
				<?php
			}
			?>
		</table>
		<?php $this->GridFooter(); ?>
		<?php
	}
	
	
	private function GridFooter() {
		
		if( $this->total_count == 0 ) {
			print('<div class="row-count-dark">No records match the current criteria.&nbsp;</div>');
			return;
		} else {
			printf('<div class="row-count-dark">%s rows returned.&nbsp;</div>', $this->total_count);
		}
	}


	/**
	  * Adds necessary javascript code to the bottom of projman container
	  */
	private function Footer() {
		//This was very useful: http://stackoverflow.com/questions/21070101/show-hide-div-using-javascript
		?>
		<div class="action-bar bottom">
			<div class="pagination">&nbsp;</div>
		</div>
	<?php
	}

	
	private function ValidateSchemaQuery($query_text) {
		
		// adding option to force insert as-is, no checks
		// due to some data having semi-colons in the middle of text!!!
		//if( $_POST['force'] == 1 ) 
		//	return true;
			
		$allowed = array('CREATE','DROP','ALTER');

		// clean query of \r\n
		$pattern[0] = "/[\r\n]+/";	// remove \r\n
		$pattern[1] = "/\s\s/"; 	// remove double-spaces
		$pattern[2] = "/`\(/"; 	// remove double-spaces
		$replace[0] = "";
		$replace[1] = " ";			// replace with single space
		$replace[2] = "` {";
		$query_text = preg_replace($pattern, $replace, trim($query_text));

		// count the queries:
		$qArr = explode(';', $query_text);

		// when exploding, there's always a blank key, so for a valid submission,
		// there should be at least 2 array elements. If not, fail.
		if( count( $qArr ) < 2 ) {
			$this->QStatus = "Invalid query " . $test . ", test " . __LINE__; // invalid statement
			return false;
		}

		// if there is no semicolon, we're done.
		if( count($qArr) == 0 ) {
			$this->QStatus = "No semicolon, test " . __LINE__; // missing semi-colon
			return false;
		}
		// check last array element; should be blank (terminator)
		// if it's not, it's a query without a semi-colon
		if( strlen(end($qArr)) > 2 ) { // accounts for \r\n ?
			$this->QStatus = "Multiple query or no semicolon, test " . __LINE__; // multi-query missing semi-colon
			return false;
		}
		
		array_pop($qArr); // toss out the blank
		
		// now that we have the query(ies), roll through them to make sure they are ONLY 
		// CREATE
		// ALTER
		// DROP
		foreach( $qArr as $Query ) {
			$idx = 0;
			
			if( strlen($Query) < 2 )
				continue; // skip blanks

			$Query = trim( $Query ); // trying to handle dangling spaces
			
			$cmdArr = explode(' ', $Query);

			$test = strtoupper(trim($cmdArr[0])); //trim(substr($Query, 0, strpos($Query, " "))); // remove leading and trailing spaces

			if( !in_array($test, $allowed) ) {
				$this->QStatus = "Invalid query " . $test . ", test " . __LINE__; // invalid statement
				return false;
			}

			// test the table name
			switch(strtoupper($test)) {
				case 'CREATE': // CREATE TABLE [IF NOT EXISTS] `table`
					
					// if the first value is not CREATE, abort.
					if( strtoupper($cmdArr[0]) != "CREATE" ) {
						$this->QStatus = "Invalid query " . $test . ", test " . __LINE__; // invalid statement
						return false;
					}
					
					// now test the rest of the array
					if( strtoupper($cmdArr[2]) == "IF" ) {
						// if the third value is IF, continue.
						$idx = 5;
					} else {
						$idx = 2;
					}
					
					break;
				case 'DROP': // DROP TABLE [IF EXISTS] `table`
					
					// if the first value is not DROP, abort.
					if( strtoupper($cmdArr[0]) != "DROP" ) {
						$this->QStatus = "Invalid query " . $test . ", test " . __LINE__; // invalid statement
						return false;
					}
					
					// now test the rest of the array
					if( strtoupper($cmdArr[2]) == "IF" ) {
						// if the third value is IF, continue.
						$idx = 4;
					} else {
						$idx = 2;
					}
					
					break;
				case 'ALTER':
					$idx = 2; // ALTER `table`
					break;
				default:
					$this->QStatus = "Invalid query " . $test . ", test " . __LINE__; // invalid statement
					return false;
					break;
			}

			// finally, the table
			$table_name = $_SESSION['modules']['patch_data']['tables'][$_GET['id']]['name'];
			$tbl = str_replace("`", "", $cmdArr[$idx]);
			//printf("%s : %s<br />", $tbl, $table_name);
			if( strpos($tbl, $table_name) === false ) { // $tbl might have back ticks, it is our haystack
				//printf("%s != %s<br />result: %s", $tbl, $table_name, strpos($tbl, $table_name));
				$this->QStatus = "Invalid table name '" . $tbl . "', test " . __LINE__; // incorrect table name
				return false;
			}
		
			$this->QCount++;
		}
		
		return true;
	}


	private function ValidateDataQuery($query_text) {

		// adding option to force insert as-is, no checks
		// due to some data having semi-colons in the middle of text!!!
		if( $_POST['force'] == 1 ) 
			return true;
			
		$allowed = array('INSERT','UPDATE','DELETE','REPLACE','TRUNCATE');
		
		// clean query of \r\n
		$pattern[0] = "/[\r\n]+/";	// remove \r\n
		$pattern[1] = "/\s\s/"; 	// remove double-spaces
		$replace[0] = "";
		$replace[1] = " ";			// replace with single space
		$query_text = preg_replace($pattern, $replace, $query_text);
		
		// count the queries:
		$qArr = explode(';', $query_text);
		//var_dump($qArr); exit;
		//echo count($qArr);
		
		// if there is no semicolon, we're done.
		if( count($qArr) == 0 ) {
			$this->QStatus = "No semicolon, test " . __LINE__; // missing semi-colon
			return false;
		}
		// check last array element; should be blank (terminator)
		// if it's not, it's a query without a semi-colon
		if( strlen(end($qArr)) > 2 ) { // accounts for \r\n ?
			$this->QStatus = "Multiple query or no semicolon, test " . __LINE__; // multi-query missing semi-colon
			return false;
		}
		
		array_pop($qArr); // toss out the blank
		
		// now that we have the query(ies), roll through them to make sure they are ONLY 
		// INSERT
		// UPDATE
		// DELETE
		// REPLACE
		// TRUNCATE
		foreach( $qArr as $Query ) 
		{
			$idx = 0;
			
			$Query = trim( $Query ); // trying to handle dangling spaces
			
			if( strlen($Query) < 2 )
				continue; // skip blanks

			$cmdArr = explode(' ', $Query);
			//print_r($cmdArr);
			$test = strtoupper(trim($cmdArr[0])); //trim(substr($Query, 0, strpos($Query, " "))); // remove leading and trailing spaces

			if( !in_array($test, $allowed) ) {
				//printf("Error: '%s' not allowed<br />", $test);
				$this->QStatus = "Invalid query " . $test . ", test " . __LINE__; // invalid statement
				return false;
			}

			// test the table name
			switch(strtoupper($test)) {
				case 'REPLACE':
				case 'INSERT':
					
					// if the first value is not INSERT, abort.
					if( strtoupper($cmdArr[0]) != "INSERT" && strtoupper($cmdArr[0]) != "REPLACE" ) {
						//echo "not insert or replace";
						$this->QStatus = "Invalid query " . $test . ", test " . __LINE__; // invalid statement
						return false;
					}
					
					// now test the rest of the array
					if( strtoupper($cmdArr[1]) == "IGNORE" ) {
						// if the second value is not IGNORE, continue.
						$idx = 3;
					} elseif( strtoupper($cmdArr[1]) == "INTO" ) {
						$idx = 2;
					}
					
					break;
				case 'UPDATE':
					$idx = 1; // UPDATE `table`
					break;
				case 'TRUNCATE': // TRUNCATE TABLE `table`
				case 'DELETE':
					$idx = 2; // DELETE FROM `table`
					break;
				default:
					$this->QStatus = "Invalid query " . $test . ", test " . __LINE__; // invalid statement
					return false;
					break;
			}
			
			// finally, the table
			$table_name = $_SESSION['modules']['patch_data']['tables'][$_GET['id']]['name'];
			$tbl = $cmdArr[$idx];
			if( strpos($tbl, $table_name) === false ) { // $tbl might have back ticks, it is our haystack
				//printf("%s != %s<br />result: %s", $tbl, $table_name, strpos($tbl, $table_name));
				$this->QStatus = "Invalid table name '" . $tbl . "', test " . __LINE__; // incorrect table name
				return false;
			}
		
			$this->QCount++;
		}
		
		return true;
	}


	private function AutoBuildTables() 
	{
		global $MOD;
		
		return;
		$this->SQLQuery = "SHOW TABLES FROM vgo_world;";
		$rows = $this->RunQueryMulti();
		//print_r($rows);
		
		//include_once(PORTAL_ROOT_PATH."common/inc_footer.php");
		//exit;		
		
		foreach( $rows as $data ) 
		{
			$sql = "INSERT IGNORE INTO " . PATCH_DATABASE . ".tables (`name`,`date_created`) VALUES ('" . $data['Tables_in_vgo_world'] . "'," . time() . ");";
			$this->RunQuery($sql);
			$table_id = $this->LastInsertID;
			
			$this->SQLQuery = "SHOW CREATE TABLE vgo_world." . $data['Tables_in_vgo_world'];
			$tabledef = $this->RunQuerySingle();
			$droptable = "DROP TABLE IF EXISTS `".$data['Tables_in_vgo_world']."`;\n";
			$tsql = sprintf("INSERT INTO " . PATCH_DATABASE . ".table_versions (table_id, query, version, date_created, last_updated) VALUES ('%s','%s;','%s','%s','%s')", $table_id, $droptable.$this->SQLEscape($tabledef['Create Table']), 1, time(), time());
			$this->RunQuery($tsql);
			//printf('%s<br />', $tabledef['Create Table']);
		}
	}


	

	/**
	 * Override SQL functions from Common
	 * REALLY dislike doing it this way, but I need separate creds/servers for gameservers?
	 */
	/****************************************************************************
	 * SQL Database Functions
	 ****************************************************************************/
	private function GetBacktrace()
	{
		$output = '<div style="font-family: monospace; font-size:15px;">';
		$backtrace = debug_backtrace();
		
		// We skip the first one, because it only shows this file/function
		unset($backtrace[0]);
		
		foreach ($backtrace as $trace)
		{
			// Strip the current directory from path
			$trace['file'] = (empty($trace['file'])) ? '(not given by php)' : htmlspecialchars($trace['file']);
			$trace['line'] = (empty($trace['line'])) ? '(not given by php)' : $trace['line'];
		
			// Only show function arguments for include etc.
			// Other parameters may contain sensible information
			$argument = '';
			if (!empty($trace['args'][0]) && in_array($trace['function'], array('include', 'require', 'include_once', 'require_once')))
			{
				$argument = htmlspecialchars($trace['args'][0]);
			}
		
			$trace['class'] = (!isset($trace['class'])) ? '' : $trace['class'];
			$trace['type'] = (!isset($trace['type'])) ? '' : $trace['type'];
		
			$output .= '<br />';
			$output .= '<b>FILE:</b> ' . $trace['file'] . '<br />';
			$output .= '<b>LINE:</b> ' . ((!empty($trace['line'])) ? $trace['line'] : '') . '<br />';
		
			$output .= '<b>CALL:</b> ' . htmlspecialchars($trace['class'] . $trace['type'] . $trace['function']);
			$output .= '(' . (($argument !== '') ? "'$argument'" : '') . ')<br />';
		}
		$output .= '</div>';
		return $output;
	}


	public function DBError() {
		global $MOD;
		
		$error = $this->db->sql_error();
		?>
		<div id="error-box">
		<table cellspacing="0" align="center">
			<tr>
				<td colspan="2" class="title">SQL Error: <?php print($error['code']); ?></td>
			</tr>
			<tr>
				<td class="label">Message:</td>
				<td class="detail"><?php print($error['message']); ?></td>
			</tr>
			<tr>
				<td class="label">Trace:</td>
				<td class="detail">
					<?php 
					print($this->GetBacktrace());
					?>
				</td>
			</tr>
			<tr>
				<td class="label">Query:</td>
				<td><?php print($this->SQLQuery); ?></td>
			</tr>
		</table>
		</div>
		<?php 
		if( $_SESSION['modules']['config']['debug'] == 1 && $_SESSION['modules']['user']['id'] == 2 ) 
			$MOD->DisplayDebug();
		include(PORTAL_ROOT_PATH."common/inc_footer.php");
		die();
	}

	/* SELECT: Use this RunQuery to return a single-row result set */
	public function RunQuerySingle($sql = '') {
		global $MOD;
		
		/*** Override $this with passed parameters ***/
		if( is_null($this->SQLQuery) && strlen($sql) > 6 )
			$this->SQLQuery = $sql;
		/**********************************************/
			
		// add ; to end of query, if missing, just for logging to screen
		if( strpos($this->SQLQuery, ";") == 0 )
			$this->SQLQuery = trim($this->SQLQuery) . ";";
			
		if( $_SESSION['modules']['config']['debug'] ) {
			$start_time = time();
			$MOD->AddDebugFunction(__FUNCTION__, "Enter");
			$MOD->AddDebugQuery(__FUNCTION__, $this->SQLQuery);
		}
		
		if( !$result = $this->db->sql_query($this->SQLQuery) ) {
			$this->DBError();
		} else {
			$num_rows = $this->db->sql_affectedrows($result);
			$rtn = $this->db->sql_fetchrow($result);
		}
		
		if( $_SESSION['modules']['config']['debug'] ) {
			$MOD->AddDebugData("RunQuerySingle", $rtn);
			$MOD->AddDebugFunction(__FUNCTION__, $num_rows." row(s)");
			if( $Elapsed > 1 )
				$Exit = sprintf("Exit - Elapsed: %s<br />Slow Query: %s", $Elapsed, $this->SQLQuery);
			else
				$Exit = "Exit";
			$MOD->AddDebugFunction(__FUNCTION__, $Exit);
		}

		unset($this->SQLQuery);  // nuke the query so it isn't used again
		
		return $rtn;
	}
	
	
	/* SELECT: Use this RunQuery to return a multiple-row result set */
	public function RunQueryMulti($sql = '') {
		global $MOD;
		
		/*** Override $this with passed parameters ***/
		if( is_null($this->SQLQuery) && strlen($sql) > 6 )
			$this->SQLQuery = $sql;
		/**********************************************/
			
		// add ; to end of query, if missing, just for logging to screen
		if( strpos($this->SQLQuery, ";") == 0 )
			$this->SQLQuery = trim($this->SQLQuery) . ";";
			
		if( $_SESSION['modules']['config']['debug'] ) {
			$start_time = time();
			$MOD->AddDebugFunction(__FUNCTION__, "Enter");
			$MOD->AddDebugQuery(__FUNCTION__, $this->SQLQuery);
		}
		
		if( !$result = $this->db->sql_query($this->SQLQuery) ) {
			$this->DBError();
		} else {
			$num_rows = $this->db->sql_affectedrows($result);
			while( $data = $this->db->sql_fetchrow($result) ) 
				$rtn[] = $data;
		}
		
		if( $_SESSION['modules']['config']['debug'] ) {
			$MOD->AddDebugData("RunQueryMulti Data", $rtn);
			$MOD->AddDebugFunction(__FUNCTION__, $num_rows." row(s)");
			$Elapsed = time() - $start_time;
			if( $Elapsed > 1 )
				$Exit = sprintf("Exit - Elapsed: %s<br />Slow Query: %s", $Elapsed, $this->SQLQuery);
			else
				$Exit = "Exit";
			$MOD->AddDebugFunction(__FUNCTION__, $Exit);
		}

		unset($this->SQLQuery);  // nuke the query so it isn't used again
		
		return $rtn;
	}
	

	public function RunQuery($sql = '') {
		global $MOD;
		
		$num_rows = 0;
		
		/*** Override $this with passed parameters ***/
		if( is_null($this->SQLQuery) && strlen($sql) > 6 )
			$this->SQLQuery = $sql;
		/**********************************************/

		// Check if SQLQuery has a valid query
		if( strlen($this->SQLQuery) === 0 )
			die("Invalid SQLQuery: '" . $this->SQLQuery . "'");
			
		// this should set the QueryType always
		$this->QueryType = substr($this->SQLQuery, 0, 6);
		
		// add ; to end of query, if missing, just for logging to screen
		if( strpos($this->SQLQuery, ";") == 0 )
			$this->SQLQuery = trim($this->SQLQuery) . ";";
			
		if( $_SESSION['modules']['config']['debug'] ) {
			$start_time = time();
			$MOD->AddDebugFunction(__FUNCTION__, "Enter");
			if( $_SESSION['modules']['config']['readonly'] )
				$MOD->AddDebugQuery(__FUNCTION__, "READ-ONLY: ".$this->SQLQuery);
			else
				$MOD->AddDebugQuery(__FUNCTION__, $this->SQLQuery);
		}
		
		switch($this->QueryType) {
			
			case "SELECT":
				if( !$result=$this->db->sql_query($this->SQLQuery) )
					$this->DBError();
				else {
					// temp: checking to see if I call RunQuery directly for any select statements
					die("Do not call RunQuery for Selects directly. Use RunQuerySingle, RunQueryMulti");
					$data = $this->db->sql_fetchrow($result);
				}
					
				break;
				
			case "TRUNCA":
			case "INSERT":
			case "UPDATE":
			case "DELETE":
				if( $_SESSION['modules']['config']['readonly'] ) {
					$MOD->AddStatus("READ-ONLY MODE (".$this->QueryType.") - No data updated!", 1);
				} else {
					if( !$result = $this->db->sql_query($this->SQLQuery) )
						$this->DBError();
					else {
						$num_rows = $this->db->sql_affectedrows($result);
						
						$this->AffectedRows = $num_rows;
						$MOD->AddDebugGeneral("Affected Rows", $this->AffectedRows);
						$this->LastInsertID = $this->db->sql_nextid();
						$MOD->AddDebugGeneral("Last Insert ID", $this->LastInsertID);
					}
				}
				break;
		}
		
		if( $_SESSION['modules']['config']['debug'] )
		{
			$MOD->AddDebugData("RunQuery Data", $data);
			$MOD->AddDebugFunction(__FUNCTION__, $num_rows." row(s)");
			if( $Elapsed > 1 ) // i don't think I'm calculating Elapsed?
				$Exit = sprintf("Exit - Elapsed: %s<br />Slow Query: %s", $Elapsed, $this->SQLQuery);
			else
				$Exit = "Exit";
			$MOD->AddDebugFunction(__FUNCTION__, $Exit);
		}
		
		unset($this->QueryType); // nuke the type so it isn't used again
		unset($this->SQLQuery);  // nuke the query so it isn't used again
		
		return $num_rows;
	}

	public function LogQuery() {
		global $MOD;
		
		// Check if SQLQuery has a valid query
		if( strlen($this->SQLQuery) === 0 )
			die("Invalid SQLQuery: '" . $this->SQLQuery . "'");

			
		// add ; to end of query, if missing, just for logging to screen
		if( strpos($this->SQLQuery, ";") == 0 )
			$this->SQLQuery = trim($this->SQLQuery) . ";";
			
		if( $_SESSION['modules']['config']['debug'] ) {
			$MOD->AddDebugFunction(__FUNCTION__, "Enter");
			if( $_SESSION['modules']['config']['readonly'] )
				$MOD->AddDebugQuery(__FUNCTION__, "READ-ONLY: ".$this->SQLQuery);
			else
				$MOD->AddDebugQuery(__FUNCTION__, $this->SQLQuery);
		}
		
		if( $_SESSION['modules']['config']['readonly'] ) {
			$MOD->AddStatus("READ-ONLY MODE (".$this->QueryType.") - No data updated!", 1);
		} else {
			if( !$result = $this->db->sql_query($this->SQLQuery) )
				$this->DBError();
			// no LastInserID or AffectedRows on Log inserts!
		}
		
		if( $_SESSION['modules']['config']['debug'] )
			$MOD->AddDebugFunction(__FUNCTION__, "Exit");
		
		unset($this->QueryType); // nuke the type so it isn't used again
		unset($this->SQLQuery);  // nuke the query so it isn't used again
		
		return $num_rows;
	}

	public function GetTotalRows($database, $table) {
		$this->SQLQuery = sprintf("SELECT count(*) AS num FROM %s.%s;", $database, $table);
		$data = $this->RunQuerySingle();
		return ( !empty($data) ) ? $data['num'] : 0;
	}

	private function SQLLog() {
		global $MOD, $user;
		
		// stuff insert, update, delete queries into VGOeditor.log table
		if( $_SESSION['modules']['config']['debug'] )
			$MOD->AddDebugFunction(__FUNCTION__, "Enter");
		
		/*
		 * Logging Stuff goes Here
		 */
		if( $_SESSION['modules']['config']['sql_log'] )
		{
			$pattern[0] = "/".DEV_DB."\./i";
			$replace[0] = "";
			
			$log_query = preg_replace($pattern, $replace, $this->SQLQuery);
			
			// can't use RunQuery because we're getting the wrong LastInsertID!
			$log_insert = sprintf("INSERT INTO log (user_id, username, table_name, object_id, update_query, update_date) VALUES ('%s','%s','%s','%s','%s','%s')",
								$data->user['user_id'],
								$this->SQLEscape($data->user['username']),
								$this->SQLEscape($this->TableName),
								$this->SQLEscape($this->ObjectID),
								$this->SQLEscape($log_query),
								time());
			
			if( !$result = $this->db->sql_query($log_insert) )
				$this->DBError();
		}

		/*
		 * File Logging
		 */
		// 2016.10.23 - this needs to be refactored for portal apps
		if( $_SESSION['modules']['config']['sql_log_file'] )
		{
			$logfile = sprintf("logs/session_%s_%s_week%s.txt", 
												 strtolower($_SESSION['modules']['user']['username']), 
												 date("Y", time()), 
												 date("W", time()));

			$log_query .= "\n";
			
			if( $_SESSION['modules']['config']['readonly'] )
				$MOD->AddStatus("READ-ONLY MODE - ".$logfile." not saved!");
			else
			{
				if( file_exists($logfile) ) 
				{
					if( !$f = fopen($logfile, 'a') ) 
						die("Cannot open existing filename: $logfile");
		
					if( !fwrite($f, $log_query) )
						die("Cannot write to existing filename: $logfile");
		
					fclose($f);
				} 
				else 
				{
					if( !$f = fopen($logfile, 'x') ) 
						die("Cannot create new file: $logfile");
						
					if( !fwrite($f, $log_query) )
							die("Cannot write to new filename: $logfile");
							
					fclose($f);
				}
			}
			
		}

		if( $_SESSION['modules']['config']['debug'] )
			$MOD->AddDebugFunction(__FUNCTION__, "Exit");
	}

	public function SQLEscape($str) {
		return $this->db->sql_escape($str);
	}


	public function NoResults() {
		print("No Results in " . __FUNCTION__ . ", " . __LINE__);
	}



} // END Class

?>
