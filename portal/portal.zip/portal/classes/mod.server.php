<?php
if( !defined("IN_PORTAL") )
	die("Hacking attempt.");

define("MAX_LOGIN_HEARTBEAT", "900");
define("IMG_PATH","/portal/images/icons/");	// all icons in these modules are in this path

/**
 * TODO: Need to make this more generic, needs to work on any Emu server not just EQ2
 */
class MODServers {
	
	// public properties


	// private properties
	private $SQLQuery			= NULL;
	private $AffectedRows		= NULL;
	private $LastInsertID		= NULL;


	//
	// Constructor
	//
	public function __construct() {
		
		$this->db_host = $_SESSION['modules']['database'][1]['db_host'];
		$this->db_user = $_SESSION['modules']['database'][1]['db_user'];
		$this->db_pass = $_SESSION['modules']['database'][1]['db_pass'];
		$this->db_name = $_SESSION['modules']['database'][1]['db_name'];
		$this->db_port = $_SESSION['modules']['database'][1]['db_port'];
		
		//printf('%s, %s, %s, %s, %s', $this->db_host, $this->db_user, $this->db_pass, $this->db_name, $this->db_port);
		include_once("mysql.class.php");
		$this->db = new MODMysql($this->db_host, $this->db_user, $this->db_pass, $this->db_name, false);
	
		$this->ls_online = $this->CheckLoginServerStatus();
		
		$this->Races = $this->GetRaces();
		$this->Classes = $this->GetClasses();
	}
	
	
	/**
	 * Local function to check if loginserver heartbeat is within 'n' seconds
	 */
	private function CheckLoginServerStatus() {
		// MAX_LOGIN_HEARTBEAT value set in DEFINE at top of script
		$this->SQLQuery = sprintf("SELECT COUNT(*) AS login_active FROM ".LOGIN_DATABASE.".login_config WHERE config_name = 'login_heartbeat' AND config_value >= UNIX_TIMESTAMP(NOW()) - %s", MAX_LOGIN_HEARTBEAT);
		$result = $this->RunQuerySingle();
		return $result['login_active'];
	}


	/**
	 * Getters
	 */
	private function GetRaces() {
		global $MOD;
		
		$MOD->SQLQuery = "SELECT race_id, race_name FROM ".PORTAL_DATABASE.".eq2races ORDER BY race_id";
		$result = $MOD->RunQueryMulti();
		if( is_array($result) ) {
			foreach( $result as $race ) {
				$ret[$race['race_id']] = $race['race_name'];
			}
		}
		return $ret;
	}
	
	
	private function GetClasses() {
		global $MOD;
		
		$MOD->SQLQuery = "SELECT class_id, class_name FROM ".PORTAL_DATABASE.".eq2classes ORDER BY class_id";
		$result = $MOD->RunQueryMulti();
		if( is_array($result) ) {
			foreach( $result as $class ) {
				$ret[$class['class_id']] = $class['class_name'];
			}
		}
		return $ret;
	}


	private function GetServerList($cat) {
		$this->SQLQuery = sprintf("SELECT w.*, w.id AS world_id, s.world_status, s.current_players, s.current_zones, s.connected_time " . 
									 "FROM ".LOGIN_DATABASE.".login_worldservers w " . 
									 "LEFT JOIN ".LOGIN_DATABASE.".login_worldstats s ON w.id = s.world_id " .
									 "WHERE hide_status = 0 AND server_category = '%s' AND lastseen >= %s %s " .
									 "ORDER BY world_status DESC, w.name %s", 
											$cat,
											$this->CalcMaxHistoryLength(),
											($_SESSION['modules']['config']['hide_offline'] == 1) ? " AND (world_status <> -4 OR server_sticky = 1)" : "",
											($_SESSION['modules']['config']['max_server_display'] > 0) ? " LIMIT 0,".$_SESSION['modules']['config']['max_server_display'] : "");
		return $this->RunQueryMulti();
	}
	
	
	private function GetServer($id) {
		$this->SQLQuery = sprintf("SELECT w.*, s.world_status, s.current_players, s.current_zones, UNIX_TIMESTAMP(s.connected_time) AS uptime " . 
									 "FROM ".LOGIN_DATABASE.".login_worldservers w " . 
									 "LEFT JOIN ".LOGIN_DATABASE.".login_worldstats s ON w.id = s.world_id " .
									 "WHERE hide_status = 0 AND w.id = %s", $id);
		return $this->RunQuerySingle();
	}
	
	
	private function GetServerUpTime($server)
	{
	
		if( $server['world_status'] != 1 )
		{
			return 'N/A';
		}
		else
		{
			$time = time() - $server['uptime'];
			//echo $server['server_uptime'];
			$weeks = $time/604800;
			$days = ($time%604800)/86400;
			$hours = (($time%604800)%86400)/3600;
			$minutes = ((($time%604800)%86400)%3600)/60;
			$seconds = (((($time%604800)%86400)%3600)%60);
	
			if(intval($weeks)) 		
				$worldOnlineTime .= ( intval($weeks) > 1 )	? intval($weeks) . " Weeks " : intval($weeks) . " Week ";
				
			if(intval($days)) 		
				$worldOnlineTime .= ( intval($days)>1 ) ? intval($days) . " Days " : intval($days)	. " Day ";
				
			if(intval($hours))		
				$worldOnlineTime .= ( intval($hours)>1 ) ? intval($hours) . " Hours " : intval($hours)	. " Hour ";
				
			if(intval($minutes))	
				$worldOnlineTime .= ( intval($minutes)>1 )	? intval($minutes) . " Minutes " : intval($minutes)	. " Minute ";
				
			if( !intval($minutes) && !intval($hours) && !intval($days) ) 
				$worldOnlineTime .= " " . intval($seconds) . " Seconds";
			
			return $worldOnlineTime;
		}
	}


	private function GetServerLastPlayerSeen($server) {
		$ret = 0;
		
		$this->SQLQuery = sprintf("SELECT UNIX_TIMESTAMP(created_date) AS char_lastseen FROM login_characters WHERE id = %s ORDER BY UNIX_TIMESTAMP(created_date) DESC LIMIT 0,1", $server['id']);
		$data = $this->RunQuerySingle();
		
		if( $data['char_lastseen'] > 0 )
			$ret = date('M d, Y h:i a', $data['char_lastseen']);
		
		return $ret;
	}
	
	
	/**
	 * Counts active, deleted and a sum of the two (total) per server for display on Server Maintenance page
	 */
	private function GetCharacterCounts($serverId) {
		
		$this->SQLQuery = sprintf("SELECT COUNT(*) AS cnt FROM ".LOGIN_DATABASE.".login_characters WHERE server_id = %s GROUP BY deleted", $serverId);
		$result = $this->RunQueryMulti();
		
		if( is_array($result) ) {
			foreach( $result as $data ) {
				$tmp[] .= $data['cnt'];
			}
		}
	
		// there should be only 3 values; active, deleted, and total
		$rtn['active'] = ( $tmp[0] > 0 ) ? $tmp[0] : 0;
		$rtn['deleted'] = ( $tmp[1] > 0 ) ? $tmp[1] : 0;
		$rtn['total'] = $tmp[0] + $tmp[1];
		
		return $rtn;
	}
	
	
	private function GetPlayersOnline($id) {
		// eventually this needs to read from login_characters
		$this->SQLQuery = sprintf("SELECT characters.*, zones.id, zones.name AS zone_name FROM eq2dev.characters, eq2dev.zones WHERE characters.current_zone_id = zones.id AND is_online > 0");
		return $this->RunQueryMulti();
	}
	

	public function Status() {
		
		if( intval($_GET['id']) == 0 )
			$this->ShowServerList();
		else
			$this->ShowServerDetail();
	}


	private function ShowServerDetail() {
	
		$server = $this->GetServer($_GET['id']);
		
		if( is_array($server) ) {
			
			$server					= $this->SetServerDetails($server);
			$server['uptime']		= $this->GetServerUpTime($server);
			//$server['lastplayed']	= $this->GetServerLastPlayerSeen($server);
			$char_counts 			= $this->GetCharacterCounts($server['id']);
	
			/*if($server['id'] == 1 && $server['lastseen'] >= time() - $_SESSION['modules']['config']['max_offline_heartbeat'])
				$players_online = $this->GetPlayersOnline($server['id']);*/
		?>
		<script type="text/javascript">
			document.getElementById('server-list-server-name').innerHTML="<?php print( $server['name'] ) ?>";
		</script>
		<div id="section">
			<ul>
				<li class="section-title" style="margin-top:-3px;"><a href="index.php?p=servers" style="color:#ccc">Server List</a> &gt; Server Detail</li>
			</ul>
		</div>
		<table width="100%" border="0" id="page-body" class="post bg2">
			<tr>
				<td class="content" height="50" style="font-size:1.3em;">
					<strong>Description:</strong><br />
					<?= $server['cleanDescription'] ?>
				</td>
			</tr>
		</table>
		<div align="center" class="bg1">
		<table width="80%" border="0" class="bg1">
			<tr>
				<td colspan="2" class="Header" nowrap><?= $server['name'] ?></td>
			</tr>
			<tr>
				<td width="40%" class="Label">&nbsp;Server Name</td>
				<td class="Detail"><?= $server['name'] ?></td>
			</tr>
			<tr>
				<td class="Label">&nbsp;Server Type</td>
				<td class="Detail"><?= $server['type'] ?></td>
			</tr>
			<tr>
				<td class="Label">&nbsp;Server Version</td>
				<td class="Detail"><?= $server['login_version'] ?></td>
			</tr>
			<tr>
				<td class="Label">&nbsp;Category</td>
				<td class="Detail"><?= $server['server_category'] ?></td>
			</tr>
			<?php if( $server['hide_admin'] = 0 && strlen($server['server_admin']) > 0 ) { ?>
			<tr>
				<td class="Label">&nbsp;Server Owner</td>
				<td class="Detail"><?= $server['server_admin'] ?></td>
			</tr>
			<?php } ?>
			<?php if( strlen($server['gm_list']) > 0 ) { ?>
			<tr>
				<td class="Label">&nbsp;GMs</td>
				<td class="Detail"><?= $server['gm_list'] ?></td>
			</tr>
			<?php } ?>
			<?php if( strlen($server['server_url']) > 0 ) { ?>
			<tr>
				<td class="Label">&nbsp;Website</td>
				<td class="Detail"><a href="<?= $server['server_url'] ?>" target="_blank"><?= $server['server_url'] ?></a></td>
			</tr>
			<?php } ?>
			<?php if( strlen($server['cleanDescription']) > 0 ) { ?>
			<tr>
				<td class="Label">&nbsp;Description</td>
				<td class="Detail"><?= $server['cleanDescription'] ?></td>
			</tr>
			<?php } ?>
			<tr>
				<td colspan="2" class="Header" nowrap>Statistics</td>
			</tr>
			<tr>
				<td width="40%" class="Label">&nbsp;Server Status</td>
				<td class="Detail"><?= !empty($server['server_sticky']) ? $server['server_sticky'] : "" ?>&nbsp;<strong><font color="<?= $server['color'] ?>"><?= $server['status'] ?></font></strong></td>
			</tr>
			<tr>
				<td class="Label">&nbsp;Created Date</td>
				<td class="Detail"><?= $server['created_date'] > 0 ? date("Y-m-d", $server['created_date']) : "unknown" ?></td>
			</tr>
			<tr>
				<td class="Label">&nbsp;Last Seen Date/Time</td>
				<td class="Detail"><?= $server['lastseen'] > 0 ? date("Y-m-d h:i:s", $server['lastseen']) : "unknown" ?></td>
			</tr>
			<?php if( $server['world_status'] == 1 ) { ?>
			<tr>
				<td class="Label">&nbsp;Up Time</td>
				<td class="Detail"><?= $server['uptime'] ?></td>
			</tr>
			<tr>
				<td class="Label">&nbsp;Current Active Players</td>
				<td class="Detail"><?= ( $server['current_players'] ) ? $server['current_players'] : 0 ?></td>
			</tr>
			<tr>
				<td class="Label">&nbsp;Current Active Zones</td>
				<td class="Detail"><?= ( $server['current_zones'] ) ? $server['current_zones'] : 0 ?></td>
			</tr>
			<?php } ?>
			<!--<tr>
				<td class="Label">&nbsp;Last Player Seen</td>
				<td class="Detail"><?= $server['lastplayed'] ?> MST</td>
			</tr>-->
			<tr>
				<td class="Label">&nbsp;# Created Characters</td>
				<td class="Detail"><?= ( $char_counts['active'] ) ? $char_counts['active'] : 0 ?> (current)</td>
			</tr>
			<tr>
				<td class="Label">&nbsp;# Deleted Characters</td>
				<td class="Detail"><?= ( $char_counts['deleted'] ) ? $char_counts['deleted'] : 0 ?> (deleted)</td>
			</tr>
			<tr>
				<td class="Label">&nbsp;Total # Characters Overall</td>
				<td class="Detail"><?= ( $char_counts['total'] ) ? $char_counts['total'] : 0 ?> (total created on this world)</td>
			</tr>
		</table>
		</div>
		<br />
		<?php if( is_array($players_online) ) { ?>
		<div id="section">
			<ul>
				<li class="section-title">Players Online</li>
			</ul>
		</div>
		<div id="PlayersOnline">
			<table width="100%" border="0" id="page-body" class="bg1">
				<tr>
					<td class="titlebar" colspan="5"></td>
				</tr>
				<tr>
					<td class="eq2StatusHeader">Player Name</td>
					<td class="eq2StatusHeader">Race</td>
					<td class="eq2StatusHeader">Adventuring</td>
					<td class="eq2StatusHeader">Crafting</td>
					<td class="eq2StatusHeader">Location</td>
				</tr>
				<?php foreach($players_online as $player) { ?>
				<tr>
					<td class="eq2row">&nbsp;<?= $player['name'] ?></td>
					<td class="eq2row"><?= $this->Races[$player['race']] ?></td>
					<td class="eq2row"><?= $player['level'] ?> <?= $this->Classes[$player['class']] ?></td>
					<td class="eq2row"><?= $player['tradeskill_level'] ?> <?= $this->Classes[$player['tradeskill_class']] ?></td>
					<td class="eq2row"><?= $player['zone_name'] ?></td>
				</tr>
				<?php } ?>
				<tr>
					<td colspan="5" class="eq2footer"><?= count($players_online) ?> players found.</td>
				</tr>
			</table>
		</div>
		<?php } ?>
		<?
		}
		else
			printf("Server ID %lu - Not Found.", $_GET['id']);
	}
	
	

	private function ShowServerList() {	
	?>
	<div id="section">
		<ul>
			<li class="section-title">Server List</li>
		</ul>
	</div>
	<table width="100%" border="0" id="page-body" class="post bg1">
		<tr>
			<td class="content" height="70" style="font-size:1.2em;">
				This is a list of current EQ2Emulator servers connected to our Public Login Service. 
				Unless a server is <span style="font-weight:bold; color:#a54;">Locked</span>, anyone with a Login Account can access the server.
				To see more detailed information about a server listed here, click on it's &lt; <strong>Info</strong> &gt; link. 
			</td>
		</tr>
	</table>
	<?php 
	$serverCount = $this->DrawServerListTable('Development'); 
	$serverCount += $this->DrawServerListTable('Preferred'); 
	$serverCount += $this->DrawServerListTable('Standard'); 
	?>
	<table width="100%" align="center">
		<tr>
			<td class="field" align="center"><?php print($serverCount); ?> servers found</td>
		</tr>
		<tr>
			<td class="field" align="center"><span style="color:#888;"><?php print(($serverCount) ? sprintf('Based on last %s %s activity', $_SESSION['modules']['config']['max_history_length'], $_SESSION['modules']['config']['max_history_interval']) : 'No Servers Available'); ?></span></td>
		</tr>
	</table>
	<?php
	}
	
	
	private function DrawServerListTable($cat) {
		
		$servers = $this->GetServerList($cat);
		
		if( count($servers) > 0 ) {
		?>
			<div id="section">
				<ul>
					<li class="section-title"><?= $cat ?></li>
				</ul>
			</div>
			<table width="100%" id="ServerList" class="bg1" border="0" cellspacing="0">
				<col width="100" />
				<col width="100" />
				<col />
				<col width="100" />
				<col width="100" />
				<col width="100" />
				<tr>
					<td class="eq2StatusHeader" align="center">Info</td>
					<td class="eq2StatusHeader" align="center">Ver</td>
					<td class="eq2StatusHeader">&nbsp;Server Name</td>
					<td class="eq2StatusHeader" align="center">Type</td>
					<td class="eq2StatusHeader" align="center">Status</td>
					<td class="eq2StatusHeader" align="center">Players</td>
				</tr>
			<?php
			$i = 0;
			foreach($servers as $server) {
				
				$detail = $this->SetServerDetails($server);
				$row_class = ($i % 2) ? "bg1" : "bg2";
				
				?>

				<tr>
					<td class="Detail <?= $row_class ?>" align="center"><?= $detail['details'] ?></td>
					<td class="Detail <?= $row_class ?>" align="center"><?= $server['login_version'] ?></td>
					<td class="Detail <?= $row_class ?>">&nbsp;
						<?= $server['name'] ?>
						<?= $detail['urlLinkImage']; ?>
					</td>
					<td class="Detail <?= $row_class ?>" align="center">&nbsp;<?= $detail['type'] ?></td>
					<td class="Detail <?= $row_class ?>" align="center">&nbsp;<?= !empty($detail['sticky']) ? $detail['sticky'] : "" ?>&nbsp;<?= $detail['status'] ?></td>
					<td class="Detail <?= $row_class ?>" align="center">&nbsp;<?= $detail['current_players'] ?></td>
				</tr>

				<?php
				$i++;
			}
			?>
				<tr>
					<td colspan="6" height="12"></td>
				</tr>
			</table>
			<?php
		}
		return $i;
	}
	
	
	function SetServerDetails($server)
	{
		global $MOD;
		
		$current_status = ( $this->ls_online == 1 ) ? $server['world_status'] : -4;
		switch($current_status)
		{
					case NULL:
					case "-4":
						$worldColor		= 'high.png'; // offline
						$worldStatus 	= sprintf('Offline since %s', date("Y/m/d h:i a", $server['lastseen']));
						break;
					case "-2":
						$worldColor = "locked.png";
						$worldStatus 	= 'Private';
						break;
					default:
						$worldColor = "low.png"; // online
						$worldStatus 	= 'Low';
						break;
		}
	
		switch($server['server_type'])
		{
			case 1:
				$server['type'] = "PvP";
				break;
			case 2:
				$server['type'] = "RP";
				break;
			case 3:
				$server['type'] = "PvE/RP";
				break;
			case 4:
				$server['type'] = "PvP/RP";
				break;
			case 5:
				$server['type'] = "PvP/Teams";
				break;
			case 6:
				$server['type'] = "Pvt";
				break;
			case 7:
				$server['type'] = "Dev";
				break;
			case 8:
				$server['type'] = "Other";
				break;
			case 9:
				$server['type'] = "iPvP";
				break;
			default:
				$server['type'] = "PvE";
				break;
		}

		$server['status'] = sprintf('<img src="%s" width="15" border="0" title="%s" />',IMG_PATH.$worldColor, $worldStatus);
		$server['sticky'] = ( $server['server_sticky'] == 1 ) ? sprintf('<img src="%ssticky.png" width="15" border="0" title="Stickied" />', IMG_PATH) : "";
		$server['cleanDescription'] = $server['description'];
		$server['description'] = (strlen($server['description']) > 40) ? substr($server['description'],0,40)."..." : $server['description'];
		if( $server['hide_details']==0 )
			$server['details'] = sprintf('&lt; <a href="%s&id=%s" title="Click to see server details!" target="_self"><strong>Info</strong></a> &gt;', $MOD->Link, $server['world_id']);
		else
			$server['details'] = '&lt; N/A &gt;';
		if( $server['hide_details']==0 && substr($server['server_url'],0,7) == 'http://' )
			$server['urlLinkImage'] = sprintf('<a href="%s" title="Click to go to server home page!" target="_blank"><img src="%slink.png" width="10" height="10" border="0"></a>', $server['server_url'], IMG_PATH);
		$server['current_players'] = ( intval($server['current_players']) > 0 ) ? $row['current_players'] : 0;
		
		return $server;
	}
	
	
	private function CalcMaxHistoryLength() {
		// first, set some defaults - just in case
		if( strlen($_SESSION['modules']['config']['max_history_interval']) > 0 )
			$interval = $_SESSION['modules']['config']['max_history_interval'];
		else
			$interval = "days";
			
		if( intval($_SESSION['modules']['config']['max_history_length']) > 0 )
			$length = $_SESSION['modules']['config']['max_history_length'];
		else
			$length = 7;
			
	
		switch($interval) {
			case "days": 
				$max_history_time = 60 * 60 * 24 * $length;
				break;
	
			case "weeks": 
				$max_history_time = 60 * 60 * 24 * 7 * $length;
				break;
	
			case "months": 
				$max_history_time = 60 * 60 * 24 * 30 * $length;
				break;
	
			case "years": 
				$max_history_time = 60 * 60 * 24 * 365 * $length;
				break;
			
			default:
				$max_history_time = 0;
				break;
		}
		
		return time() - $max_history_time;
	}
	
	

	/**
	 * Override SQL functions from Common
	 * REALLY dislike doing it this way, but I need separate creds/servers for gameservers?
	 */
	/****************************************************************************
	 * SQL Database Functions
	 ****************************************************************************/
	public function DBError() {
		global $MOD;
		
		$error = $this->db->sql_error();
		?>
		<div id="error-box">
		<table cellspacing="0" align="center">
			<tr>
				<td colspan="2" class="title">SQL Error: <?php print($error['code']); ?></td>
			</tr>
			<tr>
				<td class="label">Message:</td>
				<td class="detail"><?php print($error['message']); ?></td>
			</tr>
			<tr>
				<td class="label">Trace:</td>
				<td class="detail">
					<?php 
					print($this->GetBacktrace());
					?>
				</td>
			</tr>
			<tr>
				<td class="label">Query:</td>
				<td><?php print($this->SQLQuery); ?></td>
			</tr>
		</table>
		</div>
		<?php 
		if( $_SESSION['modules']['config']['debug'] == 1 && $_SESSION['modules']['user']['id'] == 2 ) 
			$MOD->DisplayDebug();
		include("../common/inc_footer.php");
		die();
	}

	/* SELECT: Use this RunQuery to return a single-row result set */
	public function RunQuerySingle($sql = '') {
		global $MOD;
		
		/*** Override $this with passed parameters ***/
		if( is_null($this->SQLQuery) && strlen($sql) > 6 )
			$this->SQLQuery = $sql;
		/**********************************************/
			
		// add ; to end of query, if missing, just for logging to screen
		if( strpos($this->SQLQuery, ";") == 0 )
			$this->SQLQuery = trim($this->SQLQuery) . ";";
			
		if( $_SESSION['modules']['config']['debug'] ) {
			$start_time = time();
			$MOD->AddDebugFunction(__FUNCTION__, "Enter");
			$MOD->AddDebugQuery(__FUNCTION__, $this->SQLQuery);
		}
		
		if( !$result = $this->db->sql_query($this->SQLQuery) ) {
			$this->DBError();
		} else {
			// 2015.04.11 - build a list of column names retrieved
			/*$num_fields = $this->db->sql_numfields($result);
			if( $num_fields > 0 ) {
				for( $i=0; $i < $num_fields; $i++)
					$this->ColumnNames[] = $this->db->sql_fieldname($i, $result);
			}*/
			
			$num_rows = $this->db->sql_affectedrows($result);
			$rtn = $this->db->sql_fetchrow($result);
		}
		
		if( $_SESSION['modules']['config']['debug'] ) {
			$MOD->AddDebugData("RunQuerySingle", $rtn);
			$MOD->AddDebugFunction(__FUNCTION__, $num_rows." row(s)");
			if( $Elapsed > 1 )
				$Exit = sprintf("Exit - Elapsed: %s<br />Slow Query: %s", $Elapsed, $this->SQLQuery);
			else
				$Exit = "Exit";
			$MOD->AddDebugFunction(__FUNCTION__, $Exit);
		}

		unset($this->SQLQuery);  // nuke the query so it isn't used again
		
		return $rtn;
	}
	
	
	/* SELECT: Use this RunQuery to return a multiple-row result set */
	public function RunQueryMulti($sql = '') {
		global $MOD;
		
		/*** Override $this with passed parameters ***/
		if( is_null($this->SQLQuery) && strlen($sql) > 6 )
			$this->SQLQuery = $sql;
		/**********************************************/
			
		// add ; to end of query, if missing, just for logging to screen
		if( strpos($this->SQLQuery, ";") == 0 )
			$this->SQLQuery = trim($this->SQLQuery) . ";";
			
		if( $_SESSION['modules']['config']['debug'] ) {
			$start_time = time();
			$MOD->AddDebugFunction(__FUNCTION__, "Enter");
			$MOD->AddDebugQuery(__FUNCTION__, $this->SQLQuery);
		}
		
		if( !$result = $this->db->sql_query($this->SQLQuery) ) {
			$this->DBError();
		} else {
			// 2015.04.11 - build a list of column names retrieved
			// 2016.10.11 - phpBB3.1 no longer supports numfields
			/*$num_fields = $this->db->sql_numfields($result);
			if( $num_fields > 0 ) {
				for( $i=0; $i < $num_fields; $i++)
					$this->ColumnNames[] = $this->db->sql_fieldname($i, $result);
			}*/
			
			$num_rows = $this->db->sql_affectedrows($result);
			while( $data = $this->db->sql_fetchrow($result) ) 
				$rtn[] = $data;
		}
		
		if( $_SESSION['modules']['config']['debug'] ) {
			$MOD->AddDebugData("RunQueryMulti Data", $rtn);
			$MOD->AddDebugFunction(__FUNCTION__, $num_rows." row(s)");
			$Elapsed = time() - $start_time;
			if( $Elapsed > 1 )
				$Exit = sprintf("Exit - Elapsed: %s<br />Slow Query: %s", $Elapsed, $this->SQLQuery);
			else
				$Exit = "Exit";
			$MOD->AddDebugFunction(__FUNCTION__, $Exit);
		}

		unset($this->SQLQuery);  // nuke the query so it isn't used again
		
		return $rtn;
	}
	

	public function RunQuery($sql = '') {
		global $MOD;
		
		$num_rows = 0;
		
		/*** Override $this with passed parameters ***/
		if( is_null($this->SQLQuery) && strlen($sql) > 6 )
			$this->SQLQuery = $sql;
		/**********************************************/

		// Check if SQLQuery has a valid query
		if( strlen($this->SQLQuery) === 0 )
			die("Invalid SQLQuery: '" . $this->SQLQuery . "'");
			
		// this should set the QueryType always
		$this->QueryType = substr($this->SQLQuery, 0, 6);
		
		// add ; to end of query, if missing, just for logging to screen
		if( strpos($this->SQLQuery, ";") == 0 )
			$this->SQLQuery = trim($this->SQLQuery) . ";";
			
		if( $_SESSION['modules']['config']['debug'] ) {
			$start_time = time();
			$MOD->AddDebugFunction(__FUNCTION__, "Enter");
			if( $_SESSION['modules']['config']['readonly'] )
				$MOD->AddDebugQuery(__FUNCTION__, "READ-ONLY: ".$this->SQLQuery);
			else
				$MOD->AddDebugQuery(__FUNCTION__, $this->SQLQuery);
		}
		
		switch($this->QueryType) {
			
			case "SELECT":
				if( !$result=$this->db->sql_query($this->SQLQuery) )
					$this->DBError();
				else {
					// temp: checking to see if I call RunQuery directly for any select statements
					die("Do not call RunQuery for Selects directly. Use RunQuerySingle, RunQueryMulti");
					$data = $this->db->sql_fetchrow($result);
				}
					
				break;
				
			case "INSERT":
			case "UPDATE":
			case "DELETE":
				if( $_SESSION['modules']['config']['readonly'] ) {
					$MOD->AddStatus("READ-ONLY MODE (".$this->QueryType.") - No data updated!");
				} else {
					if( !$result = $this->db->sql_query($this->SQLQuery) )
						$this->DBError();
					else {
						$num_rows = $this->db->sql_affectedrows($result);
						
						$this->AffectedRows = $num_rows;
						$MOD->AddDebugGeneral("Affected Rows", $this->AffectedRows);
						$this->LastInsertID = $this->db->sql_nextid();
						$MOD->AddDebugGeneral("Last Insert ID", $this->LastInsertID);
					}
				}
				break;
		}
		
		if( $_SESSION['modules']['config']['debug'] )
		{
			$MOD->AddDebugData("RunQuery Data", $data);
			$MOD->AddDebugFunction(__FUNCTION__, $num_rows." row(s)");
			if( $Elapsed > 1 ) // i don't think I'm calculating Elapsed?
				$Exit = sprintf("Exit - Elapsed: %s<br />Slow Query: %s", $Elapsed, $this->SQLQuery);
			else
				$Exit = "Exit";
			$MOD->AddDebugFunction(__FUNCTION__, $Exit);
		}
		
		unset($this->QueryType); // nuke the type so it isn't used again
		unset($this->SQLQuery);  // nuke the query so it isn't used again
		
		return $num_rows;
	}

	public function LogQuery() {
		global $MOD;
		
		// Check if SQLQuery has a valid query
		if( strlen($this->SQLQuery) === 0 )
			die("Invalid SQLQuery: '" . $this->SQLQuery . "'");
			
		// add ; to end of query, if missing, just for logging to screen
		if( strpos($this->SQLQuery, ";") == 0 )
			$this->SQLQuery = trim($this->SQLQuery) . ";";
			
		if( $_SESSION['modules']['config']['debug'] ) {
			$MOD->AddDebugFunction(__FUNCTION__, "Enter");
			if( $_SESSION['modules']['config']['readonly'] )
				$MOD->AddDebugQuery(__FUNCTION__, "READ-ONLY: ".$this->SQLQuery);
			else
				$MOD->AddDebugQuery(__FUNCTION__, $this->SQLQuery);
		}
		
		if( $_SESSION['modules']['config']['readonly'] ) {
			$MOD->AddStatus("READ-ONLY MODE (".$this->QueryType.") - No data updated!");
		} else {
			if( !$result = $this->db->sql_query($this->SQLQuery) )
				$this->DBError();
			// no LastInserID or AffectedRows on Log inserts!
		}
		
		if( $_SESSION['modules']['config']['debug'] )
			$MOD->AddDebugFunction(__FUNCTION__, "Exit");
		
		unset($this->QueryType); // nuke the type so it isn't used again
		unset($this->SQLQuery);  // nuke the query so it isn't used again
		
		return $num_rows;
	}

	public function GetTotalRows($database, $table) {
		$this->SQLQuery = sprintf("SELECT count(*) AS num FROM %s.%s;", $database, $table);
		$data = $this->RunQuerySingle();
		return ( !empty($data) ) ? $data['num'] : 0;
	}

	private function SQLLog() {
		global $MOD, $user;
		
		// stuff insert, update, delete queries into VGOeditor.log table
		if( $_SESSION['modules']['config']['debug'] )
			$MOD->AddDebugFunction(__FUNCTION__, "Enter");
		
		/*
		 * Logging Stuff goes Here
		 */
		if( $_SESSION['modules']['config']['sql_log'] )
		{
			$pattern[0] = "/".DEV_DB."\./i";
			$replace[0] = "";
			
			$log_query = preg_replace($pattern, $replace, $this->SQLQuery);
			
			// can't use RunQuery because we're getting the wrong LastInsertID!
			$log_insert = sprintf("INSERT INTO log (user_id, username, table_name, object_id, update_query, update_date) VALUES ('%s','%s','%s','%s','%s','%s')",
								$data->user['user_id'],
								$this->SQLEscape($data->user['username']),
								$this->SQLEscape($this->TableName),
								$this->SQLEscape($this->ObjectID),
								$this->SQLEscape($log_query),
								time());
			
			if( !$result = $this->db->sql_query($log_insert) )
				$this->DBError();
		}

		/*
		 * File Logging
		 */
		// 2016.10.23 - this needs to be refactored for portal apps
		if( $_SESSION['modules']['config']['sql_log_file'] )
		{
			$logfile = sprintf("logs/session_%s_%s_week%s.txt", 
												 strtolower($_SESSION['modules']['user']['username']), 
												 date("Y", time()), 
												 date("W", time()));

			$log_query .= "\n";
			
			if( $_SESSION['modules']['config']['readonly'] )
				$MOD->AddStatus("READ-ONLY MODE - ".$logfile." not saved!");
			else
			{
				if( file_exists($logfile) ) 
				{
					if( !$f = fopen($logfile, 'a') ) 
						die("Cannot open existing filename: $logfile");
		
					if( !fwrite($f, $log_query) )
						die("Cannot write to existing filename: $logfile");
		
					fclose($f);
				} 
				else 
				{
					if( !$f = fopen($logfile, 'x') ) 
						die("Cannot create new file: $logfile");
						
					if( !fwrite($f, $log_query) )
							die("Cannot write to new filename: $logfile");
							
					fclose($f);
				}
			}
			
		}

		if( $_SESSION['modules']['config']['debug'] )
			$MOD->AddDebugFunction(__FUNCTION__, "Exit");
	}

	public function SQLEscape($str) {
		return $this->db->sql_escape($str);
	}


	public function NoResults() {
		print("No Results in " . __FUNCTION__ . ", " . __LINE__);
	}

	
	
	
} // END Class
?>
