<?php
if( !defined("IN_PORTAL") )
	die("Hacking attempt.");

if(!defined("MODCLS_LAYER")) {
define("MODCLS_LAYER","MODCls");

class MODCls {
	
	// public properties
	
	// private properties
	
	//
	// Constructor
	//
	public function __construct() {

	}
	
	public function _halt() {
		die("<p>Dev Debugging, please stand by...</p>");
	}
	
	// $data is the form, $type is what filter set to work with
	public function SetFilters($data, $type) {
		
	}
	
	// $type is what filter set to work with
	public function GetFilters($type) {

		return $filters;
	}
	
} // END Class

} // END Define
?>