<?php
if( !defined("IN_PORTAL") )
	die("Hacking attempt.");

/**
 * TODO:
 * Group all Public/Private functions together
 * Set up class properties so we're not having to pass tons of vars around (wip)
 */

class MODProjman {
	
	// private properties
	private $Stage 		= array("1-Discovery","2-Design","3-Development","4-Testing","5-Completed");
	private $Priority 	= array("1-Immediate","2-Critical","3-Medium","4-Low","5-Cosmetic");
	private $Toggles 	= array('pm_attention', 'pm_dependency');

	private $Filters	= array();
	private $Category	= array();
	private $System		= array();
	private $Subsystem	= array();
	private $StatusData = array();
	private $ForumPath 	= "../set_me/";

	// used as selected properties
	private $selected_category 	= NULL;
	private $selected_system 	= NULL;
	private $selected_subsystem = NULL;
	private $row_count			= 0;
	private $total_count		= 0;
	private $max_cache_time		= 900; // # of seconds until cache expires

	//
	// Constructor
	//
	public function __construct() {
		global $MOD, $phpbb_root_path;
		
		$this->is_admin 	= $MOD->is_admin;
		$this->is_dev 		= $MOD->is_dev;
		$this->is_team 		= $MOD->is_team;
		
		$this->ForumPath	= $phpbb_root_path; // set the path to the forums for linking to posts
		
		// TODO: move to cache
		$this->Category 	= $MOD->GetEnum('eq2emuweb_portal', 'project_manager', 'pm_category');
		$this->System		= $this->GetSystems();
		$this->Subsystem	= $this->GetSubsystems();
		$this->Assignee		= $MOD->GetAssignee();
		
		$this->CacheStats();
		
	}


	/****************************************************************************
	 * ProjMan-specific Functions
	 ****************************************************************************/
	
	/**
	 *
	 * Called from the constructor, this function sets the $_SESSION stats for categories 
	 * and system/subsystems so there are not hundreds of hits to MySQL to count progress
	 * stats
	 * 
	 * This is on a cache timer, and refreshes every $this->max_cache_time, or whenever a
	 * task completion percentage changes
	 *
	 */
	private function CacheStats() {
		global $MOD;
		
		
		if( count($_SESSION['pm_stats']) == 0 || $_SESSION['pm_stats']['cachetime'] <= (time() - $this->max_cache_time) ) {
			unset($_SESSION['pm_stats']); // clear previous values
			$_SESSION['pm_stats']['cachetime'] = time();
			// build Category stats
			foreach( $this->Category as $cat ) {
				$MOD->SQLQuery = sprintf("SELECT (SUM(pm_dev_percent) / COUNT(*)) AS Dev, (SUM(pm_qa_percent) / COUNT(*)) AS QA FROM " . PORTAL_DATABASE . ".project_manager  WHERE pm_category = '%s'", $cat);
				$result = $MOD->RunQuerySingle();
				
				if( $result['Dev'] > 0 && $result['QA'] > 0 ) {
					$_SESSION['pm_stats']['category'][$cat] = round(intval($result['Dev'] + $result['QA']) / 2);
				} else {
					// there can be no QA if there is no Dev, so this should cover it all
					$_SESSION['pm_stats']['category'][$cat] = intval($result['Dev']);
				}
			}
			// send to debug
			$MOD->AddDebugGeneral('ProjMan', sprintf('Category cache refreshed (time: %s)', date('Y-m-d h:i:s', $_SESSION['pm_stats']['cachetime'])));

			// build System::Subsystem stats
			foreach( $this->System as $sys ) {
				//$MOD->SQLQuery = sprintf("SELECT (SUM(pm_dev_percent) / COUNT(*)) AS Dev, (SUM(pm_qa_percent) / COUNT(*)) AS QA FROM " . PORTAL_DATABASE . ".project_manager WHERE CONCAT(pm_system, '::', pm_subsystem) = '%s'", $sys['pm_system']);
				$MOD->SQLQuery = sprintf("SELECT (SUM(pm_dev_percent) / COUNT(*)) AS Dev, (SUM(pm_qa_percent) / COUNT(*)) AS QA FROM " . PORTAL_DATABASE . ".project_manager WHERE pm_system = '%s'", $sys['pm_system']);
				$result = $MOD->RunQuerySingle();
				
				if( $result['Dev'] > 0 && $result['QA'] > 0 ) {
					$_SESSION['pm_stats']['system'][$sys['pm_system']] = round(intval($result['Dev'] + $result['QA']) / 2);
				} else {
					// there can be no QA if there is no Dev, so this should cover it all
					$_SESSION['pm_stats']['system'][$sys['pm_system']] = intval($result['Dev']);
				}
			}
			//$MOD->AddDebugGeneral('ProjMan', sprintf('System::Subsystem cache refreshed (time: %s)', date('Y-m-d h:i:s', $_SESSION['pm_stats']['cachetime'])));
			$MOD->AddDebugGeneral('ProjMan', sprintf('System cache refreshed (time: %s)', date('Y-m-d h:i:s', $_SESSION['pm_stats']['cachetime'])));
		}
		
		$MOD->AddDebugGeneral('ProjMan', sprintf('Stats Max Cached (time: %s)', $this->max_cache_time));
		$MOD->AddDebugGeneral('ProjMan', sprintf('Stats Est cache refresh @ %s', date('Y-m-d h:i:s', $_SESSION['pm_stats']['cachetime'] + $this->max_cache_time)));
	}
	
	private function CategoryOptions() {
		global $MOD;
		if( count($this->Category) == 0 )
			$this->Category = $MOD->GetEnum('eq2emuweb_portal', 'project_manager', 'pm_category');
		foreach($this->Category as $option) {
			printf("<option%s>%s</option>", ( $option === $this->Filters['category'] ) ? " selected" : "", $option);
		}
	}

	private function SystemOptions() {
		if( count($this->System) == 0 )
			$this->System = $this->GetSystems();
		foreach($this->System as $option) {
			printf("<option%s>%s</option>", ( $option['pm_system'] === $this->Filters['system'] ) ? " selected" : "", $option['pm_system']);
		}
	}

	private function SubsystemOptions() {
		if( count($this->Subsystem) == 0 )
			$this->Subsystem = $this->GetSubsystems();
		foreach($this->Subsystem as $option) {
			printf("<option%s>%s</option>", ( $option['pm_subsystem'] === $this->Filters['subsystem'] ) ? " selected" : "", $option['pm_subsystem']);
		}
	}
	
	private function AssigneeOptions() {
		global $MOD; 
		if( count($this->Assignee) == 0 )
			$this->Assignee = $MOD->GetAssignee();
		foreach($this->Assignee as $option) {
			printf("<option%s>%s</option>", ( $option === $this->Filters['assignee'] ) ? " selected" : "", $option);
		}
	}
	
	private function GetSystems() {
		global $MOD;
		$MOD->SQLQuery = "SELECT pm_system FROM " . PORTAL_DATABASE . ".project_manager GROUP BY pm_system";
		return $MOD->RunQueryMulti();
	}

	private function GetSubsystems() {
		global $MOD;
		$MOD->SQLQuery = "SELECT pm_subsystem FROM " . PORTAL_DATABASE . ".project_manager GROUP BY pm_subsystem";
		return $MOD->RunQueryMulti();
	}
	
	/*private function GetConcatSys() {
		global $MOD;
		$MOD->SQLQuery = "SELECT DISTINCT CONCAT(pm_system, '::', pm_subsystem) AS pm_system FROM " . PORTAL_DATABASE . ".project_manager";
		return $MOD->RunQueryMulti();
	}*/

	private function GetFilteredSystems($category) {
		global $MOD;
		$MOD->SQLQuery = "SELECT pm_system FROM " . PORTAL_DATABASE . ".project_manager WHERE pm_category = '" . $category . "' GROUP BY pm_system";
		return $MOD->RunQueryMulti();
	}

	private function GetFilteredSubsystems($category, $system) {
		global $MOD;
		$MOD->SQLQuery = "SELECT pm_subsystem FROM " . PORTAL_DATABASE . ".project_manager WHERE pm_category = '" . $category . "' AND pm_system = '" . $system . "' GROUP BY pm_subsystem";
		return $MOD->RunQueryMulti();
	}
	
	private function GetTaskText($id) {
		global $MOD;
		$MOD->SQLQuery = sprintf("SELECT pm_task FROM " . PORTAL_DATABASE . ".project_manager WHERE id = %s", $id);
		$result = $MOD->RunQuerySingle();
		return ( strlen($result['pm_task']) > 0 ) ? $result['pm_task'] : "Unknown";
	}

	
	/****************************************************************************
	 * Search UI Functions
	 ****************************************************************************/

	public function SetFilters() {
		unset($_SESSION['modules']['filters']['projman']);
		$_SESSION['modules']['filters']['projman']['category'] 	= $_POST['category-filter'];
		$_SESSION['modules']['filters']['projman']['system'] 	= $_POST['system-filter'];
		$_SESSION['modules']['filters']['projman']['subsystem'] = $_POST['subsystem-filter'];
		$_SESSION['modules']['filters']['projman']['priority'] 	= $_POST['priority-filter'];
		$_SESSION['modules']['filters']['projman']['stage'] 	= $_POST['stage-filter'];
		$_SESSION['modules']['filters']['projman']['assignee'] 	= $_POST['assignee-filter'];
		$_SESSION['modules']['filters']['projman']['version'] 	= $_POST['version-filter'];
		$_SESSION['modules']['filters']['projman']['notes'] 	= $_POST['notes-filter'];
		$_SESSION['modules']['filters']['projman']['text'] 		= $_POST['text-filter'];
		$_SESSION['modules']['filters']['projman']['limit']		= $_POST['limit-filter'];
	}
	
	public function GetFilters() {
		$this->Filters['category'] 	= $_SESSION['modules']['filters']['projman']['category'];
		$this->Filters['system'] 	= $_SESSION['modules']['filters']['projman']['system'];
		$this->Filters['subsystem'] = $_SESSION['modules']['filters']['projman']['subsystem'];
		$this->Filters['version'] 	= $_SESSION['modules']['filters']['projman']['version'];
	    $this->Filters['text']		= $_SESSION['modules']['filters']['projman']['text'];
		
		$this->Filters['priority'] 	= $_SESSION['modules']['filters']['projman']['priority'];
		$this->Filters['stage'] 	= $_SESSION['modules']['filters']['projman']['stage'];
		$this->Filters['assignee'] 	= $_SESSION['modules']['filters']['projman']['assignee'];
		$this->Filters['notes'] 	= $_SESSION['modules']['filters']['projman']['notes'];
		$this->Filters['limit'] 	= $_SESSION['modules']['filters']['projman']['limit'];
	}

	public function ClearFilters() {
		unset($_SESSION['modules']['filters']['projman']);
	}

	public function Search() {
		global $MOD;
		
		if( $_POST['cmd'] == "Filter" ) {
			$this->SetFilters();
		} elseif( $_POST['cmd'] == "Clear" ) {
			$this->ClearFilters();
		}

		$this->GetFilters();
		
		if( count($_SESSION['modules']['filters']['projman']) > 0 ) {
			$filter_display = '';
			$filter_active = true;
		} else {
			$filter_display = 'style="display:none;"';
			$filter_active = false;
		}
		
		// This starts immediately after the header tag: <div id="page-body" role="main">, 
		// and is display: none until shown
		?>
		<div class="panel" id="search_panel"<?php print( $filter_display ) ?>>
			<h2 class="solo">Filter Tasks <?php ( $filter_active ) ? print('<span class="alert-text">*</style>') : NULL ?></h2>
			<form method="post" action="./index.php?p=projman#content" id="search_memberlist">
				<div class="panel">
					<div class="inner">
						<p>Use this form to filter the various project status entries by preference. You do not need to fill out all fields. To match partial data use * as a wildcard. Use the generated query string to share the URL to a specific status entry.</p>
						<fieldset class="fields1 column1">
							<dl style="overflow: visible;">
								<dt>
									<label for="username">Category:</label>
								</dt>
								<dd>
									<div class="dropdown-container dropdown-right">
										<select name="category-filter" style="width:200px;">
											<option value="">Select Category</option>
											<?php 
											$this->selected_category = ( strlen($_POST['pm_category']) > 0 ) ? $_POST['pm_category'] : "";
											$this->CategoryOptions(); 
											?>
										</select>
									</div>
								</dd>
							</dl>
							<dl>
								<dt>
									<label for="email">System:</label>
								</dt>
								<dd>
									<select name="system-filter" style="width:200px;">
										<option value="">Select System</option>
										<?php 
											$this->selected_system = ( strlen($_POST['pm_system']) > 0 ) ? $_POST['pm_system'] : "";
											$this->SystemOptions(); 
										?>
									</select>
								</dd>
							</dl>
							<dl>
								<dt>
									<label for="search_group_id">Subsystem:</label>
								</dt>
								<dd>
									<select name="subsystem-filter" style="width:200px;">
										<option value="">Select Subsystem</option>
										<?php 
											$this->selected_subsystem = ( strlen($_POST['pm_subsystem']) > 0 ) ? $_POST['pm_subsystem'] : "";
											$this->SubsystemOptions(); 
										?>
									</select>
								</dd>
							</dl>
							<dl>
								<dt>
									<label for="sk" class="label3">Target Version:</label>
								</dt>
								<dd>
									<input class="inputbox" name="version-filter" id="joined" value="<?php print( $this->Filters['version'] ) ?>" type="text" style="width:50px;">
								</dd>
							</dl>
							<dl>
								<dt>
									<label for="text">Text:</label>
								</dt>
								<dd>
									<input class="inputbox" name="text-filter" value="<?php print( $this->Filters['text'] ) ?>" type="text">
								</dd>
							</dl>
						</fieldset>
						<fieldset class="fields1 column2">
							<dl>
								<dt>
									<label for="stage">Stage:</label>
								</dt>
								<dd>
									<select name="stage-filter" style="width:120px;">
										<option value="">Select Stage</option>
										<?php
										foreach($this->Stage as $option)
											printf("<option%s>%s</option>", ( $option === $this->Filters['stage'] ) ? " selected" : "", $option);
										?>
										<option<?php if( $this->Filters['stage'] == "In Progress" ) print(" selected") ?>>In Progress</option>
									</select>
								</dd>
							</dl>
							<dl>
								<dt>
									<label for="priority">Priority:</label>
								</dt>
								<dd>
									<select name="priority-filter" style="width:120px;">
										<option value="">Select Priority</option>
										<?php
										foreach($this->Priority as $option)
											printf("<option%s>%s</option>", ( $option === $this->Filters['priority'] ) ? " selected" : "", $option);
										?>
									</select>
								</dd>
							</dl>
							<dl>
								<dt>
									<label for="ip">Assignee:</label>
								</dt>
								<dd>
									<select name="assignee-filter" style="width:120px;">
										<option value="">Select Assignee</option>
										<?php
										$this->AssigneeOptions(); 
										?>
									</select>
								</dd>
							</dl>
							<dl>
								<dt>
									<label for="joined">Show Notes:</label>
								</dt>
								<dd>
									<select name="notes-filter" style="width:50px;">
										<option value="0"<?php if( $this->Filters['notes'] == 0 ) print( ' selected') ?>>No</option>
										<option value="1"<?php if( $this->Filters['notes'] == 1 ) print( ' selected') ?>>Yes</option>
									</select>
								</dd>
							</dl>
							<dl>
								<dt>
									<label for="joined">Results:</label>
								</dt>
								<dd>
									<select name="limit-filter" style="width:50px;">
										<option value="0">--</option>
										<option<?php if( $this->Filters['limit'] == 25 ) print(" selected") ?>>25</option>
										<option<?php if( $this->Filters['limit'] == 50 ) print(" selected") ?>>50</option>
										<option<?php if( $this->Filters['limit'] == 100 ) print(" selected") ?>>100</option>
										<option<?php if( $this->Filters['limit'] == 250 ) print(" selected") ?>>250</option>
										<option<?php if( $this->Filters['limit'] == 500 ) print(" selected") ?>>500</option>
										<option<?php if( $this->Filters['limit'] == 1000 ) print(" selected") ?>>1000</option>
									</select>
								</dd>
							</dl>
						</fieldset>
						<div class="clear"></div>
						<hr>
						<fieldset class="submit-buttons">
							<input name="cmd" value="Filter" class="button1" type="submit" tabindex="0">
							&nbsp;
							<input value="Clear" name="cmd" class="button2" type="submit" tabindex="1">
						</fieldset>
					</div>
				</div>
			</form>
		</div>
		<a name="content" id="content"></a>
		<h2 class="solo">Project Task Manager</h2>
		<div class="action-bar top">
			<div class="member-search panel"> <a id="searchbox" href="#"><strong> Click to toggle Filters panel.</strong></a></div>
			<div class="pagination">&nbsp;</div>
		</div>
		<?php 
	}
	
	
	private function GetFilteredData() {
		global $MOD;
		
		// fetch (filtered) data
		$select = "SELECT * FROM " . PORTAL_DATABASE . ".project_manager WHERE id > 0"; // bogus clause in case we have no ANDs below

		if( strlen($this->Filters['category']) > 0 )
			$where .= "(pm_category = '".$this->Filters['category']."')";
		if( strlen($this->Filters['system']) > 0 )
			$where .= "(pm_system = '".$this->Filters['system']."')";
		if( strlen($this->Filters['subsystem']) > 0 )
			$where .= "(pm_subsystem = '".$this->Filters['subsystem']."')";
		if( strlen($this->Filters['version']) > 0 )
			$where .= "(pm_version = '".$this->Filters['version']."')";
		if( strlen($this->Filters['text']) > 0 )
			$where .= "((pm_category RLIKE '".$this->Filters['text']."') OR (pm_system RLIKE '".$this->Filters['text']."') OR (pm_subsystem RLIKE '".$this->Filters['text']."') OR (pm_task RLIKE '".$this->Filters['text']."'))";
		if( strlen($this->Filters['stage']) > 0 ) {
			if( $this->Filters['stage'] == "In Progress" ) {
				$where .= "(pm_stage IN ('2-Design','3-Development','4-Testing') OR (pm_dev_percent > 0 AND pm_dev_percent < 100) OR (pm_started > 0 AND pm_completed = 0))";
			} else {
				$where .= "(pm_stage = '".$this->Filters['stage']."')";
			}
		} else {
			$where .= "(pm_stage NOT IN ('5-Completed'))"; // if no stage filter set, only show in-progress tasks
		}
		if( strlen($this->Filters['priority']) > 0 )
			$where .= "(pm_priority = '".$this->Filters['priority']."')";
		if( strlen($this->Filters['assignee']) > 0 )
			$where .= "(pm_assignee = '".$this->Filters['assignee']."')";

		$order_by = " ORDER BY pm_category, pm_system, pm_subsystem, pm_stage DESC, pm_dev_percent DESC, pm_qa_percent DESC";
		$limit = ( intval($this->Filters['limit']) == 0 ) ? sprintf(" LIMIT 0,%s", intval($_SESSION['modules']['config']['max_grid_rows'])) : sprintf(" LIMIT 0,%s", $this->Filters['limit']);

		if( strlen($where) > 0 ) {
			$MOD->SQLQuery = $select . " AND " . preg_replace("/\)\(/", ") AND (", $where) . $order_by . $limit;
		} else {
			$MOD->SQLQuery = $select . $order_by . $limit;
		}

		$this->StatusData = $MOD->RunQueryMulti();
	}


	public function Screen() {
		global $MOD;
		
		$this->GetFilteredData();

		if( $this->is_team ) {
		?>
		<script language="javascript">
		<!--
		function goNew() {
			window.open('./index.php?p=projman&add=new#content', target='_self');
		}
		-->
		</script>
		<table width="100%" border="0" cellspacing="0">
			<tr height="30">
				<td class="mod-instruct">TEAM: Click the ID or Task to view task details. To add a new Task, click &quot;Add New&quot;.
				</td>
				<td width="20%" align="right">
					<button class="mod-instruct" onclick="goNew()">Add New</button>
				</td>
			</tr>
		</table>
		<br />
		<?php } // end is_admin ?>
		<div class="panel diffuse">
			<div class="inner">
				<div style="width: 100%;">
					<table border="0" cellspacing="0" cellpadding="0" style="margin:5px 0px 15px 0px;">
						<tr>
							<td width="50" align="right"><span style="font-weight:bold; color:#fff;">Legend:</span>&nbsp;</td>
							<td width="100" class="Depends" align="center">Depends On</td>
							<td>&nbsp;</td>
							<td width="100" class="Needs" align="center">Needs Work</td>
							<td>&nbsp;</td>
							<td width="100" class="NeedsDepends" align="center">Both</td>
						</tr>
					</table>
		<?php
		if( is_array($this->StatusData) ) {
			// build category blocks
			// 		then build system blocks
			// 			then build rows
			$Category = NULL;
			$CatCount = 0; // for new document
			$SysCount = 0; // for new section
			$this->row_count = 0;
			foreach($this->StatusData as $status) {
				
				if( $Category != $status['pm_category'] ) {
					$Category = $status['pm_category'];
					if( $CatCount > 0 )
						$this->EndCategory();
					$this->StartCategory($Category);
					$CatCount++;
					$System = NULL;
					$SysCount = 0;
					$this->row_count = 0;
				}
				
				/*$concat_system = sprintf("%s::%s", $status['pm_system'], $status['pm_subsystem']);
				if( $System != $concat_system ) {
					$System = $concat_system;
					if( $SysCount > 0 )
						$this->EndSystem();
					$this->StartSystem($System);
					$SysCount++;
					$this->row_count = 0;
				}*/ 
				if( $System != $status['pm_system'] ) {
					$System = $status['pm_system'];
					if( $SysCount > 0 )
						$this->EndSystem();
					$this->StartSystem($System);
					$SysCount++;
					$this->row_count = 0;
				} 
				
				$this->AddTaskRow($status);
				
				$this->row_count++; // section total for styling
				$this->total_count++; // page total
			}
		
		$this->EndCategory(); // close out when we're done
		} // end is_arary
		?>
				</div>
			</div>
		</div>
		<?php
		$this->Footer();
	}
	
	
	/**
	  * Opens a new category container
	  */
	private function StartCategory($cat) {
		?>
		<!-- START Category -->
		<div id="cp-main" class="ucp-main panel-container">
			<div id="cat-progress" title="Total Category Complete"><?php $this->DrawOneProgressBar($_SESSION['pm_stats']['category'][$cat]) ?><span><?php print( $_SESSION['pm_stats']['category'][$cat] ) ?>%</span></div>
			<h2><?php print( $cat ) ?></h2>
			<div class="panel" style=""><!-- collapser here? -->
				<div class="inner">
					<ul class="topiclist">
						<li class="header">
							<dl>
		<?php
	}
	
	
	/**
	  * Closes existing category container
	  */
	private function EndCategory() {
		$this->EndSystem();
	?>
						</dl>
					</li>
				</ul>
			</div>
		</div>
	</div>
	<!-- END Category -->
	<?php
	}
	
	
	/**
	  * Opens a new system container
	  */
	private function StartSystem($sys) {
	?>
	<!-- START System -->
	<dt>
		<div id="sys-progress" title="Total Subsystem Complete"><?php $this->DrawOneProgressBar($_SESSION['pm_stats']['system'][$sys]) ?><span><?php print( $_SESSION['pm_stats']['system'][$sys] ) ?>%</span></div>
		<div class="list-inner"><?php print( $sys ) ?></div>
	</dt>
	<table class="table1 responsive">
		<col width="20" />
		<col width="100" />
		<col />
		<col width="100" />
		<col width="100" />
		<col width="100" />
		<col width="100" />
		<col width="100" />
		<thead>
			<tr>
				<th>ID</th>
				<th>Subsystem</th>
				<th class="left">Task</th>
				<th>Stage</th>
				<th>Priority</th>
				<th>Ver</th>
				<th>Assigned</th>
				<th class="center">Completed</th>
			</tr>
		</thead>
		<tbody>
	<?php
	}


	/**
	  * Closes existing system container
	  */
	private function EndSystem() {
		?>
										</tbody>
											</table>
											<br />
											<hr />
											<!-- END System -->
		<?php
	}


	/**
	  * Injects a task row into the grid
	  */
	private function AddTaskRow($row) {
		global $MOD, $user;
		
		if( $row['pm_dependency'] && $row['pm_attention'] )
			$RowColor = 'NeedsDepends';
		elseif( $row['pm_dependency'] && !$row['pm_attention'] )
			$RowColor = 'Depends';
		elseif( !$row['pm_dependency'] && $row['pm_attention'] )
			$RowColor = 'Needs';
		else
			$RowColor = ( $this->row_count % 2 ) ? 'bg1' : 'bg3';
		
		$task_text = ( strlen($row['pm_task']) > 50 ) ? sprintf("%s...", substr($row['pm_task'], 0, 50)) : $row['pm_task'];
		
		if( $this->is_team ) {
		}
		
		
		?> 
													<tr class="<?php print( $RowColor ) ?>">
														<td><a href="./index.php?p=projman&id=<?php print( $row['id'] ) ?>#content"><?php print($row['id']) ?></a></td>
														<td><?php echo $row['pm_subsystem'] ?></td>
														<td><a href="./index.php?p=projman&id=<?php print( $row['id'] ) ?>#content" style="color: <?php $this->SetPriorityColor($row['pm_priority']) ?>;" class="username-coloured"><?php print( $task_text ) ?></a></td>
														<td><?php print($row['pm_stage']) ?></a></td>
														<td><?php print($row['pm_priority']) ?></td>
														<td><?php print($row['pm_version']) ?></td>
														<td nowrap="nowrap"><? ( $user->data['user_id'] > 1 ) ? print($row['pm_assignee']) : print("[hidden]") ?></td>
														<!--<td class="center" title="<?php $row['percent_complete'] ?>%"><progress max="100" value="<?php $row['percent_complete'] ?>"></progress></td>-->
														<td class="progress"><?php $this->DrawProgressBar($row['pm_dev_percent'], $row['pm_qa_percent']) ?></td>
													</tr>
		<?php if( !empty($row['pm_note']) && $this->Filters['notes'] == 1 ) { ?>
													
													<tr class="notes-row">
														<td colspan="9"><strong>Note:</strong> <?php print( $MOD->FormatString( $row['pm_note'] ) ) ?></td>
													</tr>
													
		<?php } // end devnote
	}
	
	
	private function DrawProgressBar($dev, $qa) {
		?>
		<progress id="devbar" max="100" value="<?php print( $dev ) ?>" title="<?php print( $dev ) ?>%"></progress>
		<progress id="qabar" max="100" value="<?php print( $qa ) ?>" title="<?php print( $qa ) ?>%"></progress>
		<?php
	}
	
	private function DrawOneProgressBar($total) {
		?>
		<progress id="qabar" max="100" value="<?php print( $total) ?>"></progress>
		<?php
	}
	

	// TODO: CSS these?
	private function SetPriorityColor($priority) {
		switch($priority) {
			case '1-Immediate'	: print('#c00'); break;
			case '2-Critical'	: print('#900'); break;
			case '3-Medium'		: print('#663'); break;
			case '4-Low'		: print('#690'); break;
			case '5-Cosmetic'	: print('#099'); break;
		}
		
	}

	/**
	  * Adds necessary javascript code to the bottom of projman container
	  */
	private function Footer() {
		//This was very useful: http://stackoverflow.com/questions/21070101/show-hide-div-using-javascript
		?>
		<div class="action-bar bottom">
			<div class="pagination">&nbsp;</div>
		</div>
		<script type="text/javascript">
		document.getElementById('searchbox').addEventListener('click', function () {
			toggle(document.getElementById('search_panel'));
		});
		
		function toggle (elements, specifiedDisplay) {
		  var element, index;
		  
		  elements = elements.length ? elements : [elements];
		  for (index = 0; index < elements.length; index++) {
			element = elements[index];
		
			if (isElementHidden(element)) {
			  element.style.display = '';
			  // If the element is still hidden after removing the inline display
			  if (isElementHidden(element)) {
				element.style.display = specifiedDisplay || 'block';
			  }
			} else {
			  element.style.display = 'none';
			}
		  }
		  function isElementHidden (element) {
			return window.getComputedStyle(element, null).getPropertyValue('display') === 'none';
		  }
		}
		</script>
	<?php
	}

	
	public function Detail() {
		global $MOD, $user; // user needed for insert/logging
	
		if( !$this->is_team )
			return;
			
		$status = "";

		switch($_POST['cmd']) {
			
			case "Update":
				
				if( strlen($_POST['field']['pm_task']) > 3 ) { // double check they didn't erase Task, everything else has defaults
					
					$idx_value = $_POST['orig_id'];
					$status = sprintf("No changes for detail ID %s", $idx_value);
					$sets='';
					
					// Loop through Toggles and see if any have been unset
					foreach( $this->Toggles as $toggles ) {
						$toggle_settings = sprintf('%s', $toggles);
						if( empty($_POST['field'][$toggle_settings]) ) // is this really the best way to uncheck a checkbox?
							$_POST['field'][$toggle_settings] = 0;
					}
					
					// now we find the current fields, compare them to the old [vslues] and fix the dates
					foreach($_POST['field'] as $key=>$val) {
						// first, translate string dates into unix dates
						if( $key == "pm_started" && strlen($val) > 0 )
							$_POST['field']['pm_started'] = ( $val > 0 ) ? strtotime($val) : 0;
						if( $key == "pm_completed" && strlen($val) > 0 )
							$_POST['field']['pm_completed'] = ( $val > 0 ) ? strtotime($val) : 0;
							
						if( $_POST['field'][$key] != $_POST['value'][$key] ) {
							// build the update query here
							$sets .= ( empty($sets) ) ? sprintf("%s = '%s'", $key, $MOD->SQLEscape($_POST['field'][$key])) : sprintf(", %s = '%s'", $key, $MOD->SQLEscape($_POST['field'][$key]));
						}
					}
					
					if( strlen($sets) > 0 ) {
						// something got set, so let's update!
						$MOD->TableName = $_POST['table_name'];
						
						// set query string so we can log it after
						$query = sprintf("UPDATE " . PORTAL_DATABASE . ".%s SET %s WHERE id = %s;", $MOD->TableName, $sets, $idx_value);
						
						$MOD->SQLQuery = $query;
						$MOD->RunQuery();
						
						if( $MOD->AffectedRows > 0 ) {
							$status = sprintf("Update task ID %s successful!", $idx_value);
							$_SESSION['pm_stats']['cachetime'] = 0; // force cache reload when returning to task list
						}
							
						// update log
						$log_array['log_type'] 		= 'Admin';
						$log_array['log_operation'] = 'STATUS_MANAGER_UPDATE';
						$log_array['log_data']		= sprintf("i:%s;u:%s;q:%s", $idx_value, $user->data['username'], $MOD->SQLEscape($query));
						$MOD->Log( $log_array );
					}
				}
				break;
				
			case "Delete":
				/*$query = sprintf("DELETE FROM " . PORTAL_DATABASE . ".project_manager WHERE id = %s", $_GET['id']);
				
				$MOD->SQLQuery = $query;
				$MOD->RunQuery();
				
				$log_array['log_type'] 		= 'Admin';
				$log_array['log_operation'] = 'STATUS_MANAGER_DELETE';
				$log_array['log_data']		= sprintf("i:%s;u:%s;n:%s;q:%s", $_GET['id'], $user->data['username'], $_POST['field']['pm_subsystem'], $MOD->SQLEscape($query));
				$MOD->Log( $log_array );
				
				print("<script language=\"javascript\">window.open('./index.php?p=projman', target='_self');</script>");*/
				break;
		}
		
		$MOD->SQLQuery = sprintf("SELECT * FROM " . PORTAL_DATABASE . ".project_manager WHERE id = %s", $_GET['id']);
		$data = $MOD->RunQuerySingle();
		$RowColor = ( isset($_POST['row_color']) ) ? $_POST['row_color'] : '#eeeeee'; 

		?>
		<script language="javascript">
		<!--
		function SetDate(f, dt)
		{
			var elem = document.getElementById(f);
			elem.value = dt;
		}
		function goBack() {
			window.open('./index.php?p=projman#content', target='_self');
		}
		function goReload() {
			window.location.href = './index.php?p=projman&id=<?php print( $data['id'] ) ?>#content'
			window.location.reload(true);
		}
		function goNew() {
			window.open('./index.php?p=projman&add=new#content', target='_self');
		}
		function goNext() {
			window.open('./index.php?p=projman&id=<?php print( intval($data['id'] + 1) ) ?>#content', target='_self');
		}
		function goPrev() {
			window.open('./index.php?p=projman&id=<?php print( intval($data['id'] - 1) ) ?>#content', target='_self');
		}
		-->
		</script>
		<a name="content" id="content"></a>
		<h2 class="solo">Task Details</h2>
		<table width="100%" border="0" cellspacing="0">
			<tr height="30">
				<td class="mod-instruct">Explain what Details does.
				<button class="mod-instruct" onclick="goNext()"<?php if( $data['id'] >= $MOD->GetMaxPK("project_manager", "id") ) print(" disabled") ?>>Next &gt;&gt;</button>
				<button class="mod-instruct" onclick="goBack()">List</button>
				<button class="mod-instruct" onclick="goPrev()"<?php if( $data['id'] <= 1 ) print(" disabled") ?>>&lt;&lt; Prev</button>
				<button class="mod-instruct" onclick="goReload()">Reload</button>
				</td>
			</tr>
		</table>
		<br />
		<div class="panel diffuse">
			<div class="inner">
				<div style="width: 100%;">
					<div style="height:30px"></div>
					<!-- START Detail -->
					<div id="cp-main" class="ucp-main panel-container">
						<h2>Editing: <?php print( $data['pm_task'] ) ?></h2>
						<div class="panel" style="">
							<div class="inner">
								<ul class="topiclist">
									<li class="header">
										<p class="status"><?php echo $status ?></p>
										<form method="post">
										<table class="table1 responsive">
											<thead>
												<tr>
													<th style="width:130px;">Field</th>
													<th>Value</th>
												</tr>
											</thead>
											<tbody>
												<tr>
													<td>Task ID:</td>
													<td>
														<strong><?php print( $data['id'] ); ?></strong>
														<input type="hidden" name="orig_id" value="<?php print( $data['id'] ) ?>" />
													</td>
												</tr>
												<tr>
													<td>Category:</td>
													<td><select name="field[pm_category]" style="width:200px;">
															<option value="">Select Category</option>
															<?php 
															foreach($this->Category as $option)
																printf("<option%s>%s</option>", ( $option === $data['pm_category'] ) ? " selected" : "", $option);
															?>
														</select>
														<input type="hidden" name="value[pm_category]" value="<?php print( $data['pm_category'] ) ?>" />
														</td>
												</tr>
												<tr>
													<td>System:</td>
													<td>
														<select name="field[pm_system]" style="width:200px;">
															<option value="">Select System</option>
															<?php 
															foreach($this->System as $option)
																printf("<option%s>%s</option>", ( $option['pm_system'] === $data['pm_system'] ) ? " selected" : "", $option['pm_system']);
															?>
														</select>
														<input type="hidden" name="value[pm_system]" value="<?php print( $data['pm_system'] ) ?>" />
													</td>
												</tr>
												<tr>
													<td>Subsystem:</td>
													<td>
														<select name="field[pm_subsystem]" style="width:200px;">
															<option value="">Select Subsystem</option>
															<?php 
															foreach($this->Subsystem as $option)
																printf("<option%s>%s</option>", ( $option['pm_subsystem'] === $data['pm_subsystem'] ) ? " selected" : "", $option['pm_subsystem']);
															?>
														</select>
														<input type="hidden" name="value[pm_subsystem]" value="<?php print( $data['pm_subsystem'] ) ?>" />
													</td>
												</tr>
												<tr>
													<td>Task:</td>
													<td>
														<input type="text" name="field[pm_task]" maxlength="250" value="<?php print( $data['pm_task'] ) ?>" class="inputbox" title="Task description" autocomplete="off" />
														<input type="hidden" name="value[pm_task]" value="<?php print( $data['pm_task'] ) ?>" />
													</td>
												</tr>
												<tr>
													<td>Target Version:</td>
													<td>
														<input type="text" name="field[pm_version]" maxlength="10" value="<?php print( $data['pm_version'] ) ?>" class="inputbox" title="Version this task is assigned to" autocomplete="off" style="width:50px;" />
														<input type="hidden" name="value[pm_version]" value="<?php print( $data['pm_version'] ) ?>" />
													</td>
												</tr>
												<tr>
													<td>Stage:</td>
													<td>
														<select name="field[pm_stage]" style="width:200px;">
															<option value="">Select Stage</option>
															<?php 
															if( is_array($this->Stage) )
																foreach($this->Stage as $option)
																	printf("<option%s>%s</option>", ( $option === $data['pm_stage']) ? " selected" : "", $option);
															?>
														</select>
														<input type="hidden" name="value[pm_stage]" value="<?php print( $data['pm_stage'] ) ?>" />
													</td>
												</tr>
												<tr>
													<td>Priority:</td>
													<td>
														<select name="field[pm_priority]" style="width:200px;">
															<option value="">Select Priority</option>
															<?php 
															if( is_array($this->Priority) )
																foreach($this->Priority as $option)
																	printf("<option%s>%s</option>", ( $option === $data['pm_priority']) ? " selected" : "", $option);
															?>
														</select>
														<input type="hidden" name="value[pm_priority]" value="<?php print( $data['pm_priority'] ) ?>" />
													</td>
												</tr>
												<tr>
													<td>Assigned To:</td>
													<td>
														<select name="field[pm_assignee]" style="width:200px;">
															<option value="">Select Assignee</option>
															<?php 
															foreach($this->Assignee as $option)
																printf("<option%s>%s</option>", ( $option === $data['pm_assignee'] ) ? " selected" : "", $option);
															?>
														</select>
														<input type="hidden" name="value[pm_assignee]" value="<?php print( $data['pm_assignee'] ) ?>" />
													</td>
												</tr>
												<tr>
													<td>Requires Attention:</td>
													<td class="<?php print( $data['pm_attention'] ? 'Needs' : '' ) ?>">
														<input type="checkbox" name="field[pm_attention]" value="1"<?php if( $data['pm_attention'] ) print(" checked") ?> />
														<input type="hidden" name="value[pm_attention]" value="<?php print( $data['pm_attention'] ) ?>" />
													</td>
												</tr>
												<tr>
													<td>Has Dependency:</td>
													<td class="<?php print( $data['pm_dependency'] ? 'Depends' : '' ) ?>">
														<input type="checkbox" name="field[pm_dependency]" value="1"<?php if( $data['pm_dependency'] ) print(" checked") ?> />
														<input type="hidden" name="value[pm_dependency]" value="<?php print( $data['pm_dependency'] ) ?>" />
													</td>
												</tr>
												<?php if( $data['pm_dependency'] == 1 ) { ?>
												<tr>
													<td>Link to Task:</td>
													<td class="<?php print( $data['pm_dependency'] ? 'Depends' : '' ) ?>">
														<input type="text" name="field[pm_link_to_task]" maxlength="10" value="<?php print( $data['pm_link_to_task'] ) ?>" class="inputbox" title="This task depends on another" autocomplete="off" style="width:50px;" />
														<a href="./index.php?p=projman&id=<?php print( $data['pm_link_to_task'] ); ?>"><?php print( $this->GetTaskText($data['pm_link_to_task']) ); ?></a>
														<input type="hidden" name="value[pm_link_to_task]" value="<?php print( $data['pm_link_to_task'] ) ?>" />
													</td>
												</tr>
												<?php } ?>
												<tr>
													<td>Link to Post:</td>
													<td>
														<input type="text" name="field[pm_link_to_post]" maxlength="10" value="<?php print( $data['pm_link_to_post'] ) ?>" class="inputbox" title="This task is discussed on the forums" autocomplete="off" style="width:50px;" />
														<?php 
															if( intval($data['pm_link_to_post']) === 0 )
																print("(enter post ID)");
															else
																printf('<a href="%sviewtopic.php?p=%s#p%s" target="_blank">Go!</a>', $this->ForumPath, $data['pm_link_to_post'], $data['pm_link_to_post']);
														?>
														<input type="hidden" name="value[pm_link_to_post]" value="<?php print( $data['pm_link_to_post'] ) ?>" />
													</td>
												</tr>
												<tr>
													<td>Completed (Dev):</td>
													<td>
														<select name="field[pm_dev_percent]" style="width:50px;" >
														<?php 
														$i = 0;
														for( ;; ) {
															if( $i > 100 )
																break;
															printf('<option%s>%s</option>', ( $data['pm_dev_percent'] == $i ) ? " selected" : "", $i);
															$i += 5;
														}
														?>
														</select>%
														<input type="hidden" name="value[pm_dev_percent]" value="<?php print( $data['pm_dev_percent'] ) ?>" />
													</td>
												</tr>
												<tr>
													<td>Completed (QA):</td>
													<td>
														<select name="field[pm_qa_percent]" style="width:50px;" >
														<?php 
														$i = 0;
														for( ;; ) {
															if( $i > 100 )
																break;
															printf('<option%s>%s</option>', ( $data['pm_qa_percent'] == $i ) ? " selected" : "", $i);
															$i += 5;
														}
														?>
														</select>%
														<input type="hidden" name="value[pm_qa_percent]" value="<?php print( $data['pm_qa_percent'] ) ?>" />
													</td>
												</tr>
												<tr>
													<td>Date Started:</td>
													<td>
														<input type="text" id="ds" name="field[pm_started]" maxlength="50" value="<?php ( $data['pm_started'] > 0 ) ? print( date('Y-m-d', $data['pm_started']) ) : print("0") ?>" class="inputbox" title="This task started on this date" autocomplete="off" style="width:100px;" />&nbsp;(YYYY-MM-DD)&nbsp;
														<input type="button" value="Today" onclick="SetDate('ds', '<?php print( date("Y-m-d", time()) ) ?>'); return false;" />
														<input type="hidden" name="value[pm_started]" value="<?php print( $data['pm_started'] ) ?>" />
														<input type="hidden" name="field[pm_updated]" value="<?php print( time() ) ?>" />
														<input type="hidden" name="value[pm_updated]" value="<?php print( $data['pm_updated'] ) ?>" />
													</td>
												</tr>
												<tr>
													<td>Date Completed:</td>
													<td>
														<input type="text" id="dc" name="field[pm_completed]" maxlength="50" value="<?php ( $data['pm_completed'] > 0 ) ? print( date('Y-m-d', $data['pm_completed']) ) : print("0") ?>" class="inputbox" title="This task was completed on this date" autocomplete="off" style="width:100px;" />&nbsp;(YYYY-MM-DD)&nbsp;
														<input type="button" value="Today" onclick="SetDate('dc', '<?php print( date("Y-m-d", time()) ) ?>'); return false;" />
														<input type="hidden" name="value[pm_completed]" value="<?php print( $data['pm_completed'] ) ?>" />
														<input type="hidden" name="field[pm_updated]" value="<?php print( time() ) ?>" />
														<input type="hidden" name="value[pm_updated]" value="<?php print( $data['pm_updated'] ) ?>" />
													</td>
												</tr>
												<tr>
													<td style="vertical-align:top;">Task Notes:</td>
													<td>
														<textarea name="field[pm_note]" id="signature" style="height: 9em;" rows="15" cols="76" tabindex="4" class="inputbox"><?php print( $data['pm_note'] ) ?></textarea>
														<input type="hidden" name="value[pm_note]" value="<?php print( $data['pm_note'] ) ?>" />
													</td>
												</tr>
												<tr>
													<td style="vertical-align:top;">Additional Info:</td>
													<td>
														<textarea name="field[pm_other]" id="signature" style="height: 9em;" rows="15" cols="76" tabindex="4" class="inputbox"><?php print( $data['pm_other'] ) ?></textarea>
														<input type="hidden" name="value[pm_other]" value="<?php print( $data['pm_other'] ) ?>" />
													</td>
												</tr>
												<tr>
													<td colspan="2" height="20" align="center" valign="middle">(last updated: <?php print( ($data['pm_updated'] > 0) ? date('M-d-Y h:i:s', $data['pm_updated']) : "Never" ) ?>)</td>
												</tr>
												<tr>
													<td colspan="2" align="center">
														<input type="submit" name="cmd" value="Update" />&nbsp;
														<input type="button" value="Add" onclick="goNew()" />&nbsp;
													<?php if( $this->is_admin_off ) { ?>
														<input type="submit" name="cmd" value="Delete" style="font:11px; width:90px;" />&nbsp;
													<?php } ?>
													</td>
												</tr>
												
												<input type="hidden" name="table_name" value="project_manager" />
											</tbody>
										</table>
										</form>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php 
		//if( $this->is_admin )
		//	ShowProjManLog($_GET['id']);
	}
			

	public function Add() {
		global $MOD, $user; // user needed for insert/logging
	
		if( !$this->is_team )
			return;
	
		$this->GetFilters();
	
		$status = "";
	
		switch($_POST['cmd']) {
	
			case "Add":
			
				// barrbaric form validation:
				if( strlen($_POST['field']['pm_task']) > 3 ) {
					
					$status = sprintf("Failed to add Task");
					$fields='';
					$values='';
					
					// first pass, process updated post vars
					foreach($_POST['field'] as $key=>$val) {
						if( $key == "pm_system_new" && strlen($val) > 0 ) { // this means a new System is being added
							$_POST['field']['pm_system'] = $_POST['field']['pm_system_new'];
							$_POST['field']['pm_system_new'] = '';
						}
						
						if( $key == "pm_subsystem_new" && strlen($val) > 0 ) { // this means a new System is being added
							$_POST['field']['pm_subsystem'] = $_POST['field']['pm_subsystem_new'];
							$_POST['field']['pm_subsystem_new'] = '';
						}
						
						// translate string dates into unix dates
						if( $key == "pm_started" && strlen($val) > 0 )
							$_POST['field']['pm_started'] = ( $val > 0 ) ? strtotime($val) : 0;
					}
					
					// now we find the current fields, compare them to the old [vslues] and fix the dates
					foreach($_POST['field'] as $key=>$val) {
						//printf('<span style="font-size:2em; color:#ccc;">%s = %s</span><br />', $key, $val);
							
						if( strlen($_POST['field'][$key]) > 0 ) {
							// build the insert query here
							$fields .= ( empty($fields) ) ? sprintf("`%s`", $key) : sprintf(", `%s`", $key);
							$values .= ( empty($values) ) ? sprintf("'%s'", $MOD->SQLEscape($_POST['field'][$key])) : sprintf(", '%s'", $MOD->SQLEscape($_POST['field'][$key]));
						}
					}
					
					//printf('<span style="font-size:2em; color:#0f0;">Query: %s, %s</span><br />', $fields, $values);
				}

	
				if( strlen($fields) > 0 && strlen($values) > 0 ) {
					
					$query = sprintf("INSERT INTO " . PORTAL_DATABASE . ".project_manager (%s) VALUES (%s)", $fields, $values);
					
					$MOD->SQLQuery = $query;
					$MOD->RunQuery();

					$new_id = $MOD->LastInsertID;
					if( $new_id > 0 ) {
						$status = sprintf('Add Task <a href="./index.php?p=projman&id=%s">%s</a> successful!', $new_id, $new_id);
						$_SESSION['pm_stats']['cachetime'] = 0; // force cache reload when returning to task list
					}
						
					$log_array['log_type'] 		= 'Admin';
					$log_array['log_operation'] = 'STATUS_MANAGER_ADD';
					$log_array['log_data']		= sprintf("i:%lu;u:%s;q:%s", $new_id, $user->data['username'], $MOD->SQLEscape($query));
					$MOD->Log( $log_array );
				}		
				break;
		}

		// set the selected items per Filter if one is not already set in this form
		$category 	= ( strlen($_POST['field']['pm_category']) > 0 ) ? $_POST['field']['pm_category'] : $this->Filters['category'];
		$system 	= ( strlen($_POST['field']['pm_system']) > 0 ) ? $_POST['field']['pm_system'] : $this->Filters['system'];
		$subsystem	= ( strlen($_POST['field']['pm_subsystem']) > 0 ) ? $_POST['field']['pm_subsystem'] : $this->Filters['subsystem'];
		$stage 		= ( strlen($_POST['field']['pm_stage']) > 0 ) ? $_POST['field']['pm_stage'] : "1-Discovery";
		$assignee 	= ( strlen($_POST['field']['pm_assignee']) > 0 ) ? $_POST['field']['pm_assignee'] : "Unassigned";
		$version	= ( strlen($_POST['field']['pm_version']) > 0 ) ? $_POST['field']['pm_version'] : "0.1";
		$priority 	= ( strlen($_POST['field']['pm_priority']) > 0 ) ? $_POST['field']['pm_priority'] : "3-Medium";
		
		if( strlen($category) == 0 ) {
			$category = "Server"; // default to Server category since that's where the bulk of the tasks should be
		}
	
		?>
		<script language="javascript">
		<!--
		function SetDate(f, dt)
		{
			var elem = document.getElementById(f);
			elem.value = dt;
		}
		function SetMe(f, at)
		{
			var elem = document.getElementById(f);
			elem.value = at;
		}
		function goBack() {
			window.open('./index.php?p=projman', target='_self');
		}
		function Undo() {
			window.location.href = './index.php?p=projman&id=<?php print( $data['id'] ) ?>#content'
			window.location.reload(true);
		}
		-->
		</script>
		<a name="content" id="content"></a>
		<h2 class="solo">Add Task</h2>
		<table width="100%" border="0" cellspacing="0">
			<tr height="30">
				<td class="mod-instruct">Explain what adding a Task does.
				<button class="mod-instruct" onclick="Undo()">Undo</button>
				<button class="mod-instruct" onclick="goBack()">&lt;&lt; Back</button>
				</td>
			</tr>
		</table>
		<br />
		<div class="panel diffuse">
			<div class="inner">
				<div style="width: 100%;">
					<div style="height:30px"></div>
					<!-- START Detail -->
					<div id="cp-main" class="ucp-main panel-container">
						<h2>Adding: New Task</h2>
						<div class="panel" style="">
							<div class="inner">
								<ul class="topiclist">
									<li class="header">
										<p class="status"><?php echo $status ?></p>
										<form method="post">
										<table class="table1 responsive">
											<thead>
												<tr>
													<th style="width:130px;">Field</th>
													<th style="width:200px;">Value</th>
													<th>New Value</th>
												</tr>
											</thead>
											<tbody>
												<tr>
													<td>Task ID:</td>
													<td><strong>NEW</strong></td>
													<td><?php print( $MOD->GetMaxPK("project_manager", "id")+1 ) ?></td>
												</tr>
												<tr>
													<td>Category:</td>
													<td colspan="2">
														<select name="field[pm_category]" style="width:200px;">
															<option value="">Select Category</option>
															<?php 
															foreach($this->Category as $option)
																printf("<option%s>%s</option>", ( $option === $category ) ? " selected" : "", $option);
															?>
														</select>
													</td>
												</tr>
												<tr>
													<td>System:</td>
													<td>
														<select name="field[pm_system]" style="width:200px;">
															<option value="">Select System</option>
															<?php 
															foreach($this->System as $option)
																printf("<option%s>%s</option>", ( $option['pm_system'] === $system ) ? " selected" : "", $option['pm_system']);
															?>
														</select>
													</td>
													<td>
														<input type="text" name="field[pm_system_new]" maxlength="100" value="" class="inputbox" title="Create a new System in this Category" autocomplete="on" style="width:100px;" />
														New System
													</td>
												</tr>
												<tr>
													<td>Subsystem:</td>
													<td>
														<select name="field[pm_subsystem]" style="width:200px;">
															<option value="">Select Subsystem</option>
															<?php 
															foreach($this->Subsystem as $option)
																printf("<option%s>%s</option>", ( $option['pm_subsystem'] === $subsystem ) ? " selected" : "", $option['pm_subsystem']);
															?>
														</select>
													</td>
													<td>
														<input type="text" name="field[pm_subsystem_new]" maxlength="100" value="" class="inputbox" title="Create a new Subsystem in this System" autocomplete="on" style="width:100px;" />
														New Subsystem
													</td>
												</tr>
												<tr>
													<td>Task:</td>
													<td colspan="2"><input type="text" name="field[pm_task]" maxlength="250" value="" class="inputbox" title="Task description" autocomplete="off" /></td>
												</tr>
												<tr>
													<td>Target Version:</td>
													<td colspan="2"><input type="text" name="field[pm_version]" maxlength="10" value="<?php print( $version ) ?>" class="inputbox" title="Version this task is assigned to" autocomplete="on" style="width:50px;" /></td>
												</tr>
												<tr>
													<td>Stage:</td>
													<td colspan="2">
														<select name="field[pm_stage]" style="width:200px;">
															<option value="">Select Stage</option>
															<?php 
															if( is_array($this->Stage) )
																foreach($this->Stage as $option)
																	printf("<option%s>%s</option>", ( $option === $stage) ? " selected" : "", $option);
															?>
														</select>
													</td>
												</tr>
												<tr>
													<td>Priority:</td>
													<td colspan="2">
														<select name="field[pm_priority]" style="width:200px;">
															<option value="">Select Priority</option>
															<?php 
															if( is_array($this->Priority) )
																foreach($this->Priority as $option)
																	printf("<option%s>%s</option>", ( $option === $priority ) ? " selected" : "", $option);
															?>
														</select>
													</td>
												</tr>
												<tr>
													<td>Assigned To:</td>
													<td>
														<select id="at" name="field[pm_assignee]" style="width:200px;">
															<option value="">Select Assignee</option>
															<?php 
															foreach($this->Assignee as $option)
																printf("<option%s>%s</option>", ( $option === $assignee ) ? " selected" : "", $option);
															?>
														</select>
													</td>
													<td>
														<input type="button" value="Me" onclick="SetMe('at', '<?php print( $user->data['username'] ) ?>'); return false;" />
													</td>
												</tr>
												<tr>
													<td>Link to Post:</td>
													<td colspan="2">
														<input type="text" name="field[pm_link_to_post]" maxlength="10" value="" class="inputbox" title="This task is discussed on the forums" autocomplete="on" style="width:50px;" />
													</td>
												</tr>
												<tr>
													<td>Date Started:</td>
													<td>
														<input type="text" id="ds" name="field[pm_started]" maxlength="50" value="0" class="inputbox" title="This task started on this date" autocomplete="on" style="width:100px;" />
													</td>
													<td>
														<input type="button" value="Today" onclick="SetDate('ds', '<?php print( date("Y-m-d", time()) ) ?>'); return false;" />&nbsp;(YYYY-MM-DD)&nbsp;
													</td>
												</tr>
												<tr>
													<td style="vertical-align:top;">Task Notes:</td>
													<td colspan="2">
														<textarea name="field[pm_note]" id="signature" style="height: 9em;" rows="15" cols="76" tabindex="4" class="inputbox"></textarea>
													</td>
												</tr>
												<tr>
													<td style="vertical-align:top;">Additional Info:</td>
													<td colspan="2">
														<textarea name="field[pm_other]" id="signature" style="height: 9em;" rows="15" cols="76" tabindex="4" class="inputbox"></textarea>
													</td>
												</tr>
												<tr>
													<td colspan="3" align="center">
														<input type="submit" name="cmd" value="Add" />&nbsp;
													</td>
												</tr>
												<input type="hidden" name="table_name" value="project_manager" />
											</tbody>
										</table>
										</form>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php 
	}


	// not sure if I want to use this anymore
	private function Log($id = 0) {
		global $db;
		?>
		<br />
		<div style="box-shadow: 5px 5px 5px #888888; background-color:#eee;margin-top:10px;">
		<table width="100%" border="0" cellspacing="0" class="bg2">
			<tr height="30">
				<td>&nbsp;<strong>Changelog</strong></td>
			</tr>
			<tr>
				<td width="130" class="ps_subsystem">LOG_DATE</td>
				<td width="80" class="ps_subsystem">LOG_USER</td>
				<td width="170" class="ps_subsystem">LOG_TYPE</td>
				<td class="ps_subsystem">LOG_QUERY</td>
			</tr>
			<?php 
			$data = GetChangeLog($id);
			
			if( is_array($data) ) {
				foreach($data as $log) {
					$tmp = explode(';', $log['log_data']);
					$query = substr($tmp[2], 2, strlen($tmp[2])); // 2 is always the q:
					
					// if query data gets nuts, trunc it
					//$trunc_query = ( strlen($query) > 95 ) ? substr($query, 0, 95).'...' : $query;
					
					// for now, show the whole darn thing!
					$trunc_query = $query;
					?>
					<tr valign="top">
						<td style="font-size:9px"><?php date('Y-m-d h:i:s', $log['log_time']) ?></td>
						<td style="font-size:9px"><?php $log['username'] ?></td>
						<td style="font-size:9px"><?php $log['log_operation'] ?></td>
						<td style="font-size:9px" title="<?php $log['log_data'] ?>"><?php $trunc_query ?></td>
					</tr>
					<tr>
						<td height="8"></td>
					</tr>
					<?php
				}
			}
			?>
		</table>
		</div>
		<?php
	}
	


} // END Class
?>