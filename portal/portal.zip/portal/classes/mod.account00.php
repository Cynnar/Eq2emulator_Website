<?php
if( !defined("IN_PORTAL") )
	die("Hacking attempt.");


define("IMG_PATH","/portal/images/icons/");	// all icons in these modules are in this path

class MODAccount {

	// public properties

	// private properties
	private $Accounts 		= array();
	private $Characters		= array();
	private $Servers		= array();
	private $LoginStatus 	= 0;
	private $DisableLogin 	= NULL;
	private $Count			= array();
	
	
	//
	// Constructor
	//
	public function __construct() {
		global $MOD;
		
		// alternate DB creds -- not sure I want to do this unless I replicate RunQuery locally?
		$this->db_host = $_SESSION['modules']['database'][1]['db_host'];
		$this->db_user = $_SESSION['modules']['database'][1]['db_user'];
		$this->db_pass = $_SESSION['modules']['database'][1]['db_pass'];
		$this->db_name = $_SESSION['modules']['database'][1]['db_name'];
		$this->db_port = $_SESSION['modules']['database'][1]['db_port'];
		
		//printf('%s, %s, %s, %s, %s', $this->db_host, $this->db_user, $this->db_pass, $this->db_name, $this->db_port);
		include_once("mysql.class.php");
		$this->db = new MODMysql($this->db_host, $this->db_user, $this->db_pass, $this->db_name, false);

		// set loginserver status
		$this->LoginStatus = $this->CheckLoginServerStatus();
		$this->DisableLogin = ( $this->LoginStatus === true ) ? "" : " disabled"; // set this at contruct once, and use it throughout script
	}
	
	public function _halt() {
		die("<p>Dev Debugging, please stand by...</p>");
	}
	

	/**
	 * This function counts account, server and character totals
	 */
	private function GetCounts() {
		global $user;
		
		// who are we counting?
		$where = sprintf("WHERE ((a.ip_address = '%s' OR a.key1 = '%s') OR a.`name` = '%s')", $_SERVER['REMOTE_ADDR'], $this->GetCrypt($user->data['user_id']), $_SESSION['login-account']);
		
		// accounts
		$this->SQLQuery = sprintf("SELECT COUNT(id) AS cnt FROM ".LOGIN_DATABASE.".account a %s", $where);
		$result = $this->RunQuerySingle();
		$this->Count['account'] = ( $result['cnt'] > 0 ) ? $result['cnt'] : 0;
		$result = NULL;
		
		// servers
		$this->SQLQuery = sprintf("SELECT COUNT(l.id) AS cnt FROM ".LOGIN_DATABASE.".login_worldservers l LEFT JOIN ".LOGIN_DATABASE.".account a ON l.serverop = a.name %s", $where);
		$result = $this->RunQuerySingle();
		$this->Count['server'] = ( $result['cnt'] > 0 ) ? $result['cnt'] : 0;
		$result = NULL;
		
		// characters
		$this->SQLQuery = sprintf("SELECT COUNT(c.id) AS cnt FROM ".LOGIN_DATABASE.".login_characters c LEFT JOIN ".LOGIN_DATABASE.".account a ON c.account_id = a.id %s", $where);
		$result = $this->RunQuerySingle();
		$this->Count['character'] = ( $result['cnt'] > 0 ) ? $result['cnt'] : 0;
		$result = NULL;
		
	}
	
	
	/**
	 * This function collects all the current users login account registrations for display and edit.
	 */
	private function GetAccounts() {
		global $user;
	
		// okay, don't freak out.
		// you need $query for hte logging below and $this->SQLQuery to execute the query properly.
		if( $user->data['user_id'] == 1 ) {	// anonymous
			$query = sprintf("SELECT * FROM %s.account WHERE (ip_address = '%s' OR name = '%s')", LOGIN_DATABASE, $_SERVER['REMOTE_ADDR'], $_SESSION['login-account']);
		} else { // registered
			$query = sprintf("SELECT *, unix_timestamp(last_update) AS lastseen FROM %s.account WHERE ((ip_address = '%s' OR key1 = '%s') OR name = '%s')", LOGIN_DATABASE, $_SERVER['REMOTE_ADDR'], $this->GetCrypt($user->data['user_id']), $_SESSION['login-account']);
		}
		
		// okay, don't freak out.
		// you need $query for hte logging below and $this->SQLQuery to execute the query properly.
		$this->SQLQuery = $query;
		$result = $this->RunQueryMulti();
		if ( is_array($result) ) {
			$status = 0; // counter to see if we are banned or have no accounts
			
			foreach( $result as $data ) {
				if( $data['account_status'] == 'Banned' ) {
					$status = -2;
					break;
				} elseif( $data['account_warnings'] < MAX_WARNINGS ) { //users Warnings must be < 3 to sign in
					// build the Account array
					$this->Accounts[] = $data; 
					// is the user registered, or anonymous?
					$crypto = ( $user->data['user_id'] > 1 ) ? $this->GetCrypt($user->data['user_id']) : 0;
					// only update account table if something has changed for the current account
					if( ($data['ip_address'] != $_SERVER['REMOTE_ADDR']) || ($data['key1'] != $crypto) ) {
						// update account with current information
						$this->RunQuery(sprintf("UPDATE %s.account SET ip_address = '%s', key1 = '%s' WHERE id = '%s'", LOGIN_DATABASE, $_SERVER['REMOTE_ADDR'], $crypto, $data['id']));
					}
					$status++;
				} else {
					// autoban
					/*$sql = sprintf("UPDATE %s.account SET ip_address = '%s', key1 = '%s' WHERE id = '%s')", 
																 LOGIN_DATABASE, 
																 $_SERVER['REMOTE_ADDR'], 
																 $crypto, 
																 $data['id']);
		
					if( !$result1 = $db2->sql_query($sql) ) 
						die('FATAL: Auto-Ban failure in GetLogins()');
	
					return -1;*/
				}
			}
		}
		
		switch($status) {
			
			case -2:
				$log_array['log_type'] 			= 'Player';
				$log_array['log_operation'] = 'PLAYER_MANAGER_ACCOUNT_BAN';
				$log_array['log_data']			= sprintf("i:%s;u:%s;q:%s;", $_GET['id'], $_SESSION['login-account'], $this->SQLEscape($query));
				log_action( $log_array );
				session_unset($_SESSION['login-account']);
				print('<p style="text-align:center; color:#FF0000; font-size:11px; font-weight:bold; height:40px;">Your account has been banned due to excessive hacking attempts.<br />Contact a forum administrator for assistance.</p>');
				break;
			case 0:
				$log_array['log_type'] 			= 'Player';
				$log_array['log_operation'] = 'PLAYER_MANAGER_ACCOUNT_LOGIN';
				$log_array['log_data']			= sprintf("i:%s;u:%s;q:%s;", $_GET['id'], $_SESSION['login-account'], $this->SQLEscape($query));
				log_action( $log_array );
				session_unset($_SESSION['login-account']);
				print('<p style="text-align:center; color:#FF0000; font-size:11px; font-weight:bold; height:40px;">Could not find your Login Account(s)! Contact a forum administrator for assistance.</p>');
				break;
		}
	}
			
	
	/**
	 * This function collects all the current users character registrations for display and edit.
	 */
	private function GetCharacters() {
		global $user;
		
		$common_select = sprintf("SELECT la.id AS account_id, la.name AS account_name, lc.id AS login_character_id, lc.name AS character_name, lw.name AS world_name, lc.deleted, UNIX_TIMESTAMP(lc.created_date) AS created_date, UNIX_TIMESTAMP(lc.last_played) AS last_played, lc.char_id AS world_character_id " .
								 "FROM ".LOGIN_DATABASE.".account la " .
								 "LEFT JOIN ".LOGIN_DATABASE.".login_characters lc ON la.id = lc.account_id " .
								 "LEFT JOIN ".LOGIN_DATABASE.".login_worldservers lw ON lc.server_id = lw.id");

		
		// handle getting world accounts for anonymous users
		if( $user->data['user_id'] == 1 ) // anonymous
			$this->SQLQuery = sprintf("%s WHERE lc.account_id = la.id AND (la.name = '%s' OR la.ip_address = '%s')", $common_select, $_SESSION['login-account'], $_SERVER['REMOTE_ADDR']);
		else	// registered
			$this->SQLQuery = sprintf("%s WHERE la.key1 = '%s'", $common_select, $this->GetCrypt($user->data['user_id']));
	
		$this->Characters = $this->RunQueryMulti();
	}
	

	/**
	 * This function collects all the current users world account registrations for display and edit.
	 */
	function GetServers() {
		global $user;
	
		// handle getting world accounts for anonymous users
		if( $user->data['user_id'] == 1 ) {
			// anonymous
			$this->SQLQuery = sprintf("SELECT lw.*, ls.world_status
										FROM ".LOGIN_DATABASE.".account la
										JOIN ".LOGIN_DATABASE.".login_worldservers lw ON la.name = lw.serverop
										LEFT JOIN ".LOGIN_DATABASE.".login_worldstats ls ON lw.id = ls.world_id
										WHERE (la.name = '%s' OR la.ip_address = '%s')", 
										$_SESSION['login-account'], 
										$_SERVER['REMOTE_ADDR']);
			$data = $this->RunQueryMulti(); 
			if( is_array($data) ) {
				foreach( $data as $server ) {
					if( $server['account_warnings'] < 3 ) { // users hack_count must be < 3 to sign in
						// anonymous worlds (no forum account) only have an IP address in the DB
						if( $server['ip_address'] != $_SERVER['REMOTE_ADDR'] )
							$this->RunQuery(sprintf("UPDATE ".LOGIN_DATABASE.".login_worldservers SET ip_address = '%s' WHERE id = %s", $_SERVER['REMOTE_ADDR'], $server['id']));
					} else {
						return -1;
					}
				}
			}
		} else {
			// registered
			$this->SQLQuery = sprintf("SELECT lw.*, ls.world_status
										FROM ".LOGIN_DATABASE.".account a
										JOIN ".LOGIN_DATABASE.".login_worldservers lw ON a.name = lw.serverop
										LEFT JOIN ".LOGIN_DATABASE.".login_worldstats ls ON lw.id = ls.world_id
										WHERE a.key1 = '%s';", $this->GetCrypt($user->data['user_id']));
	
			//printf("<p>Registered: %s</p>", $query);
			$data = $this->RunQueryMulti();
			if( is_array($data) ) {
				foreach( $data as $server ) {
					if( $server['account_warnings'] < 3 ) { // users hack_count must be < 3 to sign in
						// if the key1 is not set, update it with the current key + update the IP address of matching accounts
						if( $server['ip_address'] != $_SERVER['REMOTE_ADDR'] )
							$this->RunQuery(sprintf("UPDATE ".LOGIN_DATABASE.".login_worldservers SET ip_address = '%s' WHERE id = %s", $_SERVER['REMOTE_ADDR'], $server['id']));
					} // account_warnings
					else
						return -1;
				} // while
			} // results
		} // registered
		
		$this->Servers = $data;
	}
		
	
	/*
		Counts active, deleted and a sum of the two (total) per server for display on Server Maintenance page
	*/
	private function GetCharacterCounts($serverId) {
		
		$this->SQLQuery = sprintf("SELECT COUNT(*) AS cnt FROM ".LOGIN_DATABASE.".login_characters WHERE server_id = %s GROUP BY deleted", $serverId);
		$data = $this->RunQueryMulti();
		
		if( is_array( $data ) ) {
			foreach( $data as $result ) {
				$tmp[] .= $result['cnt'];
			}
		}
		
		// there should be only 3 values; active, deleted, and total
		$rtn['active'] = ( $tmp[0] > 0 ) ? $tmp[0] : 0;
		$rtn['deleted'] = ( $tmp[1] > 0 ) ? $tmp[1] : 0;
		$rtn['total'] = $tmp[0] + $tmp[1];
		
		return $rtn;
	}
	
	
	// very simple crypto function
	private function GetCrypt($key)
	{
		return hash("sha256", md5($key));
	}


	private function CountServersByAccountName($acc_name) {
		$this->SQLQuery = sprintf("SELECT COUNT(*) AS cnt FROM ".LOGIN_DATABASE.".login_worldservers WHERE serverop = '%s'", $acc_name);
		$row = $this->RunQuerySingle();
		return ($row['cnt'] > 0) ? $row['cnt'] : 0;
	}
	
	
	private function CountServersByIPAddress($ip) {
		$this->SQLQuery = sprintf("SELECT COUNT(*) AS cnt FROM ".LOGIN_DATABASE.".login_worldservers WHERE ip_address = '%s'", $ip);
		$row = $this->RunQuerySingle();
		return ($row['cnt'] > 0) ? $row['cnt'] : 0;
	}
	
	
	private function CountCharactersByAccountID($id) {
		$this->SQLQuery = sprintf("SELECT COUNT(char_id) AS cnt FROM ".LOGIN_DATABASE.".login_characters WHERE account_id = %s", $id); 
		$row = $this->RunQuerySingle();
		return ($row['cnt'] > 0) ? $row['cnt'] : 0;
	}
	
	

	private function SetServerStatus($server) {
		switch($server['world_status']) {
					case NULL:
					case "-4":
						$this->ServerColor	= 'high.png'; // offline
						$this->ServerStatus = sprintf('Offline since %s', date("Y/m/d h:i a", $server['lastseen']));
						break;
					case "-2":
						$this->ServerColor	= "locked.png";
						$this->ServerStatus = 'Private';
						break;
					default:
						$this->ServerColor	= "low.png"; // online
						$this->ServerStatus = 'Low';
						break;
		}
	}
	
	private function SetServerType( $type ) {
	
		switch($type) {
			case 1:
				$this->ServerType = "PvP";
				break;
			case 2:
				$this->ServerType = "RP";
				break;
			case 3:
				$this->ServerType = "PvE/RP";
				break;
			case 4:
				$this->ServerType = "PvP/RP";
				break;
			case 5:
				$this->ServerType = "PvP/Teams";
				break;
			case 6:
				$this->ServerType = "Pvt";
				break;
			case 7:
				$this->ServerType = "Dev";
				break;
			case 8:
				$this->ServerType = "Other";
				break;
			case NULL:
			default:
				$this->ServerType = "PvE";
				break;
		}
	}


	/**
	 * Local function to check if loginserver heartbeat is within 'n' seconds
	 *
	 * TODO: make max tmeout a config param?
	 */
	public function CheckLoginServerStatus() {
		$this->SQLQuery = sprintf("SELECT COUNT(*) AS login_active FROM ".LOGIN_DATABASE.".login_config WHERE config_name = 'login_heartbeat' AND config_value >= UNIX_TIMESTAMP(NOW()) - %s", MAX_LOGIN_HEARTBEAT);
		$result = $this->RunQuerySingle();
		return ( $result['login_active'] > 0 ) ? true : false;
	}
		
		
	/*
		This function counts the current account registrations for the users $login_ip_address.
		If greater-than the max_accounts_per_ip value, the user cannot create additional accounts until one is deleted.
	
		This is mostly to stop spam account generation.
	*/
	function CheckLoginAccounts() {
		global $user;
	
		if( $user->data['user_id'] == 1 ) 	// anonymous
			$this->SQLQuery = sprintf("SELECT COUNT(id) AS cnt FROM ".LOGIN_DATABASE.".account WHERE ip_address = '%s'", $_SERVER['REMOTE_ADDR']);	
		else								// registered
			$this->SQLQuery = sprintf("SELECT COUNT(id) AS cnt FROM ".LOGIN_DATABASE.".account WHERE ip_address = '%s' OR key1 = '%s'", $_SERVER['REMOTE_ADDR'], $this->GetCrypt($user->data['user_id']));	
	
		$row = $this->RunQuerySingle();
		return ($row['cnt'] > 0) ? $row['cnt'] : 0; // if more than ZERO, return the count, or return ZERO
	}
		
		
	/*
		This function checks if the account already exists.
		If it does, the user is prompted that they must pick a different login account name.
	*/
	private function CheckLoginAccountName( $login_name ) {
		$this->SQLQuery = sprintf("SELECT COUNT(*) AS cnt FROM ".LOGIN_DATABASE.".account WHERE name = '%s';", $login_name);
		$row = $this->RunQuerySingle();
		return ( $row['cnt'] > 0 ) ? true : false;
	}
	
	
	/**
	 * This function checks if the world account already exists.
	 * If it does, the user is prompted that they must pick a different world account name.
	 */
	private function CheckServerAccount( $world_name ) {
		$this->SQLQuery = sprintf("SELECT COUNT(*) AS cnt FROM ".LOGIN_DATABASE.".login_worldservers WHERE `name` = '%s'", $world_name);
		$result = $this->RunQuerySingle();
		if ($result['cnt'] > 0) {
			return true;
		}
		return false;
	}
	
	
	/**
	 * This function checks if the world name already exists.
	 * If it does, the user is prompted that they must pick a different world name.
	 */
	function CheckServerName( $world_name ) {
		$this->SQLQuery = sprintf("SELECT COUNT(*) AS cnt FROM ".LOGIN_DATABASE.".login_worldservers WHERE `name` = '%s'", $world_name);
		$result = $this->RunQuerySingle();
		if ($result['cnt'] > 0) {
			return true;
		}
		return false;
	}
	
	
	/**
	 * This function verifies the supplied player login account is valid.
	 */
	private function ValidateAccount($login_account_name, $login_account_password) {
		$this->SQLQuery = sprintf("SELECT COUNT(*) AS cnt FROM ".LOGIN_DATABASE.".account WHERE name = '%s' and passwd = '%s'", $login_account_name, $login_account_password);
		$result = $this->RunQuerySingle();
		if ($result['cnt'] > 0) {
			return true;
		}
		return false;
	}
	

	public function Account() {
		global $MOD;
	?>
		<div id="section">
			<ul>
				<li class="section-title">Account Management<?php 
				// TODO: Turn this into jaavascript update from footer?
				if( strlen($_SESSION['login-account']) > 0 ) {
					printf(" - Logged in as: %s", $_SESSION['login-account']);
				} ?></li>
			</ul>
		</div>
		<?php
		switch($_POST['cmd']) {

			case "Login"	: 
				$this->DoLogin(); 
				
				if( isset($_SESSION['login-account']) )
					$this->AccountManager();
				else
					$this->ShowLogin();
				break;
				
			case "Logout"	: 
				$this->DoLogout(); 
				$this->ShowLogin();
				break;
		
			case "Create Account":
				if( $_POST['action'] == "add_account" )
					$this->ShowCreateAccountDialog();
				else
				{
					$this->DoCreateAccount();
					
					if( isset($_SESSION['login-account']) )
						$this->AccountManager();
					else
						$this->ShowCreateAccountDialog();
				}
				break;
			
			case "Create Server":
				if( $_POST['action'] == "add_server" )
					$this->ShowCreateServerDialog();
				else
				{
					$this->DoCreateServer();
					$this->AccountManager();
				}
				break;
		
			case "Update Account": 
				$this->DoUpdateAccount(); 
				$this->AccountManager();
				break;
		
			case "Update Server": 
				$this->DoUpdateServer(); 
				$this->AccountManager();
				break;
	
			case "Delete": // this is deleting Characters that are already deleted
				if( intval($_POST['delete_ok']) > 0 )
				{
					$this->DoDeleteCharacter();
					$MOD->AddStatus('Deleted character '.$_POST['login_character_name'].' from server '.$_POST['server_name'].' - Successful!');
					$this->AccountManager();
				}
				else
				{
					$this->ShowDeleteCharacterCheck();
					if( sizeof($MOD->Status) > 0 )
						$this->AccountManager();
				}
				break;
			
			case "Delete Account":
				if( intval($_POST['delete_ok']) > 0 )
				{
					$this->DoDeleteAccount();
					
					if( $_POST['account_name'] == $_SESSION['login-account'] )
					{
						session_unset($_SESSION['login-account']);
						$MOD->AddStatus("Deleted current login account. Please log back in using a different account.");
						$this->ShowLogin();
					}
					else
						$this->AccountManager();
				}
				else
				{
					$this->ShowDeleteAccountCheck();
					if( sizeof($MOD->Status) > 0 )
						$this->AccountManager();
				}
				break;
				
			case "Delete Server": 
				if( intval($_POST['delete_ok']) > 0 )
				{
					$this->DoDeleteServer();
					$this->AccountManager();
				}
				else
				{
					$this->ShowDeleteServerCheck();
					if( sizeof($MOD->Status) > 0 )
						$this->AccountManager();
				}
				break;
			
			case "Grant Access":
				$this->DoGrantAccess();
				$this->AccountManager();
				break;
				
			case "Revoke Access":
				$this->DoRevokeAccess();
				$this->AccountManager();
				break;
				
			default:
				if( empty($_SESSION['login-account']) )
					$this->ShowLogin();
				else
					$this->AccountManager();
		}
	}


	private function AccountManager() {
		global $MOD;

		// Need to load these here, since updates occur above this call
		$this->GetAccounts();	// set $this->Accounts
		$this->GetCharacters();	// set $this->Characters
		$this->GetServers();	// set $this->Servers
		

		?>
		<div class="post bg1">
			<div class="inner">
				<div class="postbody">
					<div class="content">
					<p style="text-align:center; color:#F00; font-weight:bold;">
					<?php
					// Error handler
					if( strlen($MOD->Status) > 0 )
						print($MOD->Status);
					?>
					</p>
					</div>
				</div>
				<br />
				<div id="mmtabs">
					<ul>
						<li<?php if($_GET['tab']=="welcome" || empty($_GET['tab']) ) print(' id="activetab"') ?>><a href="<?= $MOD->FullPage ?>&tab=welcome" style="width:100px; text-align:center;"><span>Welcome</span></a></li>
						<li<?php if($_GET['tab']=="accounts" ) print(' id="activetab"') ?>><a href="<?= $MOD->FullPage ?>&tab=accounts" style="width:100px; text-align:center;"><span>My Accounts</span></a></li>
						<li<?php if($_GET['tab']=="characters" ) print(' id="activetab"') ?>><a href="<?= $MOD->FullPage ?>&tab=characters" style="width:120px; text-align:center;"><span>My Characters</span></a></li>
						<li<?php if($_GET['tab']=="servers" ) print(' id="activetab"') ?>><a href="<?= $MOD->FullPage ?>&tab=servers" style="width:100px; text-align:center;"><span>My Servers</span></a></li>						
						<!--<li<?php if($_GET['tab']=="permissions" ) print(' id="activetab"') ?>><a href="<?= $MOD->FullPage ?>&tab=permissions" style="width:100px; text-align:center;"><span>Permissions</span></a></li>-->
					</ul>
				</div>
				<div class="postbody">
					<div class="content">
					<?php
					switch($_GET['tab'])
					{
						case "accounts"		: $this->ShowAccountsTab(); break;
						case "characters"	: $this->ShowCharactersTab(); break;
						case "servers"		: $this->ShowServersTab(); break;
						//case "permissions"	: $this->ShowPermissionsTab(); break;
						default				: $this->ShowWelcomeTab(); break;
					}
					?>
					<form method="post" name="account-logout">
					<p align="center">
					<input type="submit" name="cmd" value="Logout" />
					</p>
					</form>
					</div>
				</div>
			</div>
		</div>
		<?php
	}


	private function ShowWelcomeTab() {
		
		$this->GetCounts(); // gets account, server and character counts
		
		?>
		<p>Welcome to the Account Manager portal. Here you can maintain your Login (player) accounts, server accounts, and view the characters you have created on various private servers.</p>
		<div id="section">
			<ul style="margin-left:0px;">
				<li class="section-title">Account Statistics</li>
			</ul>
		</div>
		<table border="0" style="margin-left:10px;">
			<col />
			<col width="50" />
			<tr>
				<td align="right"><strong>Number of Login Accounts</strong></td>
				<td>:&nbsp;<?php print($this->Count['account']); ?></td>
			</tr>
			<tr>
				<td align="right"><strong>Number of Servers</strong></td>
				<td>:&nbsp;<?php print($this->Count['server']); ?></td>
			</tr>
			<tr>
				<td align="right"><strong>Number of Characters</strong></td>
				<td>:&nbsp;<?php print($this->Count['character']); ?></td>
			</tr>
		</table>
		<br />
		<div id="section">
			<ul style="margin-left:0;">
				<li class="section-title">Accounts Overview</li>
			</ul>
		</div>
		<table width="100%" border="0" cellspacing="0" style="margin-top:-10px;">
			<col width="50" />
			<col />
			<col width="150" />
			<col width="100" />
			<col width="100" />
			<col width="100" />
			<col width="70" />
			<col width="70" />
			<col width="100" />
			<tr>
				<th class="AccountManager">ID</th>
				<th class="AccountManager" style="text-align:left;">Account</th>
				<th class="AccountManager" style="text-align:left;">Email</th>
				<th class="AccountManager"># Logins</th>
				<th class="AccountManager"># Servers</th>
				<th class="AccountManager"># Chars</th>
				<th class="AccountManager">Status</th>
				<th class="AccountManager">Warnings</th>
				<th class="AccountManager" align="right">Created</th>
			</tr>
			<?php
			if( is_array($this->Accounts) ) {
				$i = 0;
				foreach($this->Accounts as $account) {
					$RowColor = ( $i % 2 ) ? ' class="row1"' : 'class="row2"';
					$i++;
					$server_count = $this->CountServersByAccountName($account['name']);
					$char_count = $this->CountCharactersByAccountID($account['id']);
				?>
				<tr<?php print($RowColor) ?>>
					<td class="AccountManager"><?= $account['id'] ?></td>
					<td class="AccountManager"><?= $account['name'] ?></td>
					<td class="AccountManager"><?= $account['email_address'] ?></td>
					<td class="AccountManager" align="center"><?= $account['login_count'] ?></td>
					<td class="AccountManager" align="center"><?= $server_count ?></td>
					<td class="AccountManager" align="center"><?= $char_count ?></td>
					<td align="center"><?= $account['account_status'] ?></td>
					<td align="center"><?= $account['account_warnings'] ?></td>
					<td class="AccountManager" align="right"><?php ( $account['created_date'] > 0 ) ? print(date("M-d-Y", $account['created_date'])) : "Unknown"; ?></td>
				</tr>
				<?php
					$total_logins += $login_count;
					$total_servers += $server_count;
					$total_chars += $char_count;
				} // end foreach
				
				// totals
				$RowColor = ( $i % 2 ) ? ' class="row1"' : 'class="row2"';
				?>
				<tr<?php print($RowColor) ?>>
					<td class="AccountManager" colspan="3" style="font-size:1.2em; text-align:right;"><strong>Totals:</strong></td>
					<td class="AccountManager" style="font-size:1.2em; text-align:center; border-top:2px solid #666;"><?= $total_logins ?></td>
					<td class="AccountManager" style="font-size:1.2em; text-align:center; border-top:2px solid #666;"><?= $total_servers ?></td>
					<td class="AccountManager" style="font-size:1.2em; text-align:center; border-top:2px solid #666;"><?= $total_chars ?></td>
					<td class="AccountManager" colspan="3">&nbsp;</td>
				</tr>
				<?php
			}
			?>
		</table>
		<br />
		<div id="section">
			<ul style="margin-left:0;">
				<li class="section-title">Servers Overview</li>
			</ul>
		</div>
		<table width="100%" border="0" cellspacing="0" style="margin-top:-10px;">
			<col width="50" />
			<col />
			<col width="150" />
			<col width="150" />
			<col width="50" />
			<col width="80" />
			<col width="80" />
			<tr>
				<th class="AccountManager">ID</th>
				<th class="AccountManager" style="text-align:left;">Name</th>
				<th class="AccountManager" style="text-align:left;">Account</th>
				<th class="AccountManager" style="text-align:left;">IP Address</th>
				<th class="AccountManager">Status</th>
				<th class="AccountManager">Type</th>
				<th class="AccountManager" align="right">Created</th>
			</tr>
			<?php
			if( is_array($this->Servers) ) {
				foreach($this->Servers as $world) {
					$RowColor = ( $i % 2 ) ? ' class="row1"' : 'class="row2"';
					$i++;
					$this->SetServerStatus($world);
					$this->SetServerType($world['server_type']);
					$status = sprintf('<img src="%s" width="15" border="0" title="%s" />',IMG_PATH.$this->ServerColor, $this->ServerStatus);
				?>
				<tr<?php print($RowColor) ?>>
					<td class="AccountManager"><?= $world['id'] ?></td>
					<td class="AccountManager"><?= $world['name'] ?></td>
					<td class="AccountManager"><?= $world['serverop'] ?></td>
					<td class="AccountManager"><?= $world['ip_address'] ?></td>
					<td class="AccountManager" align="center"><?= $status ?></td>
					<td class="AccountManager" align="center"><?= $this->ServerType ?></td>
					<td class="AccountManager" align="right"><?php print(date("M-d-Y", $world['created_date'])); ?></td>
				</tr>
				<?php
				}
				$RowColor = ( $i % 2 ) ? ' class="row1"' : 'class="row2"';
				?>
				<tr<?php print($RowColor) ?>>
					<td class="AccountManager" colspan="7" style="font-size:1.2em; text-align:right;"><?php print(count($this->Servers)); ?> records found</td>
				</tr>
				<?php
			} else {
				?>
				<tr class="row2">
					<td class="AccountManager" colspan="7" style="font-size:1.2em; text-align:right;">No records found</td>
				</tr>
				<?php
			}
			?>
		</table>
		<br />
		<div id="section">
			<ul style="margin-left:0;">
				<li class="section-title">Characters Overview</li>
			</ul>
		</div>
		<table width="100%" border="0" cellspacing="0" style="margin-top:-10px;">
			<tr>
				<th class="AccountManager">ID</th>
				<th class="AccountManager" style="text-align:left;">Name</th>
				<th class="AccountManager" style="text-align:left;">Account</th>
				<th class="AccountManager" style="text-align:left;">Server</th>
				<th class="AccountManager">Deleted</th>
				<th class="AccountManager" style="text-align:right;">Created On</th>
				<th class="AccountManager" style="text-align:right;">Last Played</th>
			</tr>
			<?php
			if( is_array($this->Characters) ) {
				foreach($this->Characters as $character) {
					// if char is deleted, reset rowcolor
					if( $character['deleted'] ) {
						$RowStyle =  ' style="background-color:#fff; color:#aaa; font-style:italic;"';
						$i = 0;
					} else {
						$RowStyle =  '';
					}
					
					$RowColor = ( $i % 2 ) ? ' class="row1"' : ' class="row2"';
					$i++;
				?>
				<tr<?= $RowColor .$RowStyle ?>>
					<td class="AccountManager"><?= $character['login_character_id'] ?></td>
					<td class="AccountManager"><?= $character['character_name'] ?></td>
					<td class="AccountManager"><?= $character['account_name'] ?>&nbsp;(<?= $character['account_id'] ?>)</td>
					<td class="AccountManager"><?= $character['world_name'] ?></td>
					<td class="AccountManager" align="center"><?= $character['deleted'] ?></td>
					<td class="AccountManager" align="right"><?php print(date("M-d-Y", $character['created_date'])); ?></td>
					<td class="AccountManager" align="right"><?php ( $character['last_played'] > 0 ) ? print(date("M-d-Y", $character['last_played'])) : print("N/a"); ?></td>
				</tr>
				<?php
				}
				$RowColor = ( $i % 2 ) ? ' class="row1"' : 'class="row2"';
				?>
				<tr<?php print($RowColor) ?>>
					<td class="AccountManager" colspan="7" style="font-size:1.2em; text-align:right;"><?php print(count($this->Characters)); ?> records found</td>
				</tr>
				<?php
			} else {
				?>
				<tr class="row2">
					<td class="AccountManager" colspan="7" style="font-size:1.2em; text-align:right;">No records found</td>
				</tr>
				<?php
			}
			?>
		</table>
		<?php
	}
	
	
	private function ShowAccountsTab() {
		?>
		<table width="100%" border="0" cellspacing="0">
			<tr>
				<td colspan="4" valign="top" height="50">
					You may change the password of your existing Login Account, or Delete the account entirely.<br />
					<br />
				  <em>Note that if you delete the account, all characters linked to that account (on every server) will be orphaned.</em> 
				</td>
			</tr>
		</table>
		<?
		
		if( empty($_SESSION['login-account']) )
			return;
		
		if( !is_array($this->Accounts) ) 
			return;
			
		foreach($this->Accounts as $login) {
		?>
		<div id="section">
			<ul style="margin-left:0;">
				<li class="section-title">Account: <?php printf('%s (ID: %s)', $login['name'], $login['id']) ?></li>
			</ul>
		</div>
		<form method="post" name="account_<?php print($login['id']) ?>">
		<table width="100%" cellpadding="4" border="0">
			<col width="25%" />
			<col width="25%" />
			<col width="25%" />
			<col width="25%" />
			<tr>
				<td align="right"><strong>Account Name:</strong></td>
				<td><input type="text" name="login_account_name" value="<?php print($login['name']); ?>" size="32" maxlength="64" title="your login name" readonly style="background-color:#ddd;"/></td>
				<td align="right"><strong>IP Address:</strong></td>
				<td><?php print($login['ip_address']); ?></td>
			</tr>
			<tr>
				<td align="right"><strong>Email Address:</strong></td>
				<td >
					<input type="text" name="login_account_email" value="<?php print($login['email_address']); ?>" size="32" maxlength="64" title="your email address" />
					<input type="hidden" name="orig_login_account_email" value="<?php print($login['email_address']); ?>" />
				</td>
				<td align="right"><strong>Account Created:</strong></td>
				<td><?php print(date("M-d-Y", $login['created_date'])); ?></td>
			</tr>
			<tr>
				<td align="right"><strong>Current Account Password:</strong></td>
				<td><input type="password" name="login_current_password" value="" size="32" maxlength="64" title="your current login account password" /></td>
				<td align="right"><strong>Last Seen:</strong></td>
				<td><?php print(date("M-d-Y", $login['lastseen'])); ?></td>
			</tr>
			<tr>
				<td align="right"><strong>Change Account Password:</strong></td>
				<td><input type="password" name="login_account_password1" value="" size="32" maxlength="64" title="change your login account password" /></td>
				<td align="right"><strong>Hack Count:</strong></td>
				<td><?php print($login['hack_count']); ?></td>
			</tr>
			<tr>
				<td align="right"><strong>Verify Account Password:</strong></td>
				<td><input type="password" name="login_account_password2" value="" size="32" maxlength="64" title="verify your login account password change" /></td>
				<td align="right"><strong>Account Status:</strong></td>
				<td><?php ( $login['account_enabled'] == 1 ) ? print('Enabled') : print('Disabled'); ?></td>
			</tr>
			<tr>
				<td colspan="2">&nbsp;</td>
				<td align="right"><strong>Warnings:</strong></td>
				<td>0 <?php //print($login['account_warnings']); ?></td>
			</tr>
			<tr>
				<td align="center" colspan="4"><em>Current Account Password required to make changes or delete account!</em></td>
			</tr>
			<tr>
				<td colspan="4" align="center" valign="bottom" height="40">
					<input type="submit" name="cmd" class="submit" value="Update Account" />
					<?php if( $_SESSION['modules']['config']['allow_account_delete'] == 1 ) { ?>
					<input type="submit" name="cmd" value="Delete Account" />
					<? } ?>
				</td>
			</tr>
		</table>
		<input type="hidden" name="account_id" value="<?= $login['id'] ?>" />
		<input type="hidden" name="account_name" value="<?= $login['name'] ?>" />
		</form>
		<?php
			$i++;
		} // end while
		?>
		<form method="post" name="create-login">
		<table align="center" border="0" width="100%">
			<col width="25%" />
			<col width="25%" />
			<col width="25%" />
			<col width="25%" />
			<tr height="30" valign="bottom">
				<td>
					<?= $i ?> of <?= $_SESSION['modules']['config']['max_accounts_per_ip'] ?> Login Accounts in use.
				</td>
				<td colspan="2" align="center">
					<?php 
					if( $i < $_SESSION['modules']['config']['max_accounts_per_ip'] )
						printf('<input type="submit" name="cmd" value="Create Account" alt="Create a Login Account" %s />', $this->DisableLogin);
					else
						print('<span style="color:#aaa">Cannot create a new Login Account: Already at max accounts</span>');
					?>
				</td>
				<td>&nbsp;</td>
			</tr>
		</table>
		<input type="hidden" name="action" value="add_account" />
		</form>
		<?php
	}
	
	private function ShowCharactersTab() {
		
		?>
		<table width="100%" border="0">
			<tr>
				<td valign="middle" height="50">
					<strong>Note:</strong>This character list is only to help players delete orphaned characters on servers that have been reset or are offline.
				</td>
			</tr>
		</table>
		<?
		
		if( empty($_SESSION['login-account']) )
			return;
		
		if( !is_array( $this->Characters ) ) 
			return;
			
		?>
		<div id="section">
			<ul style="margin-left:0;">
				<li class="section-title">My Characters</li>
			</ul>
		</div>
		<table align="center" cellspacing="0" border="0" width="100%">
			<tr>
				<td valign="top"><br />
					<strong>Filter</strong>:&nbsp;
					<select onchange="dosub(this.options[this.selectedIndex].value)">
						<option value="index.php?p=account&tab=characters"<?php if( empty($_GET['show']) ) echo " selected" ?>>All</option>
						<option value="index.php?p=account&tab=characters&show=1"<?php if( $_GET['show'] == 1 ) echo " selected" ?>>Active</option>
						<option value="index.php?p=account&tab=characters&show=2"<?php if( $_GET['show'] == 2 ) echo " selected" ?>>Deleted</option>
					</select>
					<br />&nbsp;
				</td>
			</tr>
			<tr>
				<td colspan="2" valign="top">
					<table width="100%" border="0" cellspacing="0">
						<colgroup>
							<col width="50" />
							<col width="100" />
							<col width="100" />
							<col width="100" />
							<col width="70" />
							<col width="70" />
							<col width="70" />
							<col width="70" />
						</colgroup>
						<tr style="background-color:#666; color:#fff; font-weight:bold; font-size:12px;">
							<td>ID</td>
							<td>Name</td>
							<td>Account</td>
							<td>Server</td>
							<td align="right">Created On</td>
							<td align="right">Last Played</td>
							<td align="center">Deleted</td>
							<td>&nbsp;</td>
						</tr>
						<?php
						$i = 0; $total = 0;
						foreach($this->Characters as $character) {
							
							if( $_GET['show'] == 1 && $character['deleted'] == 1 )
								continue;
							if( $_GET['show'] == 2 && $character['deleted'] == 0 )
								continue;
							/*if( $character['deleted'] == 1 )
								continue;*/

							// if char is deleted, reset rowcolor
							if( $character['deleted'] ) {
								$RowStyle =  ' style="background-color:#fff; color:#aaa; font-style:italic;"';
								$i = 0;
							} else {
								$RowStyle =  '';
							}
							
							$RowColor = ( $i % 2 ) ? ' class="bg1"' : ' class="bg2"';
							$i++;
		
						?>
						<form method="post" name="charDel|<?= $character['login_character_id'] ?>">
						<tr<?= $RowColor . $RowStyle ?>>
							<td><?= $character['login_character_id'] ?></td>
							<td><?= $character['character_name'] ?></td>
							<td><?= $character['account_name'] ?>&nbsp;(<?= $character['account_id'] ?>)</td>
							<td><?= $character['world_name'] ?></td>
							<td align="right"><?php print(date("M-d-Y", $character['created_date'])); ?></td>
							<td align="right"><?php ( $character['last_played'] > 0 ) ? print(date("M-d-Y", $character['last_played'])) : print("N/a"); ?></td>
							<td align="center"><?= $character['deleted'] ?></td>
							<td align="right">
							<?php if( $_SESSION['modules']['config']['allow_character_delete'] == 1 ) { ?>
								<input type="submit" name="cmd" value="Delete" class="CharacterDelete" />
							<?php } ?>
							</td>
						</tr>
						<input type="hidden" name="login_character_id" value="<?= $character['login_character_id'] ?>" />
						<input type="hidden" name="login_character_name" value="<?= $character['character_name'] ?>" />
						<input type="hidden" name="server_name" value="<?= $character['world_name'] ?>" />
						<input type="hidden" name="is_orphaned" value="<?= $character['deleted'] ?>" />
						</form>
						<?php
						$total++;
						
						}
						$RowColor = ( $i % 2 ) ? ' class="row1"' : 'class="row2"';
						?>
						<tr<?php print($RowColor) ?>>
							<td class="AccountManager" colspan="8" style="font-size:1.2em; text-align:right;"><?php print($total); ?> records found</td>
						</tr>
					</table>
				</td>
			</tr>
			<tr>
				<td height="8"></td>
			</tr>
		</table>
		<?php
	}
	
	private function ShowServersTab() {
		global $user;
	
		$i = 0;
		?>
		<table width="100%" border="0" class="bg2">
			<tr>
				<td valign="top" height="50">
					<div style="float:right; vertical-align:top;"><em>Server Count</em>: <?= count($this->Servers) ?>&nbsp;&nbsp;</div> 
					You may change various settings of your existing Server Account, or Delete the server entirely.<br />
					<br />
					<em>Note that if you delete the server, all characters linked to that server will be orphaned.</em>
					
				</td>
			</tr>
		</table>
		<?
		
		if( empty($_SESSION['login-account']) )
			return;
		
		

		if( is_array( $this->Servers ) ) {
			foreach($this->Servers as $world) {
			?>
			<div id="section">
				<ul style="margin-left:0;">
					<li class="section-title">World: <?php printf("%s (%s)", $world['name'], $world['serverop']) ?></li>
				</ul>
			</div>
			<form method="post" name="server_<?= $world['id'] ?>">
			<table width="100%" border="0">
				<col width="20%" />
				<col width="30%" />
				<col width="25%" />
				<col width="25%" />
				<tr>
					<td class="Label">World ID:</td>
					<td class="Detail" title="your world ID">&nbsp;<?php print($world['id']); ?></td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td class="Label">World Name:</td>
					<td class="Detail" title="your world name">
						<input type="text" name="server|name" value="<?php print($world['name']); ?>" class="login" />
						<input type="hidden" name="orig_name" value="<?php print($world['name']); ?>" />
					</td>
					<td class="Label">Created On:</td>
					<td class="Detail"><?php print(($world['created_date']) ? date('M-d-Y',$world['created_date']) : 'Unknown.'); ?></td>
				</tr>
				<tr>
					<td class="Label">World Account:</td>
					<td class="Detail" title="your world account name">
						<input type="text" name="server|account" value="<?php print($world['account']); ?>" class="login" />
						<input type="hidden" name="orig_account" value="<?php print($world['account']); ?>" />
					</td>
					<td class="Label">Last Seen:</td>
					<td class="Detail"><?php print(($world['lastseen']) ? date('M-d-Y',$world['lastseen']) : 'Never.'); ?></td>
				</tr>
				<tr>
					<td class="Label">Change World Password:</td>
					<td class="Detail" title="change your world account password"><input type="password" name="server|password" value="" class="login" /></td>
					<td class="Label">Server Category:</td>
					<td class="Detail"><?php print($world['server_category']); ?></td>
				</tr>
				<tr>
					<td class="Label">Verify World Password:</td>
					<td class="Detail" title="verify your world account password change"><input type="password" name="password2" value="" class="login" /></td>
					<td class="Label">Server Status:</td>
					<td class="Detail"><?php ( $world['world_status'] === NULL ) ? print("Down") : print($world['world_status']); ?></td>
				</tr>
				<tr>
					<td class="Label">World Operator:</td>
					<td class="Detail" title="your name">
						<input type="text" name="server|serverop" value="<?php print($world['serverop']); ?>" class="login" />
						<input type="hidden" name="orig_serverop" value="<?php print($world['serverop']); ?>" />
					</td>
					<td class="Label">admin_id:</td>
					<td class="Detail"><?php print(($world['admin_id']) ? $world['admin_id'] : 'Not Set.'); ?></td>
				</tr>
				<tr>
					<td class="Label">Server Type:</td>
					<td class="Detail" title="your world type">
						<select name="server|server_type">
							<option value="0"<?php if ($world['server_type'] == 0 || strlen($world['server_type']) == 0) print(" selected"); ?>>PvE</option>
							<option value="1" <?php if ($world['server_type'] == 1) print(" selected"); ?>>PvP</option>
							<option value="2" <?php if ($world['server_type'] == 2) print(" selected"); ?>>RP</option>
							<option value="3" <?php if ($world['server_type'] == 3) print(" selected"); ?>>PvE/RP</option>
							<option value="4" <?php if ($world['server_type'] == 4) print(" selected"); ?>>PvP/RP</option>
							<option value="5" <?php if ($world['server_type'] == 5) print(" selected"); ?>>PvP/Teams</option>
							<option value="6" <?php if ($world['server_type'] == 6) print(" selected"); ?>>Private</option>
							<option value="7" <?php if ($world['server_type'] == 7) print(" selected"); ?>>Development</option>
							<option value="8" <?php if ($world['server_type'] == 8) print(" selected"); ?>>Other</option>
							<option value="9" <?php if ($world['server_type'] == 9) print(" selected"); ?>>iPvP</option>
						</select>
						<input type="hidden" name="orig_server_type" value="<?php print($world['server_type']); ?>" />
					</td>
					<td class="Label">World Owner:</td>
					<td class="Detail"><?php print($world['server_admin']); ?></td>
				</tr>
				<tr valign="top">
					<td class="Label">GM List:<br />(comma separated)</td>
					<td class="Detail" title="your world gamemasters">
						<textarea name="server|gm_list" style="height:80px; width:250px;"><?php print($world['gm_list']); ?></textarea>
						<input type="hidden" name="orig_gm_list" value="<?php print($world['gm_list']); ?>" />
					</td>
					<td class="Label">ip_address:</td>
					<td class="Detail"><?php print(($world['ip_address']) ? $world['ip_address'] : 'Not Set.'); ?></td>
				</tr>
				<tr>
					<td class="Label" valign="top">World Description:</td>
					<td colspan="3" class="Detail" title="your world account name">
						<textarea name="server|description" style="height:100px; width:590px; background-color:#efefef;"><?php print($world['description']); ?></textarea>
						<input type="hidden" name="orig_description" value="<?php print($world['description']); ?>" />
					</td>
				</tr>
				<?php 
				if( $_SESSION['modules']['config']['allow_server_url'] == 1 ) { 
				?>
				<tr>
					<td class="Label">Server Website:</td>
					<td class="Detail" title="url to your personal website for your server">
						<input type="text" name="server|server_url" value="<?php print($world['server_url']); ?>" class="login" />
						<input type="hidden" name="orig_server_url" value="<?php print($world['server_url']); ?>" />
					</td>
					<td>&nbsp;( http://your.domain.com )</td>
				</tr>
				<?php 
				} 
				
				if( $_SESSION['modules']['config']['allow_hide_status'] == 1 ) { 
				?>
				<tr>
					<td class="Label">Hide Status:</td>
					<td class="Detail" title="do not display your world on the public server status page">&nbsp;
						<input type="radio" name="server|hide_status" value="1"<?php if ($world['hide_status']) print(" checked") ?> />&nbsp;Yes
						<input type="radio" name="server|hide_status" value="0"<?php if (!$world['hide_status']) print(" checked") ?> />&nbsp;No
						<input type="hidden" name="orig_hide_status" value="<?php print($world['hide_status']); ?>" />
					</td>
					<td colspan="2">&nbsp;( do not display server )</td>
				</tr>
				<?php 
				} 
				
				if( $_SESSION['modules']['config']['allow_hide_details'] == 1 ) { 
				?>
				<tr>
					<td class="Label">Hide Details:</td>
					<td class="Detail" title="display your world, but do not link to your server home page">&nbsp;
						<input type="radio" name="server|hide_details" value="1"<?php if ($world['hide_details']) print(" checked") ?> />&nbsp;Yes
						<input type="radio" name="server|hide_details" value="0"<?php if (!$world['hide_details']) print(" checked") ?> />&nbsp;No
						<input type="hidden" name="orig_hide_details" value="<?php print($world['hide_details']); ?>" />
					</td>
					<td colspan="2">&nbsp;( hide server url )</td>
				</tr>
				<?php 
				} 
				
				if( $_SESSION['modules']['config']['allow_hide_admin'] == 1 ) { 
				?>
				<tr>
					<td class="Label">Hide Admin:</td>
					<td class="Detail" title="display your world, but do not show who owns it">&nbsp;
						<input type="radio" name="server|hide_admin" value="1"<?php if ($world['hide_admin']) print(" checked") ?> />&nbsp;Yes
						<input type="radio" name="server|hide_admin" value="0"<?php if (!$world['hide_admin']) print(" checked") ?> />&nbsp;No
						<input type="hidden" name="orig_hide_admin" value="<?php print($world['hide_admin']); ?>" />
					</td>
					<td colspan="2">&nbsp;( hide server admin )</td>
				</tr>
				<?php 
				} 
				?>
				<tr>
					<td class="Label">Characters:</td>
					<td class="Detail">
					<?php 
						$char_counts = $this->GetCharacterCounts($world['id']);
						printf("%s active, %s deleted, %s total", $char_counts['active'], $char_counts['deleted'], $char_counts['total']); 
					?>
					</td>
					<td colspan="2">&nbsp;( player counts )</td>
				</tr>
				<tr>
					<td title="creates the server account" colspan="4" align="center">
						<input type="submit" name="cmd" value="Update Server" />
						<?php if( $_SESSION['modules']['config']['allow_server_delete'] == 1 ) { ?>
						<input type="submit" name="cmd" value="Delete Server" />
						<? } ?>
					</td>
				</tr>
			</table>
			<input type="hidden" name="server_id" value="<?= $world['id'] ?>" />
			<input type="hidden" name="server_name" value="<?= $world['name'] ?>" />
			</form>
			<?php
				$i++;
			} //end foreach
		} // end if
		?>
		<form method="post" name="create-world">
		<table align="center" border="0" width="100%">
			<col width="25%" />
			<col width="25%" />
			<col width="25%" />
			<col width="25%" />
			<tr height="30" valign="bottom">
				<td>
					<?= $i ?> of <?= $_SESSION['modules']['config']['max_servers_per_ip'] ?> Server Accounts in use.
				</td>
				<td colspan="2" align="center">
					<?php 
					if( $i < $_SESSION['modules']['config']['max_servers_per_ip'] )
						printf('<input type="submit" name="cmd" value="Create Server" %s />', $this->DisableLogin);
					else
						print('<span style="color:#aaa">Cannot create a new Server: Already at max servers</span>');
					?>
				</td>
				<td>&nbsp;</td>
			</tr>
		</table>
		<input type="hidden" name="action" value="add_server" />
		</form>
		<?php
	}
		
		
	private function ShowLogin() {
	?>
		<div class="post bg1">
			<div class="inner">
				<div class="postbody">
					<div class="content">
					<p>In order to play on an EQ2Emulator Public Server, you must create a <i>Login Account</i>. 
					This is the user name and password you will use to connect to our Login Server for creating characters or playing on one of the public EQ2Emulator Servers.<br>
					<br>
					You also need a Login Account if you plan to register and run your own EQ2Emulator Public Server (attached to our Login Server).<br>
					<br>
					Login below if you already have a Login Account, or click "Create Account" to set one up.<br />
					</p>
					</div>
				</div>
			</div>
		</div>
		&nbsp;
		<div id="section">
			<ul>
				<li class="section-title">Public LoginServer is: <?= $this->LoginStatus ? '<span style="color:#00FF00;"><strong>UP</strong></span>' : '<span style="color:#FF0000;"><strong>DOWN</strong></span>' ?></li>
			</ul>
		</div>
		<div class="post bg1">
			<div class="inner">
				<div class="postbody">
					<div class="content">
					<p style="text-align:center; color:#F00; font-weight:bold;">
					<?php
					// Error handler
					if( strlen($MOD->Status) > 0 )
						print($MOD->Status);
					?>
					</p>
					<form method="post" name="account-login">
					<p align="center">
					Login Account Name<br />
					<input type="text" name="login_account_name" value="<?php print($_POST['login_account_name']); ?>" class="login" title="your login account name" /><br />
					Login Account Password<br />
					<input type="password" name="login_account_password" class="login" />
					</p>
					<p align="center">
					<input type="submit" name="cmd" value="Login" <?php print($this->DisableLogin) ?> />
					</p>
					</form>
					<p align="center">-OR-</p>
					<form method="post" name="account-create">
					<p align="center">
					<input type="submit" name="cmd" value="Create Account" <?php print($this->DisableLogin) ?> title="create a new login account" />
					<input type="hidden" name="action" value="add_account" />
					</p>
					</form>
					</div>
				</div>
			</div>
		</div>
	<?php 
	}

	
	private function DoLogin() {
		global $MOD;
		
		$login_account_name		= $_POST['login_account_name'];
		$login_account_password	= $_POST['login_account_password'];
		
		if ( strlen($login_account_name) > 3 && strlen($login_account_password) > 3 )
		{
			$this->SQLQuery = sprintf("SELECT COUNT(id) as cnt FROM ".LOGIN_DATABASE.".account WHERE name = '%s' AND passwd = '%s'", $this->SQLEscape($login_account_name), md5($this->SQLEscape($login_account_password)));
			$data = $this->RunQuerySingle();
			
			if( $data['cnt'] > 0 )
			{
				$_SESSION['login-account'] = $login_account_name;
	
				$log_array['log_type'] 		= 'Player';
				$log_array['log_operation'] = 'PLAYER_MANAGER_LOGIN';
				$log_array['log_data']		= sprintf("n:%s;", $_SESSION['login-account']);
				$MOD->Log( $log_array );
				
				$MOD->AddStatus(sprintf("Successfully logged in as %s!", $_SESSION['login-account']));
				return;
			}
			/*else
			{
				session_unset($_SESSION['login-account']);
				$status['Account'] = 'Account does not exist.';
				return;
			}*/
		}
		session_unset($_SESSION['login-account']);
		$MOD->AddStatus('Invalid Login.');
	}
	
	
	private function DoLogout() { 
		global $MOD;
		
		$log_array['log_type'] 		= 'Player';
		$log_array['log_operation'] = 'PLAYER_MANAGER_LOGOUT';
		$log_array['log_data']		= sprintf("n:%s;", $_SESSION['login-account']);
		$MOD->Log( $log_array );
		session_unset($_SESSION['login-account']);
		$MOD->AddStatus("Successfully logged out.");
	}
		
		
	private function ShowCreateAccountDialog() {
		global $user, $MOD;
	
		?>
		<table align="center" border="0" width="100%">
			<tr>
				<td height="50" valign="top">
					To create a Login Account, fill in the form below and click &quot;Create&quot;.&nbsp;<strong>Note:</strong> Email address is required for non-forum members.
				</td>
			</tr>
		</table>
		<div id="section">
			<ul style="margin-left:0;">
				<li class="section-title">Public LoginServer is: <?= $this->LoginStatus ? '<span style="color:#00FF00;"><strong>UP</strong></span>' : '<span style="color:#FF0000;"><strong>DOWN</strong></span>' ?></li>
			</ul>
		</div>
		<table width="100%" align="center" border="0">
			<col width="35%" />
			<col width="30%" />
			<col width="35%" />
			<form method="post" name="reg-account">
			<tr>
				<td align="right">Account Name:</td>
				<td colspan="2" title="the name you will enter into your EQ2 Client to log in"><input type="text" name="login_account_name" value="<?php print($_POST['login_account_name']); ?>" size="32" maxlength="64" /></td>
			</tr>
			<tr>
				<td align="right">Password:</td>
				<td colspan="2" title="the password you will enter into your EQ2 Client to authenticate"><input type="password" name="login_account_password1" size="32" maxlength="64" /></td>
			</tr>
			<tr>
				<td align="right">Verify Password:</td>
				<td colspan="2" title="verify the password is correct"><input type="password" name="login_account_password2" size="32" maxlength="64" /></td>
			</tr>
			<tr>
				<td align="right">Email Address:</td>
				<td colspan="2" title="required for password resets">
				<?
					if( isset($_POST['login_account_email']) )
					{
						// user entered an email address manually
						$user_mail = $_POST['login_account_email'];
					}
					else
					{
						if( !empty($user->data['user_email']) )
						{
							// user is a forum member, so use their email address
							$user_mail = $user->data['user_email'];
							$disabled = " readonly";
						}
					}
				?>
				<input type="text" name="login_account_email" value="<?= $user_mail ?>" size="32" maxlength="50"<?= $this->DisableLogin ?> /></td>
			</tr>
			<tr>
				<td colspan="3">Passwords must be at least 3 characters long.</td>
			</tr>
			<tr>
				<td colspan="3" align="center">
					<input type="submit" name="cmd" value="Create Account" title="creates the public login server account" />&nbsp;
					<? if( empty($_SESSION['login-account']) ) { ?>
						<input type="button" value="Cancel" onclick="javascript:window.open('<?= $MOD->Link ?>', target='_self');" style="font-size:11px; width:120px;" />
					<? } else { ?>
					<input type="button" value="Back" onclick="javascript:window.open('<?= $MOD->Link ?>', target='_self');" style="font-size:11px; width:120px;" />
					<? } ?>
				</td>
			</tr>
			</form>
		</table>
	<?php
	}
	
	
	private function ShowDeleteAccountCheck() {
		global $MOD;
		
		// before doing anything, verify current password is correct.
		if( !$this->ValidateAccount($_POST['account_name'], md5($_POST['login_current_password'])) ) {
			$MOD->AddStatus('You must supply the current password to DELETE this account!');
			return;
		}
		
	?>
			<table align="center" border="0" width="100%">
			<tr>
				<td height="30" align="center" class="ps_category" style="text-align:center; font-size:15px; font-weight:bold;">Delete Account: <?php print($_POST['login_account_name']); ?></td>
			</tr>
			<tr>
				<td height="30" style="text-align:center; color:#0000FF; font-size:13px; font-weight:bold;">!!! ALL SERVERS AND CHARACTERS ASSOCIATED WITH THIS ACCOUNT WILL BE ORPHANED !!!</td>
			</tr>
			<tr>
				<td height="30" align="center">Are you sure?</td>
			</tr>
			<tr>
				<td height="30" align="center">
					<form method="post" name="account-delete">
					<input type="submit" name="submit" value="Yes" />&nbsp;
					<input type="button" value="No" onclick="dosub('<?= $MOD->Link ?>', target='_self');" />
					<input type="hidden" name="cmd" value="Delete Account" />
					<input type="hidden" name="account_id" value="<?php print($_POST['account_id']); ?>" />
					<input type="hidden" name="account_name" value="<?php print($_POST['account_name']); ?>" />
					<input type="hidden" name="delete_ok" value="1" />
					</form>
				</td>
			</tr>
		</table>
	<?php 
	}
	
	
	private function DoCreateAccount() {
		global $MOD, $user;
		
		// Check that every POST value has data, or cancel entire update
		foreach($_POST as $key => $val) {
			if( (empty($val) || strlen($val) < 3) ) {
				$MOD->AddStatus('Some fields were left blank or were too short.<br />Minimum 3 characters for all values.');
				return; // find one that fails, abort
			}
		}
	
		if( !preg_match('/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b/i', $_POST['login_account_email']) ) {
			$MOD->AddStatus('Invalid Email Address.');
			return;
		}
		
		// If all values have data, continue...
		$login_account_name			= $this->SQLEscape($_POST['login_account_name']);
		$login_account_password1	= $this->SQLEscape($_POST['login_account_password1']);
		$login_account_password2	= $this->SQLEscape($_POST['login_account_password2']);
		$login_account_email		= $this->SQLEscape($_POST['login_account_email']);
		$login_account_ip			= $this->SQLEscape($_SERVER['REMOTE_ADDR']);
		$login_key1					= ( $user->data['user_id'] > 1 ) ? $this->SQLEscape($this->GetCrypt($user->data['user_id'])) : 0;
		
		// Max World Accounts per IP validation
		if ($this->CheckLoginAccounts( $login_account_ip ) < $_SESSION['modules']['config']['max_accounts_per_ip']) {
			// Login Account validation
			if (!$this->CheckLoginAccountName( $login_account_name )) {
				// Password Validation
				if ($login_account_password1 == $login_account_password2) {
					// Everything is good, stuff that sucker in there!
					$query = sprintf("INSERT INTO ".LOGIN_DATABASE.".account (name, passwd, ip_address, email_address, created_date, key1) VALUES ('%s', '%s', '%s', '%s', '%s', '%s');",
						$login_account_name, md5($login_account_password1), $login_account_ip, $login_account_email, time(), $login_key1);
					
					if( $this->RunQuery($query) == 0 ) { // if no rows affected?
						$MOD->AddStatus('Could not execute query:<br />'.$query);
					} else {
						$MOD->AddStatus("Successfully created account: ".$login_account_name);
						
						$log_array['log_type'] 		= 'Player';
						$log_array['log_operation'] = 'ADD_PLAYER_REGISTRATION';
						$log_array['log_data']		= sprintf("n:%s;q:%s", $login_account_name, $this->SQLEscape($query));
						$MOD->Log( $log_array );
						
						if( empty($_SESSION['login-account']) ) {
							$_SESSION['login-account'] = $login_account_name;
						}
					}
				} else
					$MOD->AddStatus('Passwords do not match.');
			} else
				$MOD->AddStatus('Login Name already in use.');
		}
		else
			$MOD->AddStatus('You already have the maximum number of player accounts allowed ('.$_SESSION['modules']['config']['max_accounts_per_ip'].').');
	}
	
	
	private function DoUpdateAccount() {
		global $MOD, $user;
	
		// before doing anything, verify current password is correct.
		if( !$this->ValidateAccount($_POST['account_name'], md5($_POST['login_current_password'])) )
		{
			$MOD->AddStatus('You must supply the current password to update this account!');
			return;
		}
		else
			$pwdOK = 1;
			
		$account_id 	= $_POST['account_id'];
		$account_name	= $_POST['account_name'];
		$account_email	= $this->SQLEscape($_POST['login_account_email']);
		$account_pass1	= $this->SQLEscape($_POST['login_account_password1']);
		$account_pass2	= $this->SQLEscape($_POST['login_account_password2']);
		
		// look it up!
		/*$not_anon = ( $user->data['user_id'] > 1 ) ? sprintf(" AND key1 = '%s'", GetCrypt($user->data['user_id'])) : " AND key1 = 0";
		$query = sprintf("SELECT COUNT(*) as num_rows FROM ".LOGIN_DATABASE.".ls_accounts WHERE account_id = %s AND account_pass = '%s' %s;", $account_id, $check_pass, $not_anon);
		//printf("<p>Validate: %s</p>", $query);
	
		if(!$result=$db2->sql_query($query))
		{
			$error = $db2->sql_error();
			$status['SQL'] = $error['message'] . "<br />" . $query;
		}
		else
		{
			$data = $db2->sql_fetchrow($result); 
			if( $data['num_rows'] === 0 )
			{
				$status['Password'] = 'Could not validate account for deletion. Contact a forum administrator for assistance.';
				$pwdOK = 0;
			}
			else
			{
				$pwdOK = 1;
			}
		}*/
	
		if (isset($_POST['delete_account']) && $pwdOK )
		{
			$showDeleteCheck	= true;
			if( $_POST['submit']=='Yes' )
			{
				$showDeleteCheck	= false;
			}
		}
		else if( $pwdOK )
		{
			// check New Email address
			if( strcmp($_POST['orig_login_account_email'], $account_email) <> 0 )
			{
				$sets[] = sprintf("(email_address = '%s')", $account_email);
			}
	
			// check New Password(s) are set
			if( !empty($account_pass1) )
			{
				if( strlen($account_pass1) > 3 )
				{
					if( $account_pass1 != $account_pass2 )
						$MOD->AddStatus('Passwords do not match.');
				}
				else
				{
					$MOD->AddStatus('Password must be at least 4 characters long.');
				}
				
				$sets[] = sprintf("(passwd = '%s')", md5($account_pass1));
				$newPwd = true;
				
			}
			else if( empty($sets) )
			{
				$MOD->AddStatus('Cannot update nothing. What are you trying to update?');
			}		
			
			if( empty($status) && $pwdOK )
			{
				foreach($sets as $set)
				{
					if( strlen($updates) == 0 )
						$updates = sprintf("%s", preg_replace("/\((.*?)\)/","$1", $set));
					else
						$updates .= sprintf(", %s", preg_replace("/\((.*?)\)/","$1", $set));
	
				}
				
				// if there is data to update:
				if( strlen($updates) > 0 ) {
					$query = sprintf("UPDATE ".LOGIN_DATABASE.".account SET %s WHERE id = %s;", $updates, $account_id);
					if( $this->RunQuery($query) == 0 ) { // if no rows affected?
						$MOD->AddStatus('Could not execute query:<br />'.$query);
					} else {
						$log_array['log_type'] 		= 'Player';
						$log_array['log_operation'] = 'PLAYER_MANAGER_CHANGE_ACCOUNT';
						$log_array['log_data']		= sprintf("i:%s;u:%s;q:%s;", $account_id, $_SESSION['login-account'], $this->SQLEscape($query));
						$MOD->Log( $log_array );
		
						if( $account_name == $_SESSION['login-account'] && $newPwd )
						{
							$MOD->AddStatus(sprintf('Account successfully changed. You must <a href="index.php?page=%d"><u>log back in</u></a>!', $_GET['page']));
							session_unset($_SESSION['login-account']);
						}
						else
							$MOD->AddStatus(sprintf('Account successfully changed for account: %s.', $account_name));
					}
				}
			}
		}
	}
	
	
	private function DoDeleteAccount() { 
		global $MOD;
		
		$query = sprintf("DELETE FROM ".LOGIN_DATABASE.".account WHERE id = %s", $_POST['account_id']);
		$this->RunQuery($query);

		$log_array['log_type'] 		= 'Player';
		$log_array['log_operation'] = 'PLAYER_MANAGER_DELETE_ACCOUNT';
		$log_array['log_data']		= sprintf("i:%s;u:%s;q:%s;", $_POST['account_id'], $_SESSION['login-account'], $this->SQLEscape($query));
		$MOD->Log( $log_array );
	
		$MOD->AddStatus(sprintf("%s (%s) deleted!", $_POST['account_name'], $_POST['account_id']));
	}
		
		
	private function ShowCreateServerDialog() {
		global $MOD, $user;
		
		// Need to load these here, since updates occur above this call
		$this->GetAccounts();	// set $this->Accounts
		$ok = true;
	?>
		<table align="center" border="0" width="100%">
			<tr>
				<td height="50" valign="top">
					In order to log into your personal EQ2Emulator server, it must be registered with the Public Login Server. This allows your server to connect to the LoginServer so other players can connect, receive critical database updates, and shows your server in online stats.<br />
					<br />
					For more information, see the <a href="http://eq2emulator.net/wiki/index.php/Admins" target="_blank">Server Admin Guide</a>.<br />
				</td>
			</tr>
		</table>
		<div id="section">
			<ul style="margin-left:0;">
				<li class="section-title">Public LoginServer is: <?= $this->LoginStatus ? '<span style="color:#00FF00;"><strong>UP</strong></span>' : '<span style="color:#FF0000;"><strong>DOWN</strong></span>' ?></li>
			</ul>
		</div>
		<form method="post" name="reg-server">
		<table width="100%" border="0" cellspacing="0">
			<tr>
				<td>
					Use the form below to register your new server. Before you proceed, you will need the following information:<br />
					<ul style="list-style:inside disc; padding:5px;">
						<li><strong>Your account information from the Player Registration process</strong> (name and password)</li>
						<li>A unique name for your server, with a brief description (description recommended, but optional)</li>
						<li>A unique <em>World Server Account name and password</em> different than your Player Registration information!</li>
					</ul>
					Once you enter your valid Server Account information, click &quot;Create Server&quot; to add your server.
				</td>
			</tr>
			<tr>
				<td align="center">
					<table width="70%" style="font-size:0.8em;">
						<col width="250" />
						<col />
						<tr>
							<td colspan="2">
								<div id="section">
									<ul style="margin-left:0;">
										<li class="section-title">Login Account Information</li>
									</ul>
								</div>
							</td>
						</tr>
						<tr>
							<td class="Label"><strong>Login (Player) Account Name:</strong></td>
							<td class="Detail">
							<?php
							if( is_array($this->Accounts) ) {
								
								print('<select name="login_account_name" title="verify login account to use with your server account">');
								print('<option value="0">Pick Login Account</option>');
								
								foreach($this->Accounts as $login)
									printf('<option value="%s|%s">%s</option>', $login['id'], $login['name'], $login['name']);
									
								print('</select>');
							} else {
								print("<b>No Login account found. Create one first!</b>");
								$ok = false;
							}
							?>
							</td>
						</tr>
						<?php if( $ok ) { ?>
						<tr>
							<td class="Label"><strong>Login (Player) Account Password:</strong></td>
							<td class="Detail"><input type="password" name="login_account_password" size="32" maxlength="64" title="login account password you will use to log your EQ2 client into the loginserver" /> *</td>
						</tr>
						<?php } ?>
					</table>
				</td>
			</tr>
			<?php if( $ok ) { ?>
			<tr>
				<td align="center">
					<table width="70%" style="font-size:0.8em;">
						<col width="250" />
						<col />
						<tr>
							<td colspan="2">
								<div id="section">
									<ul style="margin-left:0;">
										<li class="section-title">World Server Information</li>
									</ul>
								</div>
							</td>
						</tr>
						<tr>
							<td class="Label">World Account Name:</td>
							<td class="Detail"><input type="text" name="world_account_name" value="<?php print($_POST['world_account_name']); ?>" size="32" maxlength="30" title="world account name which goes in your LoginServer.ini 'account' value" /> *</td>
						</tr>
						<tr>
							<td class="Label">World Account Password:</td>
							<td class="Detail"><input type="password" name="world_account_password1" size="32" maxlength="32" title="world account password which goes in your LoginServer.ini 'password' value" /> *</td>
						</tr>
						<tr>
							<td class="Label">Verify Password:</td>
							<td class="Detail"><input type="password" name="world_account_password2" size="32" maxlength="32" title="verify the world account password is correct" /> *</td>
						</tr>
						<tr>
							<td class="Label">&nbsp;</td>
							<td class="Detail">&nbsp;</td>
						</tr>
						<tr>
							<td class="Label">World Server Name:</td>
							<td class="Detail"><input type="text" name="world_name" value="<?php print($_POST['world_name']); ?>" size="32" maxlength="64" title="this is the name your world will show up on the login server list" /> *</td>
						</tr>
						<tr>
							<td class="Label">World Description:</td>
							<td class="Detail"><textarea name="world_description" title="brief description of your server" style="height:50px; width:97%; background-color:#eee; font-family:'Courier New', Courier, monospace; font-size:0.9em;"><?php print($_POST['world_description']); ?></textarea></td>
						</tr>
						<tr>
							<td title="creates the public login server account" colspan="2" align="center"><br>
								<input type="submit" name="cmd" value="Create Server"<?= !$this->LoginStatus ? ' disabled' : '' ?> />
								<input type="submit" value="Back" onclick="dosub('<?php print( $MOD->Link ) ?>')" />
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
		</form>
	<?php	
		}
	}
	
	
	private function ShowDeleteServerCheck() {
		global $MOD;
		
		?>
		<table width="100%" border="0" align="center">
			<tr>
				<td height="30" align="center" class="ps_category" style="text-align:center; font-size:15px; font-weight:bold;">Delete Server: <?php print($_POST['server_name']); ?></td>
			</tr>
			<tr>
				<td height="30" style="text-align:center; color:#0000FF; font-size:13px; font-weight:bold;">!!! ALL CHARACTERS ASSOCIATED WITH THIS SERVER WILL BE ORPHANED !!!</td>
			</tr>
			<tr>
				<td height="30" style="text-align:center; font-size:15px; font-weight:bold; color:#f00;">Are you sure?</td>
			</tr>
			<tr>
				<td height="30" align="center">
					<form method="post" name="server-delete">
					<input type="submit" name="submit" value="Yes" style="font-size:11px; width:90px;" />&nbsp;
					<input type="button" value="No" style="font-size:11px; width:90px;" onclick="dosub('<?= $MOD->Link ?>', target='_self');" />
					<input type="hidden" name="cmd" value="Delete Server" />
					<input type="hidden" name="server_id" value="<?php print($_POST['server_id']); ?>" />
					<input type="hidden" name="server_name" value="<?php print($_POST['server_name']); ?>" />
					<input type="hidden" name="delete_ok" value="1" />
					</form>
				</td>
			</tr>
		</table>
		<?php 
	}
	
	
	private function DoCreateServer() {
		global $MOD;
		
		$status = array();
	
		// Check that every POST value has data, or cancel entire update
		foreach($_POST as $key => $val) {
			if((empty($val) || strlen($val) < 3) && $key != 'world_description') {
				$MOD->AddStatus('Some fields were left blank or were too short.<br />Minimum 3 characters for all values.');
				return;
			}
		}
		
		// Stop processing if any required fields are blank
		if (empty($MOD->Status)) {
			if( isset($_POST['login_account_name']) ) {
				$tmp = explode("|", $_POST['login_account_name']);
			}
			
			$login_account_id			= $tmp[0];
			$login_account_name			= $this->SQLEscape($tmp[1]);
			$login_account_password		= $this->SQLEscape($_POST['login_account_password']);
			$world_account_name			= $this->SQLEscape($_POST['world_account_name']);
			$world_account_password1	= $this->SQLEscape($_POST['world_account_password1']);
			$world_account_password2	= $this->SQLEscape($_POST['world_account_password2']);
			$world_name					= $this->SQLEscape($_POST['world_name']);
			$world_description			= $this->SQLEscape($_POST['world_description']);
			$world_ip 					= $this->SQLEscape($_SERVER['REMOTE_ADDR']);
		
			// Login Account validation
			if( $this->ValidateAccount($login_account_name, md5($login_account_password)) ) {
				// Max World Accounts per IP validation
				if( $this->CountServersByIPAddress( $world_ip ) < $_SESSION['modules']['config']['max_servers_per_ip'] ) {
					// World Account validation
					if( !$this->CheckServerAccount( $world_account_name ) ) {
						// World Account Password validation
						if( $world_account_password1 == $world_account_password2 ) {
							// World Name validation
							if( !$this->CheckServerName( $world_name ) ) {
								// Ok, I think we're finally ready to insert a new world registration!
								$query = sprintf("INSERT INTO ".LOGIN_DATABASE.".login_worldservers " . 
												 "(`admin_id`, `account`, `password`, `name`, `description`, `serverop`, `ip_address`, `created_date`) " .
												 "VALUES ('%s','%s','%s','%s','%s','%s','%s','%s')",
												 $login_account_id, $world_account_name, md5($world_account_password1), $world_name, $world_description, $login_account_name, $world_ip, time());
								$this->RunQuery($query);
								
								$log_array['log_type'] 		= 'Server';
								$log_array['log_operation'] = 'ADD_SERVER_REGISTRATION';
								$log_array['log_data']		= sprintf("n:%s;w:%s;q:%s", $login_account_name, $world_name, $this->SQLEscape($query));
								$MOD->Log( $log_array );
								
								// Success!
								$MOD->AddStatus('Successfully created world account: '.$world_name.'!');
							} else {
								// World Name already exists
								$MOD->AddStatus('World Name already exists. Choose another.');
							}
						} else {
							// World Password mismatch
							$MOD->AddStatus('World Account passwords do not match.');
						}
					} else {
						// World Account already exists
						$MOD->AddStatus('World Account already exists. Choose another.');
					}
				} else {
					// Too many worlds for this IP address
					$MOD->AddStatus('You already have the maximum number of worlds allowed for your IP Address ('.$_SESSION['modules']['config']['max_servers_per_ip'].').');
				}
			} else {
				// Login Account name not found or password mismatch
				$MOD->AddStatus('Could not verify Login Account information.');
			}
		}
	}
	
	
	private function DoUpdateServer() { 
		global $MOD;
		
		$server_id = $_POST['server_id'];
	
		// check password change
		if( !empty($_POST['server|password']) ) {
			if( strlen($_POST['server|password']) > 3 ) {
				if( $_POST['server|password'] != $_POST['password2'] )
					$MOD->AddStatus('Passwords do not match.');
				else
					$pwdChange = true;
			} else {
				$MOD->AddStatus('Password must be at least 4 characters long.');
			}
		}			
	
		if( empty($this->Status) ) {
			foreach( $_POST as $key=>$val ) {
				$chkKey = explode("|",$key);
				if( $chkKey[0] == "server" ) {
					if( $_POST['orig_'.$chkKey[1]] != $val ) {
						if( $chkKey[1] == "password" ) {
							$val = md5($val);
						}
						$sets .= ( empty($sets) ) ? sprintf("%s = '%s'", $chkKey[1], $this->SQLEscape($val)) : sprintf(", %s = '%s'", $chkKey[1], $this->SQLEscape($val));
					}
				}
			}
	
			if( !empty($sets) ) {
				$query = sprintf("UPDATE ".LOGIN_DATABASE.".login_worldservers SET %s WHERE id = %s", $sets, $server_id);
				$this->RunQuery($query);

				$log_array['log_type'] 		= 'Server';
				$log_array['log_operation'] = 'SERVER_MANAGER_UPDATED_SERVER';
				$log_array['log_data']		= sprintf("i:%s;s:%s,n:%s;u:%s;q:%s", $_POST['id'], $this->SQLEscape($_POST['server|name']), $this->SQLEscape($_POST['server|account']), $_SESSION['login-account'], $this->SQLEscape($query));
				$MOD->Log( $log_array );

				$MOD->AddStatus('Update(s) Saved!');
			} else {
				$MOD->AddStatus('No changes made!');
			}
		}
	}
	
	
	private function DoDeleteServer() { 
		global $MOD;
		
		$query = sprintf("DELETE FROM ".LOGIN_DATABASE.".login_worldservers where id = %s", $_POST['server_id']);
		$this->RunQuery($query);

		$log_array['log_type'] 		= 'Player';
		$log_array['log_operation'] = 'PLAYER_MANAGER_DELETE_ACCOUNT';
		$log_array['log_data']		= sprintf("i:%s;u:%s;q:%s;", $_POST['server_id'], $this->SQLEscape($_SESSION['server_name']), $this->SQLEscape($query));
		$MOD->Log( $log_array );
	
		$MOD->AddStatus(sprintf("%s (%s) deleted!", $_POST['server_name'], $_POST['server_id']));
	}
	
	
	private function ShowDeleteCharacterCheck() {
		global $MOD;
		
		?>
		<table width="100%" border="0" align="center">
			<tr>
				<td height="30" align="center" class="ps_category" style="text-align:center; font-size:15px; font-weight:bold;">
					Deleting Character: <?php print($_POST['login_character_name']); ?> from server: <?php print($_POST['server_name']); ?>
				</td>
			</tr>
			<?php if( intval($_POST['is_orphaned']) == 1 ) { ?>
			<tr>
				<td height="30" style="text-align:center; color:#f00; font-size:15px; font-weight:bold;">
					!!! THIS CHARACTER IS ORPHANED ON LOGINSERVER !!!
				</td>
			</tr>
			<tr>
				<td height="60" style="vertical-align:bottom; text-align:center; color:#00f; font-size:13px; font-weight:bold;">
					Delete this orphaned character?
				</td>
			</tr>
			<?php } else { ?>
			<tr>
				<td height="30" style="text-align:center; color:#f00; font-size:15px; font-weight:bold;">
					!!! THIS CHARACTER IS <span style="font-size:1.2em; text-decoration:underline;">ACTIVE</span> ON LOGINSERVER !!!
				</td>
			</tr>
			<tr>
				<td height="60" style="vertical-align:bottom; text-align:center; color:#00f; font-size:15px; font-weight:bold;">
					Delete this <span style="color:#f00; font-size:1.2em; text-decoration:underline;">ACTIVE</span> character?
				</td>
			</tr>
			<?php } ?>
			<tr>
				<td height="30" align="center">
					<form method="post" name="delete_character">
					<input type="submit" name="submit" value="Yes" style="width:90px;" />&nbsp;
					<input type="button" value="No" style="width:90px;" onclick="dosub('<?= $MOD->Link ?>', target='_self');" tabindex="0" />
					<input type="hidden" name="cmd" value="Delete" />
					<input type="hidden" name="login_character_id" value="<?php print($_POST['login_character_id']); ?>" />
					<input type="hidden" name="login_character_name" value="<?php print($_POST['login_character_name']); ?>" />
					<input type="hidden" name="server_name" value="<?php print($_POST['server_name']); ?>" />
					<input type="hidden" name="delete_ok" value="1" />
					</form>
				</td>
			</tr>
		</table>
		<?php 
	}
	
	
	private function DoDeleteCharacter() { 
		global $MOD;
		
		$query = sprintf("DELETE FROM login_characters WHERE id = %s", $_POST['login_character_id']);
		$this->RunQuery($query);
		
		$log_array['log_type'] 		= 'Player';
		$log_array['log_operation'] = 'PLAYER_MANAGER_DELETE_CHARACTER';
		$log_array['log_data']		= sprintf("i:%s;n:%s;u:%s;q:%s;", $_POST['login_character_id'], $this->SQLEscape($_POST['login_character_name']), $_SESSION['login-account'], $this->SQLEscape($query));
		$MOD->Log( $log_array );
	}
	
	

	/**
	 * Override SQL functions from Common
	 * REALLY dislike doing it this way, but I need separate creds/servers for gameservers?
	 */
	/****************************************************************************
	 * SQL Database Functions
	 ****************************************************************************/
	private function GetBacktrace()
	{
		$output = '<div style="font-family: monospace; font-size:15px;">';
		$backtrace = debug_backtrace();
		
		// We skip the first one, because it only shows this file/function
		unset($backtrace[0]);
		
		foreach ($backtrace as $trace)
		{
			// Strip the current directory from path
			$trace['file'] = (empty($trace['file'])) ? '(not given by php)' : htmlspecialchars($trace['file']);
			$trace['line'] = (empty($trace['line'])) ? '(not given by php)' : $trace['line'];
		
			// Only show function arguments for include etc.
			// Other parameters may contain sensible information
			$argument = '';
			if (!empty($trace['args'][0]) && in_array($trace['function'], array('include', 'require', 'include_once', 'require_once')))
			{
				$argument = htmlspecialchars($trace['args'][0]);
			}
		
			$trace['class'] = (!isset($trace['class'])) ? '' : $trace['class'];
			$trace['type'] = (!isset($trace['type'])) ? '' : $trace['type'];
		
			$output .= '<br />';
			$output .= '<b>FILE:</b> ' . $trace['file'] . '<br />';
			$output .= '<b>LINE:</b> ' . ((!empty($trace['line'])) ? $trace['line'] : '') . '<br />';
		
			$output .= '<b>CALL:</b> ' . htmlspecialchars($trace['class'] . $trace['type'] . $trace['function']);
			$output .= '(' . (($argument !== '') ? "'$argument'" : '') . ')<br />';
		}
		$output .= '</div>';
		return $output;
	}


	public function DBError() {
		global $MOD;
		
		$error = $this->db->sql_error();
		?>
		<div id="error-box">
		<table cellspacing="0" align="center">
			<tr>
				<td colspan="2" class="title">SQL Error: <?php print($error['code']); ?></td>
			</tr>
			<tr>
				<td class="label">Message:</td>
				<td class="detail"><?php print($error['message']); ?></td>
			</tr>
			<tr>
				<td class="label">Trace:</td>
				<td class="detail">
					<?php 
					print($this->GetBacktrace());
					?>
				</td>
			</tr>
			<tr>
				<td class="label">Query:</td>
				<td><?php print($this->SQLQuery); ?></td>
			</tr>
		</table>
		</div>
		<?php 
		if( $_SESSION['modules']['config']['debug'] == 1 && $_SESSION['modules']['user']['id'] == 2 ) 
			$MOD->DisplayDebug();
		include(PORTAL_ROOT_PATH."common/inc_footer.php");
		die();
	}

	/* SELECT: Use this RunQuery to return a single-row result set */
	public function RunQuerySingle($sql = '') {
		global $MOD;
		
		/*** Override $this with passed parameters ***/
		if( is_null($this->SQLQuery) && strlen($sql) > 6 )
			$this->SQLQuery = $sql;
		/**********************************************/
			
		// add ; to end of query, if missing, just for logging to screen
		if( strpos($this->SQLQuery, ";") == 0 )
			$this->SQLQuery = trim($this->SQLQuery) . ";";
			
		if( $_SESSION['modules']['config']['debug'] ) {
			$start_time = time();
			$MOD->AddDebugFunction(__FUNCTION__, "Enter");
			$MOD->AddDebugQuery(__FUNCTION__, $this->SQLQuery);
		}
		
		if( !$result = $this->db->sql_query($this->SQLQuery) ) {
			$this->DBError();
		} else {
			$num_rows = $this->db->sql_affectedrows($result);
			$rtn = $this->db->sql_fetchrow($result);
		}
		
		if( $_SESSION['modules']['config']['debug'] ) {
			$MOD->AddDebugData("RunQuerySingle", $rtn);
			$MOD->AddDebugFunction(__FUNCTION__, $num_rows." row(s)");
			if( $Elapsed > 1 )
				$Exit = sprintf("Exit - Elapsed: %s<br />Slow Query: %s", $Elapsed, $this->SQLQuery);
			else
				$Exit = "Exit";
			$MOD->AddDebugFunction(__FUNCTION__, $Exit);
		}

		unset($this->SQLQuery);  // nuke the query so it isn't used again
		
		return $rtn;
	}
	
	
	/* SELECT: Use this RunQuery to return a multiple-row result set */
	public function RunQueryMulti($sql = '') {
		global $MOD;
		
		/*** Override $this with passed parameters ***/
		if( is_null($this->SQLQuery) && strlen($sql) > 6 )
			$this->SQLQuery = $sql;
		/**********************************************/
			
		// add ; to end of query, if missing, just for logging to screen
		if( strpos($this->SQLQuery, ";") == 0 )
			$this->SQLQuery = trim($this->SQLQuery) . ";";
			
		if( $_SESSION['modules']['config']['debug'] ) {
			$start_time = time();
			$MOD->AddDebugFunction(__FUNCTION__, "Enter");
			$MOD->AddDebugQuery(__FUNCTION__, $this->SQLQuery);
		}
		
		if( !$result = $this->db->sql_query($this->SQLQuery) ) {
			$this->DBError();
		} else {
			$num_rows = $this->db->sql_affectedrows($result);
			while( $data = $this->db->sql_fetchrow($result) ) 
				$rtn[] = $data;
		}
		
		if( $_SESSION['modules']['config']['debug'] ) {
			$MOD->AddDebugData("RunQueryMulti Data", $rtn);
			$MOD->AddDebugFunction(__FUNCTION__, $num_rows." row(s)");
			$Elapsed = time() - $start_time;
			if( $Elapsed > 1 )
				$Exit = sprintf("Exit - Elapsed: %s<br />Slow Query: %s", $Elapsed, $this->SQLQuery);
			else
				$Exit = "Exit";
			$MOD->AddDebugFunction(__FUNCTION__, $Exit);
		}

		unset($this->SQLQuery);  // nuke the query so it isn't used again
		
		return $rtn;
	}
	

	public function RunQuery($sql = '') {
		global $MOD;
		
		$num_rows = 0;
		
		/*** Override $this with passed parameters ***/
		if( is_null($this->SQLQuery) && strlen($sql) > 6 )
			$this->SQLQuery = $sql;
		/**********************************************/

		// Check if SQLQuery has a valid query
		if( strlen($this->SQLQuery) === 0 )
			die("Invalid SQLQuery: '" . $this->SQLQuery . "'");
			
		// this should set the QueryType always
		$this->QueryType = substr($this->SQLQuery, 0, 6);
		
		// add ; to end of query, if missing, just for logging to screen
		if( strpos($this->SQLQuery, ";") == 0 )
			$this->SQLQuery = trim($this->SQLQuery) . ";";
			
		if( $_SESSION['modules']['config']['debug'] ) {
			$start_time = time();
			$MOD->AddDebugFunction(__FUNCTION__, "Enter");
			if( $_SESSION['modules']['config']['readonly'] )
				$MOD->AddDebugQuery(__FUNCTION__, "READ-ONLY: ".$this->SQLQuery);
			else
				$MOD->AddDebugQuery(__FUNCTION__, $this->SQLQuery);
		}
		
		switch($this->QueryType) {
			
			case "SELECT":
				if( !$result=$this->db->sql_query($this->SQLQuery) )
					$this->DBError();
				else {
					// temp: checking to see if I call RunQuery directly for any select statements
					die("Do not call RunQuery for Selects directly. Use RunQuerySingle, RunQueryMulti");
					$data = $this->db->sql_fetchrow($result);
				}
					
				break;
				
			case "INSERT":
			case "UPDATE":
			case "DELETE":
				if( $_SESSION['modules']['config']['readonly'] ) {
					$MOD->AddStatus("READ-ONLY MODE (".$this->QueryType.") - No data updated!", 1);
				} else {
					if( !$result = $this->db->sql_query($this->SQLQuery) )
						$this->DBError();
					else {
						$num_rows = $this->db->sql_affectedrows($result);
						
						$this->AffectedRows = $num_rows;
						$MOD->AddDebugGeneral("Affected Rows", $this->AffectedRows);
						$this->LastInsertID = $this->db->sql_nextid();
						$MOD->AddDebugGeneral("Last Insert ID", $this->LastInsertID);
					}
				}
				break;
		}
		
		if( $_SESSION['modules']['config']['debug'] )
		{
			$MOD->AddDebugData("RunQuery Data", $data);
			$MOD->AddDebugFunction(__FUNCTION__, $num_rows." row(s)");
			if( $Elapsed > 1 ) // i don't think I'm calculating Elapsed?
				$Exit = sprintf("Exit - Elapsed: %s<br />Slow Query: %s", $Elapsed, $this->SQLQuery);
			else
				$Exit = "Exit";
			$MOD->AddDebugFunction(__FUNCTION__, $Exit);
		}
		
		unset($this->QueryType); // nuke the type so it isn't used again
		unset($this->SQLQuery);  // nuke the query so it isn't used again
		
		return $num_rows;
	}

	public function LogQuery() {
		global $MOD;
		
		// Check if SQLQuery has a valid query
		if( strlen($this->SQLQuery) === 0 )
			die("Invalid SQLQuery: '" . $this->SQLQuery . "'");
			
		// add ; to end of query, if missing, just for logging to screen
		if( strpos($this->SQLQuery, ";") == 0 )
			$this->SQLQuery = trim($this->SQLQuery) . ";";
			
		if( $_SESSION['modules']['config']['debug'] ) {
			$MOD->AddDebugFunction(__FUNCTION__, "Enter");
			if( $_SESSION['modules']['config']['readonly'] )
				$MOD->AddDebugQuery(__FUNCTION__, "READ-ONLY: ".$this->SQLQuery);
			else
				$MOD->AddDebugQuery(__FUNCTION__, $this->SQLQuery);
		}
		
		if( $_SESSION['modules']['config']['readonly'] ) {
			$MOD->AddStatus("READ-ONLY MODE (".$this->QueryType.") - No data updated!", 1);
		} else {
			if( !$result = $this->db->sql_query($this->SQLQuery) )
				$this->DBError();
			// no LastInserID or AffectedRows on Log inserts!
		}
		
		if( $_SESSION['modules']['config']['debug'] )
			$MOD->AddDebugFunction(__FUNCTION__, "Exit");
		
		unset($this->QueryType); // nuke the type so it isn't used again
		unset($this->SQLQuery);  // nuke the query so it isn't used again
		
		return $num_rows;
	}

	public function GetTotalRows($database, $table) {
		$this->SQLQuery = sprintf("SELECT count(*) AS num FROM %s.%s;", $database, $table);
		$data = $this->RunQuerySingle();
		return ( !empty($data) ) ? $data['num'] : 0;
	}

	private function SQLLog() {
		global $MOD, $user;
		
		// stuff insert, update, delete queries into EQ2Editor.log table
		if( $_SESSION['modules']['config']['debug'] )
			$MOD->AddDebugFunction(__FUNCTION__, "Enter");
		
		/*
		 * Logging Stuff goes Here
		 */
		if( $_SESSION['modules']['config']['sql_log'] )
		{
			$pattern[0] = "/".DEV_DB."\./i";
			$replace[0] = "";
			
			$log_query = preg_replace($pattern, $replace, $this->SQLQuery);
			
			// can't use RunQuery because we're getting the wrong LastInsertID!
			$log_insert = sprintf("INSERT INTO log (user_id, username, table_name, object_id, update_query, update_date) VALUES ('%s','%s','%s','%s','%s','%s')",
								$data->user['user_id'],
								$this->SQLEscape($data->user['username']),
								$this->SQLEscape($this->TableName),
								$this->SQLEscape($this->ObjectID),
								$this->SQLEscape($log_query),
								time());
			
			if( !$result = $this->db->sql_query($log_insert) )
				$this->DBError();
		}

		/*
		 * File Logging
		 */
		// 2016.10.23 - this needs to be refactored for portal apps
		if( $_SESSION['modules']['config']['sql_log_file'] )
		{
			$logfile = sprintf("logs/session_%s_%s_week%s.txt", 
												 strtolower($_SESSION['modules']['user']['username']), 
												 date("Y", time()), 
												 date("W", time()));

			$log_query .= "\n";
			
			if( $_SESSION['modules']['config']['readonly'] )
				$MOD->AddStatus("READ-ONLY MODE - ".$logfile." not saved!");
			else
			{
				if( file_exists($logfile) ) 
				{
					if( !$f = fopen($logfile, 'a') ) 
						die("Cannot open existing filename: $logfile");
		
					if( !fwrite($f, $log_query) )
						die("Cannot write to existing filename: $logfile");
		
					fclose($f);
				} 
				else 
				{
					if( !$f = fopen($logfile, 'x') ) 
						die("Cannot create new file: $logfile");
						
					if( !fwrite($f, $log_query) )
							die("Cannot write to new filename: $logfile");
							
					fclose($f);
				}
			}
			
		}

		if( $_SESSION['modules']['config']['debug'] )
			$MOD->AddDebugFunction(__FUNCTION__, "Exit");
	}

	public function SQLEscape($str) {
		return $this->db->sql_escape($str);
	}


	public function NoResults() {
		print("No Results in " . __FUNCTION__ . ", " . __LINE__);
	}


	
} // END Class
?>
