<?php
error_reporting(E_ERROR | E_PARSE);
if( !defined("IN_PORTAL") )
	die("Hacking attempt.");

define("MAX_LOGIN_HEARTBEAT", "900");
define("IMG_PATH","/portal/images/icons/");	// all icons in these modules are in this path

/**
 * The MODWidget class is for small bits of code that make up the portal widgets
 * such as Login and World Stats boxes
 *
 * Need to figure out what to do when Gameservers are on a different MySQL Instance than Forums (alternate DB creds below)
 * For now, just hacking it in (booooo)
 *
 */
class MODWidget {
	
	// public properties
	
	// private properties
	private $CallingFunction	= NULL;	// set the name of __FUNCTI)ON__ here for debugging logs
	private $SQLQuery		= NULL;
	private $AffectedRows		= NULL;
	private $LastInsertID		= NULL;
	private $Counts			= array();
	private $max_cache_time		= 900; // # of seconds until cache expires
	private $world_cache_time	= 300; // # of seconds until World data cache expires
	private $ls_online		= 0;
	
	
	//
	// Constructor
	//
	public function __construct() {
		global $MOD;
		
		// alternate DB creds -- not sure I want to do this unless I replicate RunQuery locally?
		$this->db_host = $_SESSION['modules']['database'][1]['db_host'];
		$this->db_user = $_SESSION['modules']['database'][1]['db_user'];
		$this->db_pass = $_SESSION['modules']['database'][1]['db_pass'];
		$this->db_name = $_SESSION['modules']['database'][1]['db_name'];
		$this->db_port = $_SESSION['modules']['database'][1]['db_port'];
		
		//require_once (PORTAL_ROOT_PATH.'classes/MysqliDb.php');
		//$this->db = new MysqliDb ($this->db_host, $this->db_user, $this->db_pass, $this->db_name);

		//printf('%s, %s, %s, %s, %s', $this->db_host, $this->db_user, $this->db_pass, $this->db_name, $this->db_port);
		include_once("mysql.class.php");
		$this->db = new MODMysql($this->db_host, $this->db_user, $this->db_pass, $this->db_name, false);
		if( !$this->db )
			die("SQL Connect failure!");
			
		//var_dump($this->db);
		// set ls_online before loading cache
		//$this->ls_online = $this->CheckLoginServerStatus();
		//$MOD->AddDebugGeneral('LoginServer', ( intval($this->is_online) === 1 ) ? "Online" : "Offline" );
		//$this->CacheData();
		//print_r($_SESSION['modules']['login_data']);
	}
	
	public function _halt() {
		die("<p>Dev Debugging, please stand by...</p>");
	}

	/**
	 * Setters
	 */
	/** 
	 * This function loads the loginserver data and caches it for 'n' seconds (max_cache_time). 
	 * Since the account and server data doesn't change that often, we can trigger reloading the
	 * cache when/if an account/server data changes. Otherwise, prevent continuous reloading on
	 * page refreshes
	 */
	private function CacheData() {
		global $MOD;
		
		$MOD->Trace(__FUNCTION__, 'start');
		
		if( count($_SESSION['modules']['login_data']) == 0 || $_SESSION['modules']['login_data']['cachetime'] <= (time() - $this->max_cache_time) ) {
			unset($_SESSION['modules']['login_data']); // clear previous values
			$_SESSION['modules']['login_data']['cachetime'] = time();
			
			$this->LoadLoginData();
			// send to debug
			$MOD->AddDebugGeneral('Login', sprintf('Login cache refreshed (time: %s)', date('Y-m-d h:i:s', $_SESSION['modules']['login_data']['cachetime'])));
		}
		
		$MOD->AddDebugGeneral('Login', sprintf('Login Max Cached (time: %ss)', $this->max_cache_time));
		$MOD->AddDebugGeneral('Login', sprintf('Login Est cache refresh @ %s', date('Y-m-d h:i:s', $_SESSION['modules']['login_data']['cachetime'] + $this->max_cache_time)));
		
		// Cache world server data
		// Note: hard-coded cache time for World data to 5 minutes
		if( count($_SESSION['modules']['world_data']) == 0 || $_SESSION['modules']['world_data']['cachetime'] <= (time() - $this->world_cache_time) ) {
			unset($_SESSION['modules']['world_data']); // clear previous values
			$_SESSION['modules']['world_data']['cachetime'] = time();
			
			$this->LoadWorldData();
			// send to debug
			$MOD->AddDebugGeneral('World', sprintf('World cache refreshed (time: %s)', date('Y-m-d h:i:s', $_SESSION['modules']['world_data']['cachetime'])));
		}
		
		$MOD->AddDebugGeneral('World', sprintf('World Max Cached (time: %ss)', $this->world_cache_time));
		$MOD->AddDebugGeneral('World', sprintf('World Est cache refresh @ %s', date('Y-m-d h:i:s', $_SESSION['modules']['world_data']['cachetime'] + $this->world_cache_time)));
		
		$MOD->Trace(__FUNCTION__, 'stop');
	}
	
	/**
	 * 
	 */
	private function LoadLoginData() {
		$_SESSION['modules']['login_data']['accounts'] 	= $this->LoadAccounts();
		$_SESSION['modules']['login_data']['characters']= $this->LoadCharacters();

		$this->GetLoginStats();
	}


	private function LoadWorldData() {
		$_SESSION['modules']['world_data']['servers'] 	= $this->LoadServers();
		//$_SESSION['modules']['world_data']['active'] 	= $this->LoadActiveServers();
		
		$this->GetWorldStats();
	}



	/**
	 * Getters
	 */
	private function LoadAccounts() {
		$this->SQLQuery = sprintf("SELECT * FROM ".LOGIN_DATABASE.".account ORDER BY name");
		return $this->RunQueryMulti();
	}


	private function LoadCharacters() {
		$this->SQLQuery = sprintf("SELECT * FROM ".LOGIN_DATABASE.".login_characters ORDER BY account_id, server_id, name");
		return $this->RunQueryMulti();
	}


	private function LoadServers() {
		$this->SQLQuery = sprintf("SELECT lws.* FROM ".LOGIN_DATABASE.".login_worldservers lws JOIN ".LOGIN_DATABASE.".account a ON lws.serverop = a.name ORDER BY a.id, lws.name");
		return $this->RunQueryMulti();
	}


	private function LoadActiveServers() {
		$this->SQLQuery = sprintf("SELECT ls.id AS world_id, ls.name, ws.current_players, ws.world_status FROM ".LOGIN_DATABASE.".login_worldservers ls " .
								  "LEFT JOIN ".LOGIN_DATABASE.".login_worldstats ws ON ls.id = ws.world_id " .
								  "WHERE ls.lastseen >= %s " .
								  "ORDER BY ls.lastseen DESC", $this->CalcMaxHistoryLength());
		return $this->RunQueryMulti();
	}
	
	
	private function GetLoginStats() {
		// TODO: hacking in for now
		$this->SQLQuery = "SELECT MAX(VERSION) AS minor_version FROM eq2_patcher.table_versions";
		$result = $this->RunQuerySingle();
                $_SESSION['modules']['login_data']['minor_version'] = $result['minor_version'];

		// change these to Dates soon as the eq2_patcher table gets updated properly
                $this->SQLQuery = "SELECT `name` FROM eq2_patcher.table_versions tv, eq2_patcher.`tables` t WHERE tv.`table_id` = t.`table_id` ORDER BY tv.`id` DESC LIMIT 0,1";
                $result = $this->RunQuerySingle();
                $_SESSION['modules']['login_data']['table_date'] = $result['name'];

                $this->SQLQuery = "SELECT `name` FROM eq2_patcher.table_data td, eq2_patcher.`tables` t WHERE td.`table_id` = t.`table_id` ORDER BY td.`id` DESC LIMIT 0,1";
                $result = $this->RunQuerySingle();
                $_SESSION['modules']['login_data']['data_date'] = $result['name'];
 
		/* removing until it can be fixed using new patcher database
		if( is_array($result) ) {
			foreach($result as $data) {
				$minor_version = ( $data['minor_version'] > $minor_version ) ? $data['minor_version'] : $minor_version;
				switch($data['log_type']) {
					case "Data Update":
						$data_date = date('Y-m-d', $data['changed_on']);
						break;
					case "Create Table":
					case "Update Table":
						$table_date = date('Y-m-d', $data['changed_on']);
						break;
				}
			}
			
			$_SESSION['modules']['login_data']['minor_version'] = $minor_version;
			$_SESSION['modules']['login_data']['data_date']		= $data_date;
			$_SESSION['modules']['login_data']['table_date']	= $table_date;
		}
		*/
		
		// more stats
		$this->SQLQuery = sprintf("SELECT COUNT(id) AS servers FROM ".LOGIN_DATABASE.".login_worldservers WHERE lastseen >= %s", $this->CalcMaxHistoryLength());
		$data = $this->RunQuerySingle();
		$_SESSION['modules']['login_data']['server_count']	= $data['servers'];
		$data = NULL;
		$this->SQLQuery = sprintf("SELECT SUM(current_players) AS players FROM ".LOGIN_DATABASE.".login_worldstats");
		$data = $this->RunQuerySingle();
		$_SESSION['modules']['login_data']['player_count']	= $data['players'];
		$data = NULL;
		$this->SQLQuery = sprintf("SELECT COUNT(world_id) AS servers 
									FROM ".LOGIN_DATABASE.".login_worldstats ws1
									JOIN ".LOGIN_DATABASE.".login_worldservers ws2 on ws1.world_id = ws2.id
									WHERE world_status > -4");
		$data = $this->RunQuerySingle();
		$_SESSION['modules']['login_data']['server_active']	= $data['servers'];
	}

	
	private function GetWorldStats() {
		$this->SQLQuery = sprintf("SELECT ls.id AS world_id, ls.name, ls.server_url, ls.hide_details, ws.current_players, ws.world_status " .
								  "FROM ".LOGIN_DATABASE.".login_worldservers ls " .
								  "LEFT JOIN ".LOGIN_DATABASE.".login_worldstats ws ON ls.id = ws.world_id " .
								  "WHERE ls.lastseen >= %s %s" .
								  "ORDER BY ls.lastseen DESC " .
								  "%s", 
								  	$this->CalcMaxHistoryLength(),
									( $_SESSION['modules']['config']['hide_offline'] ) 		 ? " AND world_status > -4" : "",
									( $_SESSION['modules']['config']['max_server_display'] ) ? " LIMIT 0,".$_SESSION['modules']['config']['max_server_display'] : "");
		$result = $this->RunQueryMulti();
		
		if ( is_array($result) ) {
			$worldCount = 0;
			
			foreach($result as $row) {
				
				$server = array(); // init
				
				$server['serverId'] = $row['world_id'];
				$server['serverName'] = ( strlen($row['name']) < 22 ) ? trim($row['name']) : sprintf("%s...", substr($row['name'], 0, 22));
				$server['current_status'] = ( $this->ls_online == 1 ) ? $row['world_status'] : -4;
				if( strlen($server['serverName']) > 0 ) {
					switch($server['current_status']) {
						case NULL:
						case -4:
							$server['worldColor']	= 'high.png'; // offline
							$server['worldStatus']	= 'Offline';
							break;
						case -3:
							$server['worldColor'] 	= "full.png";
							$server['worldStatus']	= 'Full';
							break;
						case -2:
							$server['worldColor'] 	= "locked.png";
							$server['worldStatus']	= 'Private';
							break;
						case -1:
							$server['worldColor'] 	= "critical.png";
							$server['worldStatus']	= 'Unknown';
							break;
						default:
							$server['worldColor'] 	= "low.png";
							$server['worldStatus']	= 'Online';
							break;
					}
					$server['worldStatusIcon'] = sprintf('<img src="%s" width="15" border="0" title="%s" />', IMG_PATH.$server['worldColor'], $server['worldStatus']);
					// 2017.04.13 - only takes user to Server List page for now
					$server['detailLink'] = ( $row['hide_details']==0 ) ? sprintf('<a href="index.php?p=servers&id=%s" title="Click for server info!">%s</a>', $server['serverId'], $server['serverName']) : $server['serverName'];
					$server['serverStatus'] = sprintf("%-15s", $server['worldStatusIcon']);
					$server['current_players'] = ( intval($row['current_players']) > 0 ) ? $row['current_players'] : 0;
				
					$_SESSION['modules']['world_data']['active'][$server['serverId']] = $server;
				}
			++$worldCount;
			} // end foreach
		} // end is_array
		//print_r($_SESSION['modules']['world_data']['active']);
	}


	/**
	 * Local function to check if loginserver heartbeat is within 'n' seconds
	 */
	public function CheckLoginServerStatus() {
		// MAX_LOGIN_HEARTBEAT value set in DEFINE at top of script
		$this->SQLQuery = sprintf("SELECT COUNT(*) AS login_active FROM ".LOGIN_DATABASE.".login_config WHERE config_name = 'login_heartbeat' AND config_value >= UNIX_TIMESTAMP(NOW()) - %s", MAX_LOGIN_HEARTBEAT);
		$result = $this->RunQuerySingle();
		return $result['login_active'];
	}


	private function CalcMaxHistoryLength() {
		// first, set some defaults - just in case
		if( strlen($_SESSION['modules']['config']['max_history_interval']) > 0 )
			$interval = $_SESSION['modules']['config']['max_history_interval'];
		else
			$interval = "days";
			
		if( intval($_SESSION['modules']['config']['max_history_length']) > 0 )
			$length = $_SESSION['modules']['config']['max_history_length'];
		else
			$length = 7;
			
	
		switch($interval) {
			case "days": 
				$max_history_time = 60 * 60 * 24 * $length;
				break;
	
			case "weeks": 
				$max_history_time = 60 * 60 * 24 * 7 * $length;
				break;
	
			case "months": 
				$max_history_time = 60 * 60 * 24 * 30 * $length;
				break;
	
			case "years": 
				$max_history_time = 60 * 60 * 24 * 365 * $length;
				break;
			
			default:
				$max_history_time = 0;
				break;
		}
		
		return time() - $max_history_time;
	}
	
	
	// construct the left-side widgets
	public function Left() {
		$this->LeftMenu();
		$this->LeftLinks();
	}
	
	private function LeftMenu() {
		global $MOD;
		
		?>
		<div id="portal-menu">
			<div id="nav" class="bg1">
				<ul>
					<li class="menu-title">Portal Home</li>
					<li><a href="/phpBB3/index.php">Forums</a></li>
					<!-- <li><a href="index.php?p=servers"<?php if( $MOD->Page == "servers" ) print(' class="active"') ?>>Server List</a></li> -->
					<!-- <li><a href="index.php?p=account"<?php if( $MOD->Page == "account" ) print(' class="active"') ?>>Account Management</a></li> -->
					<!-- <li><a href="index.php?p=irc"<?php if( $MOD->Page == "irc" ) print(' class="active"') ?>>IRC Info</a></li> -->
					<li><a href="/phpBB3/memberlist.php">Members</a></li>
					<li><a href="/phpBB3/search.php">Search</a></li>
				</ul>
				<ul>
					<li class="menu-title">Project Info</li>
					<!-- <li><a href="index.php?p=projman"<?php if( $MOD->Page == "projman" ) print(' class="active"') ?>>Project Manager</a></li> -->
					<?php if( $MOD->is_admin ) { ?>
					<li><a href="index.php?p=bugs"<?php if( $MOD->Page == "bugs" ) print(' class="active"') ?>>Bug Tracker</a></li>
					<?php } ?>
					<!-- <li><a href="index.php?p=svn"<?php if( $MOD->Page == "svn" ) print(' class="active"') ?>>SVN</a></li>
					<li><a href="https://svn.eq2emulator.net/!/#eq2server/history" target="_blank">ChangeLog</a></li> -->

<li><a href="index.php?p=git"<?php if( $MOD->Page == "git" ) print(' class="active"') ?>>Source Code</a></li>

<a href="https://github.com/EQ2Emulator-net" target="_blank">GitHib Repo</a></li>
					<li><a href="index.php?p=about"<?php if( $MOD->Page == "about" ) print(' class="active"') ?>>About Us</a></li>
				</ul>
				<ul>
					<li class="menu-title">Resources</li>
					<li><a href="/wiki/index.php/Players:AoM_Client">Player Guide</a></li>
					<!-- <li><a href="/wiki/index.php/Admins">Admin Guide</a></li> -->
					<li><a href="/wiki/index.php">Wiki</a></li>
					<li><a href="/phpBB3/viewforum.php?f=33">Dev Forums</a></li>
					<!-- <li><a href="/phpBB3/feed.php">RSS Feed</a></li> -->
					<li><a href="index.php?p=commands"<?php if( $MOD->Page == "commands" ) print(' class="active"') ?>>GM Command List</a></li>
				</ul>
				<?php if( $MOD->is_admin || $MOD->is_dev || $MOD->is_dba ) { ?>
				<ul>
					<li class="menu-title">Project Administration</li>
					<!--<li><a href="index.php?p=login"<?php if( $MOD->Page == "login" ) print(' class="active"') ?>>LoginServer Manager</a></li>
					<li><a href="index.php?p=modules"<?php if( $MOD->Page == "modules" ) print(' class="active"') ?>>Module Settings</a></li>-->
					<?php if( $MOD->is_dba ) { ?>
					<li><a href="index.php?p=patcher"<?php if( $MOD->Page == "patcher" ) print(' class="active"') ?>>DB Auto-Updates</a></li>
					<?php } ?>
				</ul>
				<?php } ?>
			</div>
		</div>
		<br />&nbsp;
		<?php
	}


	private function LeftLinks() {
		?>
		<div id="portal-menu">
			<div id="nav" class="bg1">
				<ul>
					<li class="menu-title">EQ2 Social</li>
					<li><a href="http://www.facebook.com/pages/EQ2Emulatornet/196292440467150" target="_blank">Facebook</a></li>
					<li><a href="http://twitter.com/#!/EQ2Emulator" target="_blank">Twitter</a></li>
					<li><a href="https://discord.gg/sCR4fPZ" target="_blank">Discordapp</a></li>
				</ul>
				<ul>
					<li class="menu-title">EQ2 Info</li>
					<li><a href="https://www.everquest2.com/home" target="_blank">Official EQ2 Site</a></li>
					<li><a href="https://forums.daybreakgames.com/eq2/index.php" target="_blank">Official EQ2 Forums</a></li>
				</ul>
				<ul>
					<li class="menu-title">Reference</li>
					<li><a href="http://eq2.zam.com/" target="_blank">EQ2Zam's</a></li>
					<li><a href="http://eq2.wikia.com/" target="_blank">EQ2Wikia</a></li>
				</ul>
			</div>
		</div>
		<br />&nbsp;
		<?php
	}


	// Displays the main content modules/widgets based on ?p= querystring
	public function Main() {
		global $MOD;
		
		?>
		<div id="portal">
		<?php
		switch($MOD->Page) {
			
			case "about":
				$this->DisplaySiteText('about');
				break;
				
			case "account":
				include(PORTAL_ROOT_PATH."blocks/Accounts.php");
				break;
				
			case "bugs":
				include(PORTAL_ROOT_PATH."blocks/Bugs.php");
				break;
				
			case "commands":
				$this->GMCommandList();
				break;
		
			case "irc":
				$this->DisplaySiteText('irc');
				break;
				
			case "login":
				include(PORTAL_ROOT_PATH."blocks/Login.php");
				break;
		
			case "patcher":
				include(PORTAL_ROOT_PATH."blocks/DBPatcher.php");
				break;
		
			case "projman":
				include(PORTAL_ROOT_PATH."blocks/ProjectManager.php");
				break;
			
			case "modules":
				include(PORTAL_ROOT_PATH."blocks/Modules.php");
				break;
			
			case "servers":
				include(PORTAL_ROOT_PATH."blocks/ServerList.php");
				break;
		
			//case "svn":
				//include(PORTAL_ROOT_PATH."blocks/SVN.php");
		
			case "git":
				include(PORTAL_ROOT_PATH."blocks/Git.php");

				break;
				
			default:
				$this->DisplaySiteText('index');
				break;
		}
		?>
		</div>
		<br />
		<br />&nbsp;
		<?php
	}
	
	
	public function Right() {
	?>
	<div id="portal">
	<?php
	//$this->LoginStats();
	//$this->WorldStats();
              $this->DiscordView();
	?>
	</div>
	<?php
	}
	
	
	/** 
	 * Kinda messy, but let's see how it plays out :-)
	 */
	private function DisplaySiteText($page) {
		global $MOD;
		
		$MOD->SQLQuery = sprintf("SELECT p.*, topic_title, topic_time, topic_views, topic_first_post_id, topic_first_poster_name, topic_first_poster_colour FROM ".PORTAL_DATABASE.".site_text p ".
								 "LEFT JOIN phpbb3_topics ON link_to_topic_id = topic_id " .
								 "WHERE pagename = '%s' AND (is_active = 1 OR is_sticky = 1 OR (NOW() BETWEEN displayfrom AND displayto)) " .
								 "ORDER BY display_order, postdate DESC", $page);
		$result = $MOD->RunQueryMulti();
		
		if( count($result) > 0 ) {
			// group the sections together
			foreach( $result as $post ) {
				$data[$post['sectiontitle']][] = $post;
			}
			
			if( count($data) > 0 ) {
				// now, print the sections
				foreach( $data as $section=>$val ) {
					$i = 0;
					$section_text  = ( $val[0]['icon'] != 'none' ) ? sprintf('<img src="%s" border="0" />&nbsp;%s ', IMG_PATH.$val[0]['icon'], $val[0]['sectiontitle']) : sprintf('<img src="%s" border="0" />&nbsp;%s ', IMG_PATH."information.png", $val[0]['sectiontitle']);
					?>
					<div id="section">
						<ul>
							<li class="section-title"><?php print( $section_text ) ?></li>
						</ul>
					</div>
					<?php
					if( $val[0]['link_to_topic_id'] > 0 || count($data[$section]) > 1 ) {
						foreach($data[$section] as $result) {
							$postlink = "";
							$poster_info = "";
							// try to get a valid post title from both sources
							if( strlen($result['topic_title']) > 0 ) {
								$postlink = sprintf('<a href="/phpBB3/viewtopic.php?t=%s">%s</a>', $result['link_to_topic_id'], $result['topic_title']);
							} else {
								$postlink = sprintf('<a href="/phpBB3/viewtopic.php?t=%s">%s</a>', $result['link_to_topic_id'], $result['posttitle']);
							}
							if( strlen($result['topic_first_poster_name']) > 0 ) {
								$poster_info = sprintf('<font color="#%s">%s</font>', $result['topic_first_poster_colour'], $result['topic_first_poster_name']);
								$posted_on = sprintf("&nbsp;<strong>on</strong>&nbsp;%s", date('M d, Y', $result['topic_time']));
								$views = sprintf("&nbsp;(%s views)", $result['topic_views']);
							}
							
							?>
							<div class="post bg1">
								<div class="inner">
									<div class="postbody">
										<?php if( strlen($postlink) > 0 ) { ?>
										<h3 class="first"><?php print( $postlink ) ?></h3>
										<?php } ?>
										<div class="content">
											<?php if( strlen($poster_info) > 0 ) { ?>
											<p><strong>Posted By:</strong> <?php print( $poster_info ) ?><?php print( $posted_on ) ?><?php print( $views ) ?></p>
											<?php } ?>
											<?php print( $result['postbody'] ) ?>
										</div>
									</div>
								</div>
							</div>
							<?php
							$i++;
						}
					} else {
						// only 1 post
						$postlink = $val[0]['posttitle'];
						$poster_info = ( strlen($val[0]['author']) > 0 ) ? sprintf("<strong>Posted by:</strong> %s", $val[0]['author']) : "";
						if( $val[0]['postdate'] > 0 ) {
							$posted_on = sprintf("&nbsp;<strong>on</strong>&nbsp;%s", date('M d, Y', $val[0]['postdate']));
						}
						?>
						<div class="post bg1">
							<div class="inner">
								<div class="postbody">
									<?php if( strlen($postlink) > 0 ) { ?>
									<h3 class="first"><?php print( $postlink ) ?></h3>
									<?php } ?>
									<div class="content">
										<?php if( strlen($poster_info) > 0 ) { ?>
										<p><?php print( $poster_info ) ?><?php print( $posted_on ) ?><?php print( $views ) ?></p>
										<?php } ?>
										<?php print( $val[0]['postbody'] ) ?>
									</div>
								</div>
							</div>
						</div>
						<?php
					}
				} // end foreach section
			}
		}
	}

	private function DiscordView() {
	?>
		<div class="text-red-500">
		<div id="section">
			<ul>
				<li class="section-title">Discord Information</li>
			</ul>
		</div>
		</div>
		<div class="post bg1">
			<div class="inner">
				<div class="postbody">
					<table width="100%">
  <tr>
    <td colspan="2"><p>EQ2Emu public discord <a href="https://discord.gg/sCR4fPZ">Invite</a></p></td>
  </tr>
  <tr>
    <td>
      <iframe src="https://discord.com/widget?id=210453864678293514&theme=dark" width="190" height="500" allowtransparency="true" frameborder="0" sandbox="allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts"></iframe>
    </td>
  </tr>
</table>
					</li>
				</ul>
			</div>
		</div>
	<?php
	}


	private function LoginStats() {
	?>
		<div id="section">
			<ul>
				<li class="section-title">Public Login Information</li>
			</ul>
		</div>
		<div class="post bg1">
			<div class="inner">
				<div class="postbody">
					<table>
						<col width="60" />
						<col />
						<tr>
							<td ><strong>Status</strong></td>
							<td>:&nbsp;<?= ( $this->ls_online ) ? '<span class="lsOnline">ONLINE</span>' : '<span class="lsOffline">OFFLINE</span>' ?></td>
						</tr>
						<tr>
							<td colspan="2" height="10"><!--spacer--></td>
						</tr>
						<tr>
							<td rowspan="3" valign="top"><strong>Servers</strong></td>
							<td>:&nbsp;<?= ( $this->ls_online ) ? $_SESSION['modules']['login_data']['server_active'] : 0; ?> online</td>
						</tr>
						<tr>
							<td>:&nbsp;<?= $_SESSION['modules']['login_data']['server_count'] ?> recent</td>
						</tr>
						<tr>
							<td>:&nbsp;<?= count($_SESSION['modules']['world_data']['servers']) ?> total worlds</td>
						</tr>
						<tr>
							<td colspan="2" height="5"><!--spacer--></td>
						</tr>
						<tr>
							<td colspan="2" align="center">
								<span style="font-size:0.8em">
								<?php printf('Based on last %s %s activity', $_SESSION['modules']['config']['max_history_length'], $_SESSION['modules']['config']['max_history_interval']) ?>
								</span>
							</td>
						</tr>
						<tr>
							<td colspan="2" height="5"><!--spacer--></td>
						</tr>
						<tr>
							<td colspan="2" align="center"><a href="?p=servers" class="modules"><u>Click for Server List</u></a></td>
						</tr>
						<tr>
							<td colspan="2" height="10"><!--spacer--></td>
						</tr>
						<tr>
							<td ><strong>Players</strong></td>
							<td>:&nbsp;<?= $_SESSION['modules']['login_data']['player_count'] ?> online</td>
						</tr>
						<tr>
							<td ><strong>Accounts</strong></td>
							<td>:&nbsp;<?= count($_SESSION['modules']['login_data']['accounts']) ?> created</td>
						</tr>
						<tr>
							<td ><strong>Characters</strong></td>
							<td>:&nbsp;<?= count($_SESSION['modules']['login_data']['characters']) ?> active</td>
						</tr>
						<tr>
							<td colspan="2" height="10"><!--spacer--></td>
						</tr>
						<tr>
							<td colspan="2" align="center"><strong>Recent Updates</strong></td>
						</tr>
						<tr>
							<td><strong>Tables</strong></td>
							<td>:&nbsp;<?= $_SESSION['modules']['login_data']['table_date'] ?></td>
						</tr>
						<tr>
							<td><strong>Data</strong></td>
							<td>:&nbsp;<?= $_SESSION['modules']['login_data']['data_date'] ?></td>
						</tr>
						<tr>
							<td><strong>Version</strong></td>
							<td>:&nbsp;<?= $_SESSION['modules']['login_data']['minor_version'] ?></td>
						</tr>
						<tr>
							<td colspan="2" height="10"><!--spacer--></td>
						</tr>
						<tr>
							<td><strong>Client</strong></td>
							<td>:&nbsp;<?= $_SESSION['modules']['config']['max_client_version'] ?></td>
						</tr>
						<tr>
							<td><strong>DataVer</strong></td>
							<td>:&nbsp;<?= $_SESSION['modules']['config']['max_client_data_version'] ?></td>
						</tr>
						<tr>
							<td colspan="2" height="10"><!--spacer--></td><?php /*?>trying to line the bottom of the login box with Welcome :/ <?php */?>
						</tr>
					</table>
				</div>
			</div>
		</div>
	<?php
	}
	
	
	private function WorldStats() {
	?>
		<div id="section">
			<ul>
				<li class="section-title">World Status</li>
			</ul>
		</div>
		<div class="post bg1">
			<div class="inner">
				<div class="postbody">
					<table width="100%" cellspacing="0" cellpadding="0">
						<col />
						<col width="20" />
						<col width="20" />
						<tr>
							<td><strong>Server Name</strong></td>
							<td colspan="2">&nbsp;</td>
						</tr>
						<tr>
							<td colspan="3" height="10"><hr /></td>
						</tr>
						<?php
						if ( count($_SESSION['modules']['world_data']['active']) > 0 ) {
							foreach($_SESSION['modules']['world_data']['active'] as $key=>$val) {
						?>
						<tr>
							<td><?php print( $val['detailLink'] ) ?></td>
							<td align="right" title="Server Status"><?php print( $val['worldStatusIcon'] ) ?></td>
							<td align="right" title="Players Online"><?php echo $val['current_players'] ?></td>
						</tr>
						<?php
							} // end foreach
						} // end is_array
						?>
						<tr>
							<td colspan="3" height="10"><!--spacer--></td>
						</tr>
						<tr>
							<td colspan="3" align="center">
								<span style="font-size:0.8em">
								<?php 
								if( count($_SESSION['modules']['world_data']['active']) > 0 ) {
									printf('Based on last %s %s activity', $_SESSION['modules']['config']['max_history_length'], $_SESSION['modules']['config']['max_history_interval']);
								} else {
									print('No Servers Available');
								}
								?>
								</span>
							</td>
						</tr>
					</table>
					</li>
				</ul>
			</div>
		</div>
	<?php
	}
	

	private function GMCommandList() {
	?>
		<div id="section">
			<ul>
				<li class="section-title">GM Commands</li>
			</ul>
		</div>
		<div class="post bg1">
			<div class="inner">
				<div class="postbody">
					<div class="content">
						<p>List of Custom GM Commands (slash commands) available currently</p>
						<p><em>Note that you must have the required access to use the command, some are restricted on EQ2Emulator server</em></p>
						<p>Access: 0 = All, 1+ = GM/Dev only</p>
					</div>
				</div>
			</div>
		</div>
		<div id="section">
			<ul>
				<li class="section-title">Commands</li>
			</ul>
		</div>
		<table width="100%" border="0" id="page-body" class="post bg1">
			<tr height="25">
				<td width="100"><strong>ID</strong></td>
				<td><strong>Command+Sub</strong></td>
				<td width="100"><strong>Handler</strong></td>
				<td width="100"><strong>Access</strong></td>
			</tr>
			<?php
			$this->SQLQuery = "SELECT * FROM eq2emu.commands ORDER BY command, subcommand;";
			$result = $this->RunQueryMulti();
			
			if( is_array($result) ) {
				$row_count = 0;
				foreach( $result as $data ) {
					$row_color = ( $row_count % 2 ) ? ' bgcolor="#EEEEEE"' : ' bgcolor="#FFFFFF"';
	
					printf('<tr%s>', $row_color);
					printf('<td style="padding:5px;">%s</td>', $data['id']);
					printf('<td style="padding:5px;">.%s %s</td>', $data['command'], $data['subcommand']);
					printf('<td style="padding:5px;">%s</td>', $data['handler']);
					printf('<td style="padding:5px;">%s</td>', $data['required_status']);
					print('</tr>');
					$row_count++;
				}
			}
			else
				print("No Records Found.");
			
			?>
			<tr>
				<td colspan="6" style="background-color:#ccc"><strong>Rows: <?= $row_count ?></strong></td>
			</tr>
		</table>
	<?php		
	}




	/**
	 * Override SQL functions from Common
	 * REALLY dislike doing it this way, but I need separate creds/servers for gameservers?
	 */
	/****************************************************************************
	 * SQL Database Functions
	 ****************************************************************************/
	public function DBError() {
		global $MOD;
		
		$error = $this->db->sql_error();
		print_r($error);
		?>
		<div id="error-box">
		<table cellspacing="0" align="center">
			<tr>
				<td colspan="2" class="title">SQL Error: <?php print($error['code']); ?></td>
			</tr>
			<tr>
				<td class="label">Message:</td>
				<td class="detail"><?php print($error['message']); ?></td>
			</tr>
			<tr>
				<td class="label">Trace:</td>
				<td class="detail">
					<?php 
					print($MOD->GetBacktrace());
					?>
				</td>
			</tr>
			<tr>
				<td class="label">Query:</td>
				<td><?php print($this->SQLQuery); ?></td>
			</tr>
		</table>
		</div>
		<?php 
		if( $_SESSION['modules']['config']['debug'] == 1 && $_SESSION['modules']['user']['id'] == 2 ) 
			$MOD->DisplayDebug();
		include(PORTAL_ROOT_PATH."common/inc_footer.php");
		die();
	}

	/* SELECT: Use this RunQuery to return a single-row result set */
	public function RunQuerySingle($sql = '') {
		global $MOD;
		
		/*** Override $this with passed parameters ***/
		if( is_null($this->SQLQuery) && strlen($sql) > 6 )
			$this->SQLQuery = $sql;
		/**********************************************/
			
		// add ; to end of query, if missing, just for logging to screen
		if( strpos($this->SQLQuery, ";") == 0 )
			$this->SQLQuery = trim($this->SQLQuery) . ";";
			
		if( $_SESSION['modules']['config']['debug'] ) {
			$start_time = time();
			$MOD->AddDebugFunction(__FUNCTION__, "Enter");
			$MOD->AddDebugQuery(__FUNCTION__, $this->SQLQuery);
		}
		
		if( !$result = $this->db->sql_query($this->SQLQuery) ) {
			$this->DBError();
		} else {
			// 2015.04.11 - build a list of column names retrieved
			/*$num_fields = $this->db->sql_numfields($result);
			if( $num_fields > 0 ) {
				for( $i=0; $i < $num_fields; $i++)
					$this->ColumnNames[] = $this->db->sql_fieldname($i, $result);
			}*/
			
			$num_rows = $this->db->sql_affectedrows($result);
			$rtn = $this->db->sql_fetchrow($result);
		}
		
		if( $_SESSION['modules']['config']['debug'] ) {
			$MOD->AddDebugData("RunQuerySingle", $rtn);
			$MOD->AddDebugFunction(__FUNCTION__, $num_rows." row(s)");
			if( $Elapsed > 1 )
				$Exit = sprintf("Exit - Elapsed: %s<br />Slow Query: %s", $Elapsed, $this->SQLQuery);
			else
				$Exit = "Exit";
			$MOD->AddDebugFunction(__FUNCTION__, $Exit);
		}

		unset($this->SQLQuery);  // nuke the query so it isn't used again
		
		return $rtn;
	}
	
	
	/* SELECT: Use this RunQuery to return a multiple-row result set */
	public function RunQueryMulti($sql = '') {
		global $MOD;
		
		/*** Override $this with passed parameters ***/
		if( is_null($this->SQLQuery) && strlen($sql) > 6 )
			$this->SQLQuery = $sql;
		/**********************************************/
			
		// add ; to end of query, if missing, just for logging to screen
		if( strpos($this->SQLQuery, ";") == 0 )
			$this->SQLQuery = trim($this->SQLQuery) . ";";
			
		if( $_SESSION['modules']['config']['debug'] ) {
			$start_time = time();
			$MOD->AddDebugFunction(__FUNCTION__, "Enter");
			$MOD->AddDebugQuery(__FUNCTION__, $this->SQLQuery);
		}
		
		if( !$result = $this->db->sql_query($this->SQLQuery) ) {
			$this->DBError();
		} else {
			// 2015.04.11 - build a list of column names retrieved
			// 2016.10.11 - phpBB3.1 no longer supports numfields
			/*$num_fields = $this->db->sql_numfields($result);
			if( $num_fields > 0 ) {
				for( $i=0; $i < $num_fields; $i++)
					$this->ColumnNames[] = $this->db->sql_fieldname($i, $result);
			}*/
			
			$num_rows = $this->db->sql_affectedrows($result);
			while( $data = $this->db->sql_fetchrow($result) ) 
				$rtn[] = $data;
		}
		
		if( $_SESSION['modules']['config']['debug'] ) {
			$MOD->AddDebugData("RunQueryMulti Data", $rtn);
			$MOD->AddDebugFunction(__FUNCTION__, $num_rows." row(s)");
			$Elapsed = time() - $start_time;
			if( $Elapsed > 1 )
				$Exit = sprintf("Exit - Elapsed: %s<br />Slow Query: %s", $Elapsed, $this->SQLQuery);
			else
				$Exit = "Exit";
			$MOD->AddDebugFunction(__FUNCTION__, $Exit);
		}

		unset($this->SQLQuery);  // nuke the query so it isn't used again
		
		return $rtn;
	}
	

	public function RunQuery($sql = '') {
		global $MOD;
		
		$num_rows = 0;
		
		/*** Override $this with passed parameters ***/
		if( is_null($this->SQLQuery) && strlen($sql) > 6 )
			$this->SQLQuery = $sql;
		/**********************************************/

		// Check if SQLQuery has a valid query
		if( strlen($this->SQLQuery) === 0 )
			die("Invalid SQLQuery: '" . $this->SQLQuery . "'");
			
		// this should set the QueryType always
		$this->QueryType = substr($this->SQLQuery, 0, 6);
		
		// add ; to end of query, if missing, just for logging to screen
		if( strpos($this->SQLQuery, ";") == 0 )
			$this->SQLQuery = trim($this->SQLQuery) . ";";
			
		if( $_SESSION['modules']['config']['debug'] ) {
			$start_time = time();
			$MOD->AddDebugFunction(__FUNCTION__, "Enter");
			if( $_SESSION['modules']['config']['readonly'] )
				$MOD->AddDebugQuery(__FUNCTION__, "READ-ONLY: ".$this->SQLQuery);
			else
				$MOD->AddDebugQuery(__FUNCTION__, $this->SQLQuery);
		}
		
		switch($this->QueryType) {
			
			case "SELECT":
				if( !$result=$this->db->sql_query($this->SQLQuery) )
					$this->DBError();
				else {
					// temp: checking to see if I call RunQuery directly for any select statements
					die("Do not call RunQuery for Selects directly. Use RunQuerySingle, RunQueryMulti");
					$data = $this->db->sql_fetchrow($result);
				}
					
				break;
				
			case "INSERT":
			case "UPDATE":
			case "DELETE":
				if( $_SESSION['modules']['config']['readonly'] ) {
					$MOD->AddStatus("READ-ONLY MODE (".$this->QueryType.") - No data updated!");
				} else {
					if( !$result = $this->db->sql_query($this->SQLQuery) )
						$this->DBError();
					else {
						$num_rows = $this->db->sql_affectedrows($result);
						
						$this->AffectedRows = $num_rows;
						$MOD->AddDebugGeneral("Affected Rows", $this->AffectedRows);
						$this->LastInsertID = $this->db->sql_nextid();
						$MOD->AddDebugGeneral("Last Insert ID", $this->LastInsertID);
					}
				}
				break;
		}
		
		if( $_SESSION['modules']['config']['debug'] )
		{
			$MOD->AddDebugData("RunQuery Data", $data);
			$MOD->AddDebugFunction(__FUNCTION__, $num_rows." row(s)");
			if( $Elapsed > 1 ) // i don't think I'm calculating Elapsed?
				$Exit = sprintf("Exit - Elapsed: %s<br />Slow Query: %s", $Elapsed, $this->SQLQuery);
			else
				$Exit = "Exit";
			$MOD->AddDebugFunction(__FUNCTION__, $Exit);
		}
		
		unset($this->QueryType); // nuke the type so it isn't used again
		unset($this->SQLQuery);  // nuke the query so it isn't used again
		
		return $num_rows;
	}

	public function LogQuery() {
		global $MOD;
		
		// Check if SQLQuery has a valid query
		if( strlen($this->SQLQuery) === 0 )
			die("Invalid SQLQuery: '" . $this->SQLQuery . "'");
			
		// add ; to end of query, if missing, just for logging to screen
		if( strpos($this->SQLQuery, ";") == 0 )
			$this->SQLQuery = trim($this->SQLQuery) . ";";
			
		if( $_SESSION['modules']['config']['debug'] ) {
			$MOD->AddDebugFunction(__FUNCTION__, "Enter");
			if( $_SESSION['modules']['config']['readonly'] )
				$MOD->AddDebugQuery(__FUNCTION__, "READ-ONLY: ".$this->SQLQuery);
			else
				$MOD->AddDebugQuery(__FUNCTION__, $this->SQLQuery);
		}
		
		if( $_SESSION['modules']['config']['readonly'] ) {
			$MOD->AddStatus("READ-ONLY MODE (".$this->QueryType.") - No data updated!");
		} else {
			if( !$result = $this->db->sql_query($this->SQLQuery) )
				$this->DBError();
			// no LastInserID or AffectedRows on Log inserts!
		}
		
		if( $_SESSION['modules']['config']['debug'] )
			$MOD->AddDebugFunction(__FUNCTION__, "Exit");
		
		unset($this->QueryType); // nuke the type so it isn't used again
		unset($this->SQLQuery);  // nuke the query so it isn't used again
		
		return $num_rows;
	}

	public function GetTotalRows($database, $table) {
		$this->SQLQuery = sprintf("SELECT count(*) AS num FROM %s.%s;", $database, $table);
		$data = $this->RunQuerySingle();
		return ( !empty($data) ) ? $data['num'] : 0;
	}

	private function SQLLog() {
		global $MOD, $user;
		
		// stuff insert, update, delete queries into VGOeditor.log table
		if( $_SESSION['modules']['config']['debug'] )
			$MOD->AddDebugFunction(__FUNCTION__, "Enter");
		
		/*
		 * Logging Stuff goes Here
		 */
		if( $_SESSION['modules']['config']['sql_log'] )
		{
			$pattern[0] = "/".DEV_DB."\./i";
			$replace[0] = "";
			
			$log_query = preg_replace($pattern, $replace, $this->SQLQuery);
			
			// can't use RunQuery because we're getting the wrong LastInsertID!
			$log_insert = sprintf("INSERT INTO log (user_id, username, table_name, object_id, update_query, update_date) VALUES ('%s','%s','%s','%s','%s','%s')",
								$data->user['user_id'],
								$this->SQLEscape($data->user['username']),
								$this->SQLEscape($this->TableName),
								$this->SQLEscape($this->ObjectID),
								$this->SQLEscape($log_query),
								time());
			
			if( !$result = $this->db->sql_query($log_insert) )
				$this->DBError();
		}

		/*
		 * File Logging
		 */
		// 2016.10.23 - this needs to be refactored for portal apps
		if( $_SESSION['modules']['config']['sql_log_file'] )
		{
			$logfile = sprintf("logs/session_%s_%s_week%s.txt", 
												 strtolower($_SESSION['modules']['user']['username']), 
												 date("Y", time()), 
												 date("W", time()));

			$log_query .= "\n";
			
			if( $_SESSION['modules']['config']['readonly'] )
				$MOD->AddStatus("READ-ONLY MODE - ".$logfile." not saved!");
			else
			{
				if( file_exists($logfile) ) 
				{
					if( !$f = fopen($logfile, 'a') ) 
						die("Cannot open existing filename: $logfile");
		
					if( !fwrite($f, $log_query) )
						die("Cannot write to existing filename: $logfile");
		
					fclose($f);
				} 
				else 
				{
					if( !$f = fopen($logfile, 'x') ) 
						die("Cannot create new file: $logfile");
						
					if( !fwrite($f, $log_query) )
							die("Cannot write to new filename: $logfile");
							
					fclose($f);
				}
			}
			
		}

		if( $_SESSION['modules']['config']['debug'] )
			$MOD->AddDebugFunction(__FUNCTION__, "Exit");
	}

	public function SQLEscape($str) {
		return $this->db->sql_escape($str);
	}


	public function NoResults() {
		print("No Results in " . __FUNCTION__ . ", " . __LINE__);
	}

	
	
} // END Class

?>
