/* Custom JA js code */
function dosub(subm) 
{ 
	if (subm != "") 
	{ 
		self.location=subm; 
	} 
}

function SetServerBreadcrumb(value)
{
	var ss = document.getElementById('server-list-server-name');
	document.write(ss.value);
}


/* Google Search-like js code */
function getXmlHttpRequestObject() 
{
	if (window.XMLHttpRequest) 
	{
		return new XMLHttpRequest();
	} 
	else if(window.ActiveXObject) 
	{
		return new ActiveXObject("Microsoft.XMLHTTP");
	} 
	else 
	{
		alert("Incompatible web browser.");
	}
}

var searchReq = getXmlHttpRequestObject();

function handleSearchSuggest() 
{
	if (searchReq.readyState == 4) 
	{
		var ss = document.getElementById('search_suggest');
		ss.innerHTML = '';
		var str = searchReq.responseText.split("\n");
		for(i=0; i < str.length - 1; i++) 
		{
			var suggest = '<div onmouseover="javascript:suggestOver(this);" ';
			suggest += 'onmouseout="javascript:suggestOut(this);" ';
			suggest += 'onclick="javascript:setSearch(this.innerHTML);" ';
			suggest += 'class="suggest_link">' + str[i] + '</div>';
			ss.innerHTML += suggest;
		}
	}
}

function suggestOver(div_value) 
{
	div_value.className = 'suggest_link_over';
}

function suggestOut(div_value) 
{
	div_value.className = 'suggest_link';
}

function setSearch(value) 
{
	document.getElementById('txtSearch').value = value;
	document.getElementById('search_suggest').innerHTML = '';
}

function goBack () {
	window.open('index.php?p=bugs', target='_self');
}

/* Bug Tracker status checks */
function CheckStatus() {
	
	// check assignee, if not set, disable a bunch of stuff
	var assign = document.getElementById("assignee").value;
	if( assign == 0 ) {
		document.getElementById("update").disabled = true;
		document.getElementById("fixedby").disabled = true;
		document.getElementById("forum").disabled = true;
		document.getElementById("assignee").style = "border:1px solid #f00; background-color:#966; color:#fff;";
	} else {
		document.getElementById("update").disabled = false;
		//document.getElementById("update").style = "border:1px solid #f00;";
		document.getElementById("forum").disabled = false;
		document.getElementById("assignee").style = "border:1px solid #000; background-color:#fff; color:#000;";
		
		// check bug status, if still New, disable a bunch of stuff
		var status = document.getElementById("status").value;
		if( status != "Fixed" && status != "Fixed in Dev" ) {
			document.getElementById("fixedby").disabled = true;
		} else {
			document.getElementById("fixedby").disabled = false;
		}
		
	}
}
