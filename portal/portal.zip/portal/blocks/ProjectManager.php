<?php
if( !defined("IN_PORTAL") )
	die("Hacking attempt.");

include_once(PORTAL_ROOT_PATH."classes/mod.projman.php");
$PM = new MODProjman();


//if( !$MOD->is_team ) 
//	$MOD->_halt(); // basic Access Denied message


// do the heavy lifting here
if( isset($_GET['id']) )
	$PM->Detail(); 	// update/delete here
else if( isset($_GET['add']) )
	$PM->Add();		// insert here
else
{
	switch($_POST['cmd'])
	{
		case "Search":
			$PM->SetFilters();
			$PM->Search();
			break;
			
		case "Clear":
			$PM->ClearFilters();
			$PM->Search();
			break;
			
		default:
			$PM->Search();
			break;	
	}

	$PM->Screen();	// select here
}
?>
