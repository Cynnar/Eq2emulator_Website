<?php
if( !defined("IN_PORTAL") )
	die("Hacking attempt.");
?>

<div id="section">
	<ul>
		<li class="section-title">EQ2Emulator Source Control Information (SVN)</li>
	</ul>
</div>
<div class="post bg1">
	<div class="inner">
		<div class="postbody">
			<div class="content">
				<p> If you are using a Windows-based operating system, a GUI subversion client such as <a href="http://tortoisesvn.tigris.org" onclick="window.open(this.href);return false;" class="postlink">TortoiseSVN</a> is recommended to retrieve the source code. 
					You may also point a web browser to the SVN URL and see the latest revisions.</p>
				<p>If your OS is Linux-based, you can install the SVN package available for your OS and retrieve the latest code with a simple command line:</p>
				<dl class="codebox">
					<dt>Code: <a href="#" onclick="selectCode(this); return false;">Select all</a></dt>
					<dd><code style="font-size:1.3em;">svn co https://svn.eq2emulator.net/svn/eq2server/trunk EQ2</code></dd>
				</dl>
				<p>&nbsp;</p>
				<p>SVN Username: <span style="font-weight: bold">anonymous</span> (no password required)</p>
				<h3>Server Code SVN</h3>
				<br />
				<p>
				<ul>
					<li style="font-size:1.3em;">Main Public SVN: <a href="https://svn.eq2emulator.net/svn/eq2server" target="_blank">https://svn.eq2emulator.net/svn/eq2server</a></li>
					<!--<li>Mirror Public SVN: <a href="http://code.google.com/p/eq2emu-server/source/checkout" onclick="window.open(this.href);return false;" class="postlink">http://code.google.com/p/eq2emu-server/source/checkout</a></li>-->
				</ul>
				</p>
				<p>&nbsp;</p>
				<h3>Content SVN</h3>
				<br />
				<p>
				<ul>
					<li style="font-size:1.3em;">Database/Scripts: <a href="https://svn.eq2emulator.net/svn/eq2content" target="_blank">https://svn.eq2emulator.net/svn/eq2content</a></li>
				</ul>
				</p>
				<p>&nbsp;</p>
				<h3>EQ2Emulator Tools SVN</h3>
				<br />
				<p>
				<ul>
					<li style="font-size:1.3em;">Tools: <a href="https://svn.eq2emulator.net/svn/eq2tools" target="_blank">https://svn.eq2emulator.net/svn/eq2tools</a></li>
				</ul>
				</p>
				<p>&nbsp;</p>
				<p>See the <a href="http://eq2emulator.net/wiki/index.php/Admins:Server_Setup_Guide" target="_blank">Server Admins Guide</a> for more information on compiling and setting up your own server. </p>
				<p>&nbsp;</p>
			</div>
		</div>
	</div>
</div>
<?php if( $MOD->is_dev ) { ?>
<div id="section">
	<ul>
		<li class="section-title">Private SVN Information</li>
	</ul>
</div>
<div class="post bg1">
	<div class="inner">
		<div class="postbody">
			<div class="content">
				<p> Private SVN is for Developers only. Do not give out your login information for any reason. Code committed here gets synchronized to the Public SVN (and mirror) weekly - so be sure to thoroughly test your code before committing.</p>
				<p>Developers of Content and Tools have read-write access to the Public Content and Tools SVNs, and should commit content or tools only to those SVN Repositories.</p>
				<p>Private SVN Username and Password have been sent to you via PM</p>
				<p>&nbsp;</p>
				<h3>Developer SVNs</h3>
				<br />
				<p>
				<ul>
					<li style="font-size:1.3em;">Server Code: <a href="https://svn.eq2emulator.net/svn/EQ2" target="_blank">https://svn.eq2emulator.net/svn/EQ2</a></li>
					<li style="font-size:1.3em;">Logs (private): <a href="https://svn.eq2emulator.net/svn/eq2logs" target="_blank">https://svn.eq2emulator.net/svn/eq2logs</a></li>
				</ul>
				</p>
			</div>
		</div>
	</div>
</div>
<?php } ?>
