<?php
if( !defined("IN_PORTAL") )
	die("Hacking attempt.");

include_once(PORTAL_ROOT_PATH."classes/mod.account.php");
$ACC = new MODAccount();

$ACC->Account();
?>