<?php
if( !defined("IN_PORTAL") )
	die("Hacking attempt.");

include_once(PORTAL_ROOT_PATH."classes/mod.server.php");
$SRV = new MODServers();

//if( !$MOD->is_team ) 
//	$MOD->_halt();

$SRV->Status();
?>