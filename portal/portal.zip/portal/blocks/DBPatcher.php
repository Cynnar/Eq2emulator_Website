<?php 
if( !defined("IN_PORTAL") )
	die("Hacking attempt.");

include_once(PORTAL_ROOT_PATH."classes/mod.database.php");
$DATA = new MODDatabase();

if( !$MOD->is_dba ) 
	$MOD->_halt(); // basic Access Denied message

$DATA->Screen();	// very simple display
?>
