<?php
if( !defined("IN_PORTAL") )
	die("Hacking attempt.");

include_once(PORTAL_ROOT_PATH."classes/mod.bugtrack.php");
$BT = new MODBugs();

if( !$BT->is_team ) 
	$BT->_halt(); // basic Access Denied message

// That's it... drawing "Container" now in constructor







/**
 * Oh boy, you need to clean this sucker out below this line :D 
 */
 
function old_page_header() {
	?>
	<div id="BugTrack">
		<table class="main">
			<tr>
				<td valign="top">
	<?
	if( $_GET['id'] > 0 )
		ShowBugDetail();
	elseif( $_GET['id'] == "add" )
		ShowBugAdd();
	else
	{
		switch($_POST['cmd'])
		{
			case "Convert":
				foreach($_POST as $key=>$val)
				{
					if( $key == "convert_from" )
						$status_from = $val;
					if( $key == "convert_to" )
						$status_to = $val;
				}
				$query = sprintf("UPDATE bugs SET Status = '%s', bug_updated = %lu WHERE Status = '%s'", $status_to, time(), $status_from);
				if( !$result = $db2->sql_query($query) )
				{
					$error = $db2->sql_error();
					die($error['message']);
				}
				$log_array['log_type'] 			= 'Admin';
				$log_array['log_operation'] = 'BUG_MANAGER_CONVERT_STATUS';
				$log_array['log_data']			= sprintf("f:%s;t:%s;u:%s;q:%s", $_POST['convert_from'], $_POST['convert_to'], GetMyName(), $db2->sql_escape($query));
				log_action( $log_array );
				//break;
	
			case "Search Bugs":
				SetCriteriaSession();
				DisplayBugSearchDialog();
				break;
				
			case "Clear":
				foreach($_SESSION as $key=>$val)
				{
					$tmp = explode(":", $key);
					// clear session from status search form
					if( $tmp[0] == "bugs" ) 
					{
						//print("UNSET 1!<br />");
						session_unset($key);
					}
				}
				DisplayBugSearchDialog();
				break;
			
			
			case "fixpid"	: 
				FixPostIDDialog(); 
				break;
				
				
			default:
				SetCriteriaSession();
				DisplayBugSearchDialog();
				break;	
		}
	
		ShowBugList();
		//foreach($_POST as $key=>$val) printf("POST: %s = %s<br>", $key, $val);
		//foreach($_SESSION as $key=>$val) printf("SESS: %s = %s<br>", $key, $val);
	}
	?>
				</td>
			</tr>
		</table>
	</div>
	<?
}  // end old page header


/*
	Function: DisplayBugSearchDialog()
	Purpose	: Input fields to search through bug list, shows only Servers whom have bugs on record.
*/
function DisplayBugSearchDialog()
{
	global $Link, $is_admin, $user;
	
	//ForMe($_SESSION);
	
	// set up pre-selected criteria based on Session or Post
	$server_name 		= ( isset($_SESSION['bugs:server_name']) ) ? $_SESSION['bugs:server_name'] : 0;
	$category 			= ( isset($_SESSION['bugs:category']) ) ? $_SESSION['bugs:category'] : 0;
	$subcategory 		= ( isset($_SESSION['bugs:sub_id']) ) ? $_SESSION['bugs:sub_id'] : 0;
	$status			 		= ( isset($_SESSION['bugs:status']) ) ? $_SESSION['bugs:status'] : "New";
	$age				 		= ( isset($_SESSION['bugs:age']) ) ? $_SESSION['bugs:age'] : 0;
	$text				 		= ( isset($_SESSION['bugs:text']) ) ? $_SESSION['bugs:text'] : "";
	$submitted_by		= ( isset($_SESSION['bugs:submitted_by']) ) ? $_SESSION['bugs:submitted_by'] : 0;
	$assign_id 			= ( isset($_SESSION['bugs:assign_to_forum_id']) ) ? $_SESSION['bugs:assign_to_forum_id'] : 0;
	$status_except	= ( isset($_SESSION['bugs:status_except']) ) ? $_SESSION['bugs:status_except'] : 0;
	$order_by				= ( isset($_SESSION['bugs:order_by']) ) ? $_SESSION['bugs:order_by'] : "ASC";
	$bug_type 			= ( isset($_SESSION['bugs:forum_id']) ) ? $_SESSION['bugs:forum_id'] : 0;
?>
	<div style="box-shadow: 5px 5px 5px #888888; background-color:#eee;margin-top:10px;">
	<table width="100%" border="0" cellspacing="4" cellpadding="4">
	<form action="<?= $Link ?>" method="post" name="bugsearch">
		<tr>
			<td colspan="4" align="center" class="ps_category">Bug Tracker</td>
		</tr>
		<tr>
			<td width="15%"></td>
			<td width="40%"></td>
			<td width="15%"></td>
			<td width="30%"></td>
		</tr>
		<tr>
			<td colspan="4" align="center"><strong>Search Bugs:</strong>&nbsp;Use this form to limit your bug list to server or specific problem.</td>
		</tr>
		<tr>
			<td align="right"><strong>Server Name:</strong>&nbsp;</td>
			<td colspan="3">&nbsp;
				<? $options = GetServersWithBugs($server_name); ?>
				<select name="bugs|server_name" style="width:400px; font-size:11px;">
					<option value="0">All Servers</option>
					<?= $options; ?>
				</select>
			</td>
		</tr>
		<tr>
			<td align="right"><strong>Category:</strong>&nbsp;</td>
			<td>&nbsp;
				<? $options = GetActiveBugCategories($category); ?>
				<select name="bugs|category" style="width:150px; font-size:11px;">
					<option value="0">All Categories</option>
					<?= $options; ?>
				</select>
			</td>
			<td align="right"><strong>Sub-Category:</strong>&nbsp;</td>
			<td>&nbsp;
				<? $options = GetActiveBugSubCategories($subcategory); ?>
				<select name="bugs|sub_id" style="width:150px; font-size:11px;">
					<option value="0">All Sub-Categories</option>
					<?= $options; ?>
				</select>
			</td>
		</tr>
		<tr>
			<td align="right"><strong>Status:</strong>&nbsp;</td>
			<td>&nbsp;
				<select name="bugs|status" style="width:150px; font-size:11px;">
					<option value="All"<?php if( $status==="All" ) print(" selected") ?>>All Statuses</option>
					<option<?php if( $status==="New" ) print(" selected") ?>>New</option>
					<option<?php if( $status==="Assigned" ) print(" selected") ?>>Assigned</option>
					<option<?php if( $status==="Fixed" ) print(" selected") ?>>Fixed</option>
					<option<?php if( $status==="Need Info" ) print(" selected") ?>>Need Info</option>
					<option<?php if( $status==="Not Implemented" ) print(" selected") ?>>Not Implemented</option>
					<option<?php if( $status==="Not a Bug" ) print(" selected") ?>>Not a Bug</option>
					<option<?php if( $status==="Duplicate" ) print(" selected") ?>>Duplicate</option>
					<option<?php if( $status==="Closed" ) print(" selected") ?>>Closed</option>
					<option<?php if( $status==="All Open" ) print(" selected") ?>>All Open</option>
				</select>&nbsp;
				<input type="checkbox" name="bugs|status_except" value="1"<?php if( $status_except ) print(" checked") ?> /> Except
			</td>
			<td align="right"><strong>Bug Age:</strong>&nbsp;</td>
			<td>&nbsp;
				<select name="bugs|age" style="width:150px; font-size:11px;">
					<option value="0"<?php if( $age==0 ) print(" selected") ?>>All Dates</option>
					<option value="1"<?php if( $age==1 ) print(" selected") ?>>1 Day</option>
					<option value="7"<?php if( $age==7 ) print(" selected") ?>>7 Days</option>
					<option value="14"<?php if( $age==14 ) print(" selected") ?>>2 Weeks</option>
					<option value="30"<?php if( $age==30 ) print(" selected") ?>>1 Month</option>
					<option value="90"<?php if( $age==90 ) print(" selected") ?>>3 Months</option>
					<option value="180"<?php if( $age==180 ) print(" selected") ?>>6 Months</option>
					<option value="360"<?php if( $age==360 ) print(" selected") ?>>1 Year</option>
					<option value="720"<?php if( $age==720 ) print(" selected") ?>>2 Years</option>
				</select>
			</td>
		</tr>
		<tr>
			<td align="right"><strong>Order By:</strong>&nbsp;</td>
			<td>&nbsp;
				<select name="bugs|order_by" style="width:150px; font-size:11px;">
					<option<?php if( $order_by === "ASC" ) print(" selected") ?>>ASC</option>
					<option<?php if( $order_by === "DESC" ) print(" selected") ?>>DESC</option>
				</select>
			</td>
			<td align="right"><strong>Bug Type:</strong>&nbsp;</td>
			<td>&nbsp;
				<select name="bugs|forum_id" style="width:150px; font-size:11px;">
					<option value="">All Bugs</option>
					<option value="22"<?php if( $bug_type==22 ) print(" selected") ?>>Server Bug</option>
					<option value="23"<?php if( $bug_type==23 ) print(" selected") ?>>Content Bug</option>
					<option value="24"<?php if( $bug_type==24 ) print(" selected") ?>>Tools Bug</option>
				</select>
			</td>
		</tr>
		<?
		if( $is_admin )
		{
		?>
		<tr>
			<td align="right"><strong>Submitted By:</strong>&nbsp;</td>
			<td>&nbsp;
				<? $options = GetBugAuthors($submitted_by); ?>
				<select name="bugs|submitted_by" style="width:150px; font-size:11px;">
					<option value="0"<?php if( empty($_SESSION['bugs:submitted_by']) || $_SESSION['bugs:submitted_by'] == 0 ) print(" selected"); ?>>Everyone</option>
					<?= $options; ?>
				</select>
			</td>
			<td align="right"><strong>Assigned To:</strong>&nbsp;</td>
			<td>&nbsp;
				<? $options = GetActiveAssigned($assign_id); ?>
				<select name="bugs|assign_to_forum_id" style="width:150px; font-size:11px;">
					<option value="0">All Assignees</option>
					<?= $options; ?>
				</select>
			</td>
		</tr>
		<?
		}
		?>
		<tr>
			<td align="right" nowrap="nowrap"><strong>Search Text/ID:</strong>&nbsp;</td>
			<td colspan="3">&nbsp;
				<input type="text" name="bugs|text" value="<?= $text ?>" style="width:90%; font-size:11px" />&nbsp;
			</td>
		</tr>
		<tr>
			<td colspan="4" align="center">
				<input type="submit" name="cmd" value="Search Bugs" />&nbsp;
				<input type="submit" name="cmd" value="Clear" />&nbsp;
			</td>
		</tr>
		<?
		if( $is_ja )
		{
		?>
		<tr>
			<td colspan="4" align="center">Convert Status from&nbsp;
				<select name="convert_from" style="width:150px; font-size:11px;">
					<option>---</option>
					<option<?php if( $status==="New" ) print(" selected") ?>>New</option>
					<option<?php if( $status==="Assigned" ) print(" selected") ?>>Assigned</option>
					<option<?php if( $status==="By Design" ) print(" selected") ?>>By Design</option>
					<option<?php if( $status==="Closed" ) print(" selected") ?>>Closed</option>
					<option<?php if( $status==="Deleted" ) print(" selected") ?>>Deleted</option>
					<option<?php if( $status==="Duplicate" ) print(" selected") ?>>Duplicate</option>
					<option<?php if( $status==="Fixed" ) print(" selected") ?>>Fixed</option>
					<option<?php if( $status==="Fixed in Dev" ) print(" selected") ?>>Fixed in Dev</option>
					<option<?php if( $status==="Invalid" ) print(" selected") ?>>Invalid</option>
					<option<?php if( $status==="Not a Bug" ) print(" selected") ?>>Not a Bug</option>
					<option<?php if( $status==="Need Info" ) print(" selected") ?>>Need Info</option>
					<option<?php if( $status==="Not Implemented" ) print(" selected") ?>>Not Implemented</option>
					<option<?php if( $status==="Server Specific" ) print(" selected") ?>>Server Specific</option>
				</select>&nbsp;to&nbsp;
				<select name="convert_to" style="width:150px; font-size:11px;">
					<option>New</option>
					<option>Already Fixed</option>
					<option>Assigned</option>
					<option>Fixed</option>
					<option>Server Specific</option>
					<option>Invalid</option>
					<option>Closed</option>
					<option>Duplicate</option>
					<option>Need Info</option>
					<option>Not Implemented</option>
					<option>Deleted</option>
					<option>Not a Bug</option>
					<option>By Design</option>
					<option selected="selected">Fixed in Dev</option>
				</select>
				&nbsp;
				<input type="submit" name="cmd" value="Convert" style="width:100px; font-size:11px" />&nbsp;
			</td>
		</tr>
		<?
		}
		?>
		</form>
	</table>
	</div>
<?php
}


/*
	Function: DisplayBugAddDialog
	Purpose	: Finds orphaned bugs on Forums and sets the proper Post ID.
*/
function FixPostIDDialog()
{
	global $db, $db2;
	
	// First, find bugs without post_id's
	$sql = "select id, summary, assign_to_forum_id from bugs where post_id = 0 and status not in ('Closed', 'Deleted')";
	if( !$result = $db2->sql_query($sql) )
		die("SQL Error");
		
	$bug_array = array();
	while( $row = $db2->sql_fetchrow($result) )
	{
		$bug_array[] = $row;
	}

	//print_r($bug_array);
	
	if( is_array($bug_array) )
	{
		//print_r($bug_array);
		foreach($bug_array as $bug)
		{
			$pattern[0] = "/\"/i";
			$pattern[1] = "/\'/i";
			$replace[0] = "";
			$replace[1] = "";
			
			
			$subject = sprintf("BugID: %s (%s) %s", $bug['id'], LookupForumUser($bug['assign_to_forum_id']), preg_replace($pattern, $replace, $bug['summary']));
			
			$sql2 = sprintf("select post_id, forum_id from phpbb3_posts where post_subject = '%s' order by post_id limit 0,1", $subject);
			//echo $sql2;
			
			if( !$result2 = $db->sql_query($sql2) )
				die("SQL Error");
				
			$data2 = $db->sql_fetchrow($result2);
			if( $data2['post_id'] > 0 )
			{
				//printf("%i<br>", intval($data2['forum_id']));
				if( $data2['forum_id'] == 13 || $data2['forum_id'] == 23 )
				{
					printf("=> <strong>Updating</strong> bug_id: %s with forum_id %s, post_id %s<br />", $bug['id'], $data2['forum_id'], $data2['post_id']);
					$update = sprintf("update bugs set post_id = %s where id = %lu", $data2['post_id'], $bug['id']);
					if( !$result3 = $db2->sql_query($update) )
						die("SQL Error");
				}
				else
				{
					//printf("<p>%s</p>", $sql2);
					// other ones in the wrong forums?
					printf('<p>Subject: %s is forum_id: %s, post_id: <a href="http://eq2emulator.net/phpBB3/viewtopic.php?p=%s#p%s" target="_blank">%s</a></p>', $subject, intval($data2['forum_id']), intval($data2['post_id']), intval($data2['post_id']), intval($data2['post_id']));
					//exit;
				}
			}
			else
			{
				printf('<p>What is this? %s is forum_id: %s, post_id: <a href="http://eq2emulator.net/phpBB3/viewtopic.php?p=%s#p%s" target="_blank">%s</a></p>', $subject, intval($data2['forum_id']), intval($data2['post_id']), intval($data2['post_id']), intval($data2['post_id']));
			}
		}
	}
	exit;
	
	?>
	<table width="50%" cellspacing="0" cellpadding="0" border="0" class="bg1">
		<tr>
			<td colspan="2" align="center" height="50"><strong>Post ID's Fixed!</strong></td>
		</tr>
	</table>
	<?php
}


/*
	Function: DisplayBugAddDialog
	Purpose	: 
*/
function ShowBugAdd()
{
	global $db2, $bug_cat;
	
	if( isset($_POST['cmd']) )
	{
		// save these in case something went wrong in the form submission
		$summary = $_POST['bugs|summary'];
		$detail = $_POST['bugs|description'];
		
		switch($_POST['cmd'])
		{
			case "Submit Report":
			
				if( strlen($_POST['bugs|category']) > 0 && 
						strlen($_POST['bugs|sub_id']) > 0 && 
						strlen($_POST['bugs|description']) > 0 && 
						strlen($_POST['bugs|summary']) > 0 ) 
				{
					foreach($_POST as $key=>$val) {
						//printf("%s = %s<br />", $key, $val);
						$chkKey = explode("|",$key);
						if( $chkKey[0]=="bugs" && $val ) {
							if( empty($fields) ) {
								$fields.=$chkKey[1];
								$values.="'".addslashes($val)."'";
							} else {
								$fields.=", ".$chkKey[1];
								$values.=",'".addslashes($val)."'";
							}
							
							if($chkKey[1]=="server_name")
								$server_name = $chkKey[1];
						}
					}	
					
					if( !empty($fields) ) {
						// fetch account info based on forum user ID+Key
						// note, won't find them if they have never used Account Manager
						$fields .= ", account_id";
						$values .= sprintf(", '%s'", GetMyAccountID());
						
						$query = sprintf("INSERT INTO bugs (%s) VALUES (%s);", $fields, $values); 
						//print($query); exit;
						
						if( !$result = $db2->sql_query($query) ) {
							$error = $db2->sql_query();
							die($error['message']);
						}
	
						$sql2 = "SELECT LAST_INSERT_ID() AS nextid";
						//printf("%s<br />", $sql2);
						if( !$result = $db2->sql_query($sql2) ) {
							$error = $db2->sql_query();
							die($error['message']);
						}
						
						$id = $db2->sql_fetchrow($result);
						$new_id = $id['nextid'];
							
						$log_array['log_type'] 			= 'Admin';
						$log_array['log_operation'] = 'BUG_MANAGER_ADD';
						$log_array['log_data']			= sprintf("i:%lu;u:%s;q:%s", $new_id, GetMyName(), $db2->sql_escape($query));
						log_action( $log_array );
						
						$status = '<span style="color:#00F; font-weight:bold; font-size:13px;">Bug saved! Thank you!</span>';
						$summary = '';
						$detail = '';
						
					} else {
						$status = '<span style="color:#F00; font-weight:bold; font-size:13px;">Nothing to save!</span>';
					}
					
				} else {
					$status = '<span style="color:#f00; font-weight:bold; font-size:13px;">All required fields must have data!</span>';
				}
				/*?><script language="javascript">window.open('<?= $Link ?>', target='_self');</script><?php*/
				break;
			
			default:
				/*?><script language="javascript">window.open('<?= $Link ?>&cmd=add', target='_self');</script><?php*/
				break;
		}
	}
?>
	<div style="box-shadow: 5px 5px 5px #888888; background-color:#eee;margin-top:10px;">
	<table width="100%" cellspacing="0" cellpadding="0" border="0" class="bg1">
	<form action="../index.php?p=bugs&amp;id=add" method="post" name="bugadd">
		<tr>
			<td colspan="4" align="center" class="ps_category">Report a Bug</td>
		</tr>
    <tr>
    	<td valign="top" class="bg2" width="50%">
      	<fieldset>
        <table border="1" cellspacing="0">
        	<tr>
          	<td valign="top" style="padding:10px; height:470px;">
            	<strong>Instructions:</strong> Use this form to submit a bug report. When entering bugs, please follow these guidelines:<br />
	            <br />
              <ul style="list-style:disc; margin-left:20px; font-size:10px;">
              <li>We prefer bugs are submitted from within game, due to the additional information provided... but if you cannot, this form has been provided as an alternative (eg., maybe your WorldServer is crashed and you cannot log in)</li>
              <li><span class="required">Items in RED are required!</span>
              <li>Include only one bug per bug report submitted.</li>
              <li>Use plain, simple, and complete sentences.</li>
              <li>List step by step instructions on how to reproduce the bug.</li>
              <li>Your bug submission will be reviewed by a VGOEmu Team Member and assigned to a developer as soon as possible.</li>
              <li>Not all bugs are top priority, so exercise patience when submitting a bug for review.</li>
              </ul>
              <br />

              Thank you for taking the time to make VGOEmulator a better World!
            </td>
          </tr>
        </table>
      	</fieldset>
      </td>
      <td valign="top" class="bg3" align="center">
      	<table cellspacing="5" style="padding-top:10px">
        	<tr>
          	<td align="right"><strong>Server Name:&nbsp;</strong></td>
            <td><? $worlds = GetRecentActiveServer(); ?>
            	<select name="bugs|server_name" style="font-size:11px; width:200px">
              	<option value="New Telon">&lt;Select Server&gt;</option>
		            <? 
								if( is_array($worlds) )
								{
									foreach($worlds as $world) 
									{
										$selected = ( $_POST['bugs|server_name'] == $world['server_name'] ) ? " selected" : "";
										printf('<option style="padding-left:5px;"%s>%s</option>', $selected, $world['server_name']);
									}
								}
								?>
            	</select>
            </td>
          </tr>
        	<tr>
          	<td align="right"><span class="required">Category:&nbsp;</span></td>
            <td>
            	<select name="bugs|category" style="font-size:11px; width:200px;">
              	<option value="">&lt;Select Category&gt;</option>
                <?php
								foreach($bug_cat as $key=>$val)
									printf('<option style="padding-left:5px">%s</option>', $key);
                ?>
            	</select>
            </td>
          </tr>
        	<tr>
          	<td align="right"><span class="required">SubCategory:&nbsp;</span></td>
            <td>
            	<select name="bugs|sub_id" style="font-size:11px; width:200px">
              	<option value="">&lt;Select subcategory&gt;</option>
                <?php
								foreach($bug_cat as $key=>$val)
								{
									foreach($val as $sub=>$desc)
									{
										if( $sub > 0 )
											printf('<option value="%s" style="padding-left:5px">%s</option>', $sub, $desc);
									}
								}
                ?>
            	</select>
            </td>
          </tr>
        	<tr>
          	<td align="right"><strong>Severity?&nbsp;</strong></td>
            <td>
            	<select name="bugs|sev_id" style="font-size:11px; width:200px">
              	<option value="1">&lt;Select Severity&gt;</option>
              	<option value="0">Severe (e.g. Exploitable)</option>
              	<option value="1">Standard</option>
              	<option value="2">Minor (e.g. Cosmetic)</option>
            	</select>
            </td>
          </tr>
        	<tr>
          	<td align="right"><strong>Reproducible?&nbsp;</strong></td>
            <td>
            	<select name="bugs|rep_id" style="font-size:11px; width:200px">
              	<option value="2">&lt;Select Reproducibility&gt;</option>
              	<option value="0">Every time</option>
              	<option value="1">Some of the time</option>
              	<option value="2">Only seen once</option>
            	</select>
            </td>
          </tr>
        	<tr>
          	<td align="right"><span class="required">Summary:&nbsp;</span></td>
           	<td><input type="text" name="bugs|summary" value="<?= $summary ?>" style="font-size:11px; width:265px" /></td>
          </tr>
        	<tr>
          	<td align="right" valign="top"><span class="required">Description:&nbsp;</span></td>
            <td>
            	<textarea name="bugs|description" style="width:270px; height:100px"><?= $detail ?></textarea>
            </td>
          </tr>
        	<tr>
            <td colspan="2" align="center" style="padding-top:15px">
            	<input type="submit" name="cmd" value="Submit Report" style="font-size:11px; width:100px" />&nbsp;
              <input type="button" value="Done" style="font-size:11px; width:100px" onclick="window.open('index.php?p=bugs', target='_self');" />&nbsp;
							<input type="hidden" name="bugs|forum_username" value="<?= GetMyForumName(); ?>" />
							<input type="hidden" name="bugs|createdate" value="<?= time(); ?>" />
							<input type="hidden" name="bugs|source" value="1" /> <?php /*?>forum submitted bug<?php */?>
							<input type="hidden" name="table" value="bugs" />
            </td>
          </tr>
					<tr>
						<td colspan="2" align="center"><?= $status ?></td>
					</tr>
        </table>
      </td>
    </tr>
	</form>
	</table>
	</div>
<?php
	
}


/*
	Function: ShowBugList
	Purpose	: 
*/
function ShowBugList()
{
	global $db2, $is_admin, $user, $Link, $bug_cat;

	$query = sprintf("SELECT * FROM bugs "); 

	if( $_GET['debug']==1 )
		ForMe($_SESSION);
	
	foreach($_SESSION as $key=>$val) {
		$tmp = explode(":", $key);
		if( $tmp[0] == "bugs" && $val ) {
			if( $_GET['debug']==1 )
				printf('<br />%s => %s', $key, $val);
			switch($tmp[1]) {
				case "text":
					$where .= sprintf("(description RLIKE '%s' OR bug_id = '%s')", addslashes($val), addslashes($val));
					break;
					
				case "age":
					$timebase = 86400; // 1 day
					$timediff = time() - ($timebase * $val);
					$where .= sprintf("(createdate >= %lu)", $timediff);
					break;
				
				case "submitted_by":
					$where .= sprintf("(char_name = '%s' OR forum_username = '%s')", $val, $val);
					break;
					
				/*case "forum_id":
					$where .= sprintf("(forum_id = '%s')", $val);
					break;
					
				case "assign_to_forum_id":
					$where .= sprintf("(assign_to_forum_id = '%s')", $val);
					break;*/
				
				case "status":
					if( $_SESSION['bugs:status'] == "All" ) {
						// set to bogus value to show all statuses
						$where .= sprintf("(status <> '')");
					} else if( $_SESSION['bugs:status_except']==1 ) {
						if( $_SESSION['bugs:status'] == 'All Open' ) {
							$where = "(Status NOT IN ('New','Assigned','Fixed'))";
						} else {
							$where .= sprintf("(%s != '%s')", $tmp[1], addslashes($val));
						}
					} else {
						if( $_SESSION['bugs:status'] == 'All Open' ) {
							$where = "(Status IN ('New','Assigned'))";
						} else {
							$where .= sprintf("(%s = '%s')", $tmp[1], addslashes($val));
						}
					}
					break;
					
				default:
					// do not process non-column filter data
					if( $tmp[1] != 'order_by' && $tmp[1] != 'status_except' )
						$where .= sprintf("(%s = '%s')", $tmp[1], addslashes($val));
					break;
			}
		}
	}

	if( isset($where) )
	{
		$where = preg_replace("/\)\(/", ") AND (", $where);
		$query .= " WHERE " . $where;
	} else {
		$query .= "WHERE Status = 'New'";
	}

	// set order reverse
	$order_by = sprintf(" ORDER BY createdate %s", $_SESSION['bugs:order_by']);
	$query .= $order_by;
	
	if( $_GET['debug']==1 )
		echo '<br />'.$query;
	
	$result = $db2->sql_query($query);
	
	?>
	<hr />
	<?php if( $user->data['user_id'] > 1 ) { ?>
	<table width="100%" border="0" cellspacing="0">
		<tr>
			<td width="80%" valign="middle" style="padding-top:5px; padding-bottom:5px;">
				<strong>Click <img src="/modules/images/gear_information.png" align="bottom" /> to see details of an entry.
				To add a new bug, click &quot;Add New&quot;.</strong>
			</td>
			<td width="20%" align="right" valign="middle">
				<input type="button" value="Add New" style="font-size:11px; width:90px;" onclick="javascript:window.open('<?= $Link ?>&id=add', target='_self');" />
			</td>
		</tr>
	</table>
	<?php } ?>
	<div style="box-shadow: 5px 5px 5px #888888; background-color:#eee;margin-top:10px;">
	<table width="100%" border="0" cellspacing="0" cellpadding="4">
		<tr>
			<td colspan="9" height="30" class="forabg">
				<span style="color:#eee; font-size:13px; font-weight:bold; padding:3px 0px 3px 0px;">&nbsp;Click &quot;Detail&quot; to see bug details.</span><br />
			</td>
		</tr>
		<tr height="25" class="bg3">
			<td width="50">&nbsp;<strong>id</strong></td>
			<td width="75"><strong>bug date</strong></td>
			<td width="100"><strong>status</strong></td>
			<td width="105"><strong>assigned to</strong></td>
			<td width="100" align="center"><strong>category / subcategory</strong></td>
			<td width="250"><strong>summary</strong></td>
			<td width="18"><strong>D</strong></td>
			<td width="18"><strong>N</strong></td>
			<td width="18"><strong>P</strong></td>
		</tr>
		<?php
		while($data=$db2->sql_fetchrow($result)) {
			$RowColor = ( $i % 2 ) ? 'bg1' : 'bg2';
			//$bug_has_notes = ( CheckHasBugNotes($data['id']) ) ? "font-weight:bold; color:#fff; background-color:#99c;" : "background-color:#ddd;";
			$priority_icon = ( $data['priority'] ) ? GetPriorityIcon($data['priority']) : "";
			//$summary = ( strlen($data['summary']) > 1 ) ? $data['summary'] : "[&lt;Needs Summary&gt;]";
			$summary = ( strlen($data['summary']) > 1 ) ? $data['summary'] : sprintf("%s...", substr($data['description'], 0, 95));
			?>
			<tr height="40" class="<?= $RowColor ?>">
				<td>&nbsp;<?= $data['bug_id'] ?></td>
				<td style="font-size:9px">&nbsp;<?= ($data['createdate']) ? date('M d, Y', $data['createdate']) : "N/A" ?></td>
				<td>&nbsp;<?= $data['Status'] ?></td>
				<td>&nbsp;<?= LookupForumUser($data['assign_to_forum_id']) ?></td>
				<td align="center"><?= $data['category'] ?> /<br><?= $bug_cat[$data['category']][$data['sub_id']+1] ?></td>
				<td><?= $summary ?></td>
				<td><a href="<?= $Link ?>&id=<?= $data['bug_id'] ?>" target="_self"><img src="/modules/images/gear_information.png" /></a></td>
				<td>
					<?php 
					if( CheckHasBugNotes($data['bug_id']) )
						printf('<img src="/modules/images/information.png" width="16" title="Has Notes" />');
					?>
				</td>
				<td><?= $priority_icon ?></td>
			</tr>
			<?php
			$i++;
		}	
		?>
		<tr>
			<td colspan="9" height="25" align="right"><strong>...<?= $i ? $i : 0 ?> bugs found&nbsp;</strong></td>
		</tr>
	</table>
	</div>
	<?php
}


/*
	Function: ShowBugList
	Purpose	: 
*/
function ShowBugDetail()
{
	global $db, $db2, $Link, $is_admin, $bug_cat;

	$bug_severity 			= array(0 => 'Severe (e.g. Exploitable)', 1 => 'Standard', 2 => 'Minor (e.g. Cosmetic)');
	$bug_reproducible 	= array(0 => 'Every time', 1 => 'Some of the time', 2 => 'Only seen once');
	$forum_severity			= array(1 => 15, 2 => 14, 3 => 13, 4 => 12, 5 => 11); // phpbb_icons IDs mapped to BugTrackers priority IDs
	
	if( isset($_POST['cmd']) )
	{
		switch($_POST['cmd'])
		{
			case "Fixed":
				if( $_POST['fixed_by_forum_id'] > 0 )
				{
					$sql = sprintf("UPDATE bugs SET Status = '%s', fixed_by_forum_id = %lu, updatedate = %lu WHERE bug_id = %lu", ( $_POST['bug_status'] == "Assigned" ) ? "Fixed" : $_POST['bug_status'], $_POST['fixed_by_forum_id'], time(), $_POST['orig_id']);
					//printf("%s<br />", $sql);
					if( !$result = $db2->sql_query($sql) )
					{
						$error = $db2->sql_error();
						die($error['message']);
					}
					$log_array['log_type'] 			= 'Admin';
					$log_array['log_operation'] = 'BUG_MANAGER_UPDATE_FIXED';
					$log_array['log_data']			= sprintf("i:%s;u:%s;n:%d;q:%s", $_POST['orig_id'], GetMyName(), $_POST['fixed_by_forum_id'], $db2->sql_escape($sql));
					log_action( $log_array );
				}
				break;
				
			case "Assign":
			
				if( $_POST['assigned_to'] > 0 ) {
					$sql = sprintf("UPDATE bugs SET Status = '%s', assign_to_forum_id = %lu, priority = %d, updatedate = %lu, summary = '%s', forum_id = %s WHERE bug_id = %lu", ( $_POST['bug_status'] == "New" ) ? "Assigned" : $_POST['bug_status'], $_POST['assigned_to'], $_POST['priority'], time(), $db2->sql_escape($_POST['summary']), $_POST['forum_id'], $_POST['orig_id']);
					//printf("%s<br />", $sql);
					$db2->sql_query($sql); // login DB
					
					$log_array['log_type'] 			= 'Admin';
					$log_array['log_operation'] = 'BUG_MANAGER_UPDATE_ASSIGN';
					$log_array['log_data']			= sprintf("i:%s;u:%s;n:%d;q:%s", $_POST['orig_id'], GetMyName(), $_POST['assigned_to'], $db2->sql_escape($sql));
					log_action( $log_array );
					
					
					// When a bug gets Assigned, post a forum topic to better track it. Re-assignments are posts added to an existing thread.
					if( isset($_POST['forum_post']) && $_POST['forum_post']==1 ) {
						
						// First, lookup to see if the bug already exists for appending Dev Notes:
						$sql = "SELECT * FROM phpbb3_topics WHERE topic_title LIKE 'Bug ".$_GET['id'].":%' ORDER BY topic_time DESC limit 0,1";
						//printf("%s<br />", $sql); exit;
						$row = $db->sql_fetchrow($db->sql_query($sql)); // phpBB DB
						
						// already posted this bug, so add re-assignment to the existing topic
						if( $row['topic_id'] > 0 ) {
							$existing									= 1;
							$topic_id 								= $row['topic_id'];
							$forum_id 								= $row['forum_id'];
							$icon_id									= $forum_severity[$_POST['priority']]; // in case the change is to a higher priority
							$topic_title							= sprintf("Bug %s: (%s) %s (Re-assigned)", $_GET['id'], LookupForumUser($_POST['assigned_to']), $_POST['summary']);
							$topic_poster 						= 3; //$user->data['user_id'];
							$topic_time 							= time();
							$topic_replies 						= $row['topic_replies'] + 1;
							$topic_replies_real 			= $topic_replies;
							$topic_first_post_id			= $row['topic_first_post_id'];
							$topic_first_poster_name	= $row['topic_first_poster_name'];
							$topic_first_poster_colour= $row['topic_first_poster_colour'];
							
							$topic_last_post_id				= $row['topic_last_post_id']; // new post not inserted yet, so this is 0
							$topic_last_poster_id			= $topic_poster;
							$topic_last_poster_name		= $topic_first_poster_name;
							$topic_last_poster_colour = 'AA0000';
							$topic_last_post_time 		= time();
							$topic_last_view_time			= $row['topic_time'];
		
							// the new topic_title may be different if re-assigning bug to someone else
							$topic_last_post_subject 	= $topic_title;
		
							$sql = sprintf("UPDATE phpbb3_topics SET
																icon_id = %d,
																topic_replies = %lu,
																topic_replies_real = %lu,
																topic_last_poster_id = %lu, 
																topic_last_poster_name = '%s', 
																topic_last_poster_colour = '%s', 
																topic_last_post_subject = '%s', 
																topic_last_post_time = %lu, 
																topic_last_view_time = %lu
															WHERE topic_id = %lu",
																$icon_id,
																$topic_replies,
																$topic_replies_real,
																$topic_last_poster_id,
																$db->sql_escape($topic_last_poster_name), 
																$topic_last_poster_colour,
																$db->sql_escape($topic_last_post_subject),
																$topic_last_post_time,
																$topic_last_view_time,
																$topic_id);
							//printf("%s<br />", $sql); exit;
							$db->sql_query($sql); // phpBB DB
							
						} else {
							// must be a new bug just being assigned so create a new topic
							$existing									= 0;
							$forum_id 								= $_POST['forum_id'];
							$icon_id									= $forum_severity[$_POST['priority']];
							$topic_title							= sprintf("Bug %s: (%s) %s", $_GET['id'], LookupForumUser($_POST['assigned_to']), $_POST['summary']);
							$topic_poster 						= 3; //$user->data['user_id'];
							$topic_time 							= time();
							
							$topic_replies 						= 0;
							$topic_replies_real 			= $topic_replies;
							
							$topic_first_post_id			= 0; // post not inserted yet, so this is 0
							$topic_first_poster_name	= LookupForumUser($topic_poster);
							$topic_first_poster_colour= 'AA0000';
							
							$topic_last_post_id				= $topic_first_post_id; // post not inserted yet, so this is 0
							$topic_last_poster_id			= $topic_poster;
							$topic_last_poster_name		= $topic_first_poster_name;
							$topic_last_poster_colour	= $topic_first_poster_colour;
							$topic_last_post_time			= $topic_time;
							$topic_last_view_time			= $topic_time;
							
							$topic_last_post_subject	= $topic_title;
			
							$sql = sprintf("INSERT INTO phpbb3_topics (
																forum_id,
																icon_id, 
																topic_title, 
																topic_poster, 
																topic_time, 
																topic_first_poster_name, 
																topic_first_poster_colour, 
																topic_last_poster_id, 
																topic_last_poster_name, 
																topic_last_poster_colour, 
																topic_last_post_subject, 
																topic_last_post_time, 
																topic_last_view_time
																) VALUES (
																%lu,
																%d,
																'%s',
																%lu,
																%lu,
																'%s',
																'%s',
																%lu,
																'%s',
																'%s',
																'%s',
																%lu,
																%lu)",
																$forum_id,
																$icon_id,
																$db->sql_escape($topic_title),
																$db->sql_escape($topic_poster),
																$topic_time,
																$db->sql_escape($topic_first_poster_name),
																$topic_first_poster_colour, 
																$db->sql_escape($topic_poster), 
																$db->sql_escape($topic_last_poster_name),
																$topic_last_poster_colour, 
																$db->sql_escape($topic_title),
																$topic_time,
																$topic_time
																);
							
							//printf("%s<br />", $sql); exit;
							$db->sql_query($sql);
							$topic_id = $db->sql_nextid();
		
							// update bug forum_id only if bug is new!
							// not needed?
							//$sql = sprintf("UPDATE bugs SET forum_id = %lu WHERE bug_id = %lu", $_POST['forum_id'], $_GET['id']);
							//printf("%s<br />", $sql);
							//$db2->sql_query($sql); // login DB
						}
		
						// details
						$sql = sprintf("SELECT * FROM bugs WHERE bug_id = %lu", $_GET['id']);
						//printf("%s<br />", $sql);
						$row = $db2->sql_fetchrow($db2->sql_query($sql));
						
						if( $row['bug_id'] == 0 )
							die("You trying to get banned?");
		
						$reassign = ( $existing ) ? "[size=120:2syjpbvs]([color=#FF0000:2syjpbvs][b:2syjpbvs]Re-assigned[/b:2syjpbvs][/color:2syjpbvs])[/size:2syjpbvs]" : "";

						// header
						$post_text .= sprintf("\n[pre:2syjpbvs][b:2syjpbvs][color=#0000BF:2syjpbvs]Bug ID[/color:2syjpbvs]       : %s[/b:2syjpbvs] - [url=http&#58;//vgoemulator&#46;net/index.php?p=bugs&id=%s:2syjpbvs]%s[/url:2syjpbvs] %s\n", $_GET['id'], $_GET['id'], $_POST['summary'], $reassign);
						// date					
						$post_text .= sprintf("[b:2syjpbvs][color=#0000BF:2syjpbvs]Bug Date[/color:2syjpbvs]     :[/b:2syjpbvs] %s\n", date('Y/m/d h:i:s', $row['createdate']));
						// assigned
						$post_text .= sprintf("[b:2syjpbvs]%s[/color:2syjpbvs]:[/b:2syjpbvs] %s\n", ( $existing ) ? "[color=#FF0000:2syjpbvs]Reassigned To" : "[color=#0000BF:2syjpbvs]Assigned To  ", ( $row['assigned_to_forum_id'] > 0 ) ? LookupForumUser($row['assigned_to_forum_id']) : LookupForumUser($_POST['assigned_to']));
						// priority
						$post_text .= sprintf("[b:2syjpbvs][color=#0000BF:2syjpbvs]Priority[/color:2syjpbvs]     :[/b:2syjpbvs] %s\n", GetPriorityName($row['priority']));
						
						// category
						$post_text .= sprintf("\n[b:2syjpbvs][color=#BF0000:2syjpbvs]Category[/color:2syjpbvs]     :[/b:2syjpbvs] %s\n", $row['category']);
						// subcategory
						$post_text .= sprintf("[b:2syjpbvs][color=#BF0000:2syjpbvs]Sub-Category[/color:2syjpbvs] :[/b:2syjpbvs] %s\n", $bug_cat[$row['category']][$row['sub_id']+1]);
						// crash
						$post_text .= sprintf("[b:2syjpbvs][color=#BF0000:2syjpbvs]Severity[/color:2syjpbvs]     :[/b:2syjpbvs] %s\n", $bug_severity[$row['sev_id']]);
						// reproducible
						$post_text .= sprintf("[b:2syjpbvs][color=#BF0000:2syjpbvs]Reproducible[/color:2syjpbvs] :[/b:2syjpbvs] %s[/pre:2syjpbvs]", $bug_reproducible[$row['rep_id']]); // no LF, pre adds the extra line
						// Details
						$post_text .= sprintf("\n[size=120:2syjpbvs][b:2syjpbvs]Details:[/b:2syjpbvs][/size:2syjpbvs]\n%s\n\n", $row['description']);

						if( $_POST['source'] == 1 ) { // forum
							$post_text .= sprintf("[pre:2syjpbvs][b:2syjpbvs][color=#008000:2syjpbvs]Originated From Forum[/color:2syjpbvs]:[/b:2syjpbvs] via BugTracker[/pre:2syjpbvs]\n");
						} else { // world
						
							$post_text .= sprintf("[pre:2syjpbvs][b:2syjpbvs][color=#008000:2syjpbvs]Originated From World[/color:2syjpbvs]:[/b:2syjpbvs] %s &#40;%s&#41;\n", GetWorld($row['server_id']), $row['server_id']);
							
							if( $row['chunk_id'] > 0 ) {
								$post_text .= sprintf("[b:2syjpbvs][color=#008000:2syjpbvs]Chunk[/color:2syjpbvs][/b:2syjpbvs]                : %s &#40;%s&#41;\n", GetChunkNameByID($row['chunk_id']), $row['chunk_id']);
								$post_text .= sprintf("[b:2syjpbvs][color=#008000:2syjpbvs]Location[/color:2syjpbvs][/b:2syjpbvs]             : %s %s %s\n", $row['loc_x'], $row['loc_y'], $row['loc_z']);
							}
							
							if( $row['entity_id'] > 0 )
								$post_text .= sprintf("[b:2syjpbvs][color=#008000:2syjpbvs]Entity[/color:2syjpbvs][/b:2syjpbvs]               : %s &#40;%s&#41;\n", GetEntityNameByID($row['entity_id']), $row['entity_id']);
								
							$post_text .= "[/pre:2syjpbvs]\n"; // close out World origin
							
							// Get Dev Notes
							$sql2 = sprintf("SELECT * FROM bug_notes WHERE bug_id = %lu ORDER BY note_date", $_GET['id']);
							//printf("%s<br />", $sql);
							$result2 = $db2->sql_query($sql2);
							
							// there must be bug notes
							while($note = $db2->sql_fetchrow($result2)) {
								$post_text .= sprintf("\n\n[b:2syjpbvs]Entered on %s by %s[/b:2syjpbvs]", date("M d, Y h:i", $note['note_date']), $note['author']);
								$post_text .= sprintf("\n%s", $note['note']);
							}
							
						}
					
						// insert new post, get new post ID
						$sql = sprintf("INSERT INTO phpbb3_posts (
															topic_id,
															forum_id,
															icon_id,
															poster_id,
															poster_ip,
															post_time,
															post_subject,
															post_text,
															bbcode_uid,
															bbcode_bitfield,
															enable_sig
															) VALUES (
															%lu,
															%lu,
															%d,
															%lu,
															'%s',
															%lu,
															'%s',
															'%s',
															'2syjpbvs',
															'VgE==',
															0)",
															$topic_id,
															$forum_id,
															$icon_id,
															$db->sql_escape($topic_poster),
															$_SERVER['REMOTE_ADDR'],
															$topic_time,
															$db->sql_escape($topic_title),
															$db->sql_escape($post_text));
						
						//printf("%s<br />", $sql); exit;
						$db->sql_query($sql);
						$new_post_id = $db->sql_nextid();
						
						// update topic with new post ID
						$topic_first_post_id = ( $topic_first_post_id ) ? $topic_first_post_id : $new_post_id;
						$sql = sprintf("UPDATE phpbb3_topics SET topic_first_post_id = %lu, topic_last_post_id = %lu WHERE topic_id = %lu", $topic_first_post_id, $new_post_id, $topic_id);
						//printf("%s<br />", $sql);
						$db->sql_query($sql);
			
						// update forum with new topic info
						$sql = sprintf("UPDATE phpbb3_forums SET 
															forum_posts = forum_posts + 1, 
															forum_topics = forum_topics + 1, 
															forum_topics_real = forum_topics_real + 1, 
															forum_last_post_id = %lu, 
															forum_last_poster_id = %lu, 
															forum_last_post_subject = '%s', 
															forum_last_post_time = %lu, 
															forum_last_poster_name = '%s', 
															forum_last_poster_colour = '%s'
														WHERE forum_id = %lu", 
														$new_post_id,
														$db->sql_escape($topic_poster),
														$db->sql_escape($topic_title),
														$topic_time,
														$db->sql_escape($topic_last_poster_name),
														$topic_last_poster_colour,
														$forum_id);
						//printf("%s<br />", $sql);
						$db->sql_query($sql);
						
						// *NEW* finally, log post_id to the bugs table for tracking
						$query = sprintf("UPDATE bugs SET post_id = %lu WHERE bug_id = %lu", $new_post_id, $_POST['orig_id']);
						$db2->sql_query($query);

					} // end if forum_post
				} // end if assigned_to
	
				break;
				
			case "Set Status":
				$query = sprintf("UPDATE bugs SET Status = '%s', updatedate = %lu WHERE bug_id = %lu", $_POST['bug_status'], time(), $_POST['orig_id']);
				if( !$result = $db2->sql_query($query) )
				{
					$error = $db2->sql_error();
					die($error['message']);
				}
				$log_array['log_type'] 			= 'Admin';
				$log_array['log_operation'] = 'BUG_MANAGER_UPDATE_STATUS';
				$log_array['log_data']			= sprintf("i:%s;u:%s;n:%s;q:%s", $_POST['orig_id'], GetMyName(), $_POST['bug_status'], $db2->sql_escape($query));
				log_action( $log_array );
				break;
				
			case "Add Note":
				// TODO: Append Dev Note to existing thread, if exists. If not, do not append.
				
				if( strlen($_POST['note']) > 3 ) {
					$query = sprintf("INSERT INTO bug_notes (bug_id, note, author, note_date) VALUES (%lu, '%s', '%s', %lu);", 
						$_POST['orig_id'], addslashes($_POST['note']), $_POST['author'], time());
					if( !$result = $db2->sql_query($query) )
					{
						$error = $db2->sql_error();
						die($error['message']);
					}
	
					$log_array['log_type'] 			= 'Admin';
					$log_array['log_operation'] = 'BUG_MANAGER_ADD_NOTE';
					$log_array['log_data']			= sprintf("i:%s;u:%s;q:%s", $_POST['orig_id'], $_POST['author'], $db2->sql_escape($query));
					log_action( $log_array );
	
					$query = sprintf("UPDATE bugs SET updatedate = %lu WHERE bug_id = %lu", time(), $_POST['orig_id']);
					if( !$result = $db2->sql_query($query) )
					{
						$error = $db2->sql_error();
						die($error['message']);
					}
				} else {
					die("Notes must be longer than 3 characters.<br /><a href='javascript:history.back(1)'>&lt;&lt; Back</a>");
				}
				break;
		}
	} // end if(cmd)

	// reload bug+details
	$query = sprintf("SELECT * FROM bugs WHERE bug_id = %lu LIMIT 0, 1", $_GET['id']);
	$data = $db2->sql_fetchrow($db2->sql_query($query));	
	$RowColor = ( isset($_POST['row_color']) ) ? $_POST['row_color'] : '#eeeeee'; 
	$priority_icon = ( $data['priority'] ) ? GetPriorityIcon($data['priority']) : "";
	$fix_summary = ( strlen($data['summary']) < 2 ) ? sprintf("%s...", substr($data['description'], 0, 30)) : $data['summary']; // if Summary is blank (usually is, doesn't come from Client) sub description text in
	?>
	<script language="javascript">
	<!-- 
	function CheckSummary() {
		var str = document.getElementById("summary").value;
		var n = str.length;
		if( n > 0 ) {
			document.getElementById("assign").disabled = false;
		} else {
			document.getElementById("assign").disabled = true;
		}
	}
	-->
	</script>
	<div style="box-shadow: 5px 5px 5px #888888; background-color:#eee;margin-top:10px;">
	<form method="post" name="bug|<?php print($data['bug_id']) ?>">
	<table width="100%" border="0" cellspacing="0" cellpadding="4" class="bg1">
		<tr>
			<td colspan="5" align="center" class="ps_category">Bug ID: <?php print($data['bug_id']) ?></td>
		</tr>
		<tr class="bg3" height="20">
			<td width="125"><strong>bug_datetime</strong></td>
			<td width="100"><strong>status</strong></td>
			<td width="100"><strong>category</strong></td>
			<td width="150"><strong>subcategory</strong></td>
			<td width="350"><strong>summary</strong></td>
		</tr>
		<tr height="25" class="bg2">
			<td nowrap><?= ( $data['createdate'] > 0 ) ? date('Y/m/d H:i:s', $data['createdate']) : "N/A" ?></td>
			<td nowrap><?php echo $data['Status'] ?></td>
			<td nowrap><?php echo $data['category'] ?></td>
			<td nowrap><?php echo $bug_cat[$data['category']][$data['sub_id']+1] ?></td>
			<td nowrap><input type="text" name="summary" value="<?php echo $fix_summary ?>" style="width:90%; font-size:9px;" id="summary" onkeyup="CheckSummary();" /></td>
		</tr>
		<tr>
			<td class="bg2" valign="top" colspan="5">
				<table width="100%" border="0" cellspacing="0" cellpadding="4">
					<tr height="50" valign="middle">
						<td align="center">&nbsp;
							<input type="button" value="Back" onclick="javascript:window.open('<?= $Link ?>', target='_self');" style="width:90px; font-size:11px; margin-bottom:5px;" />
							<input type="button" value="Reload" onclick="javascript:window.open('<?= $Link ?>&id=<?= $data['bug_id'] ?>', target='_self');" style="width:90px; font-size:11px; margin-bottom:5px;" />
							<?
							if( $is_admin)
							{
							?>
							<input type="submit" name="cmd" value="Set Status" style="width:90px; font-size:11px;" />
							<select name="bug_status" style="width:100px; font-size:11px; vertical-align:absmiddle;" id="status" >
								<option<?php if( $data['Status']==="New" ) print(" selected") ?>>New</option>
								<option<?php if( $data['Status']==="Assigned" ) print(" selected") ?>>Assigned</option>
								<option<?php if( $data['Status']==="Fixed" ) print(" selected") ?>>Fixed</option>
								<option<?php if( $data['Status']==="Need Info" ) print(" selected") ?>>Need Info</option>
								<option<?php if( $data['Status']==="Not Implemented" ) print(" selected") ?>>Not Implemented</option>
								<option<?php if( $data['Status']==="Not a Bug" ) print(" selected") ?>>Not a Bug</option>
								<option<?php if( $data['Status']==="Cannot Reproduce" ) print(" selected") ?>>Cannot Reproduce</option>
								<option<?php if( $data['Status']==="Duplicate" ) print(" selected") ?>>Duplicate</option>
								<option<?php if( $data['Status']==="Closed" ) print(" selected") ?>>Closed</option>
							</select>
							<?
							}
							?>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</div>
	<br />
	<div style="box-shadow: 5px 5px 5px #888888; background-color:#eee;margin-top:10px;">
	<table width="100%" border="0" cellspacing="0" cellpadding="4" class="bg1">
		<tr>
			<td colspan="4" class="forabg" align="center"><span style="color:#eee; font-size:13px; font-weight:bold; padding:3px 0px 3px 0px;">Bug Details</span></td>
		</tr>
		<tr>
			<td width="35%" rowspan="7" valign="top" class="bg2">
				<span style="font-size:10px; font-weight:bold">Other Bugs From Submitter</span>
				<br />
				<br />
				<? ListOtherBugsFromSubmitter($data, $data['bug_id']) ?>
			</td>
			<td colspan="3" class="bg2" style="width:450px; height:80px; border-left:1px solid #789; vertical-align:top; padding-left:3px;"><strong>Details:</strong>
				<br />
				<br />
				<?php echo $data['description'] ?>
				<br />&nbsp;
			</td>
		</tr>
		<?php if( $is_admin ) { // account row ?>
		<tr height="30" style="font-size:11px;" valign="top">
			<?php if( $data['char_id'] > 0 ) { ?>
			<td style="border-left:1px solid #789; vertical-align:top; padding-left:3px;"><strong>account:</strong><br /><?php echo $data['account_id'] ?></td>
			<td style="vertical-align:top; padding-left:3px;"><strong>char_id:</strong><br /><?php echo $data['char_id'] ?></td>
			<td style="vertical-align:top; padding-left:3px;"><strong>character:</strong><br /><?php echo GetCharacterName($data['server_id'], $data['char_id']) ?></td>
			<?php } else { ?>
			<td colspan="3" style="border-left:1px solid #789; vertical-align:top; padding-left:3px;"><strong>forum user:</strong><br /><?php echo $data['forum_username'] ?></td>
			<?php } ?>
		</tr>
		<? } // end account row ?>
		<tr height="30" style="font-size:11px;">
			<td style="border-left:1px solid #789; vertical-align:top; padding-left:3px;"><strong>server_id:</strong><br /><?php echo ( $data['server_id'] > 0 ) ? $data['server_id'] : GetWorldIDByName($data['server_name']) ?></td>
			<td colspan="2" style="vertical-align:top; padding-left:3px;"><strong>server name:</strong><br /><?php echo GetWorld($data['server_id']) ?></td>
		</tr>
		<?php if( $data['char_id'] > 0 ) { // this means it was submitted from In-Game, so there will be chunk data ?>
		<tr height="30" style="font-size:11px;">
			<td style="border-left:1px solid #789; vertical-align:top; padding-left:3px;"><strong>chunk:</strong><br /><?php echo GetChunkNameByID($data['chunk_id']) ?> (<?php echo $data['chunk_id'] ?>)</td>
			<td style="vertical-align:top; padding-left:3px;" colspan="2"><strong>location:</strong><br /><?php echo $data['loc_x'] ?> <?php echo $data['loc_y'] ?> <?php echo $data['loc_z'] ?></td>
		</tr>
		<?php } // end in-game bug ?>
		<tr height="30" style="font-size:11px;">
			<td style="border-left:1px solid #789; vertical-align:top; padding-left:3px;"><strong>severity:</strong><br /><?php echo $bug_severity[$data['sev_id']] ?></td>
			<td style="vertical-align:top; padding-left:3px;"><strong>reproduce:</strong><br /><?php echo $bug_reproducible[$data['rep_id']] ?></td>
			<td width="125" style="vertical-align:top; padding-left:3px;"><strong>updated:</strong><br /><?= ( $data['updatedate'] > 0 ) ? date('Y/m/d H:i:s', $data['updatedate']) : "Never" ?></td>
		</tr>
		<tr height="30" class="bg3" style="font-size:11px;">
			<td colspan="3" valign="top">
				<table width="100%" border="0" cellspacing="0" cellpadding="4" style="border-left:1px solid #789; border-top:1px solid #789; border-bottom:1px solid #789">
					<tr>
						<td style="padding-left:3px;"><strong>assigned to:</strong></td>
						<td style="border-left:1px solid #999; padding-left:3px;"><strong>Type:</strong></td>
						<td style="border-left:1px solid #999; padding-left:3px;"><strong>Priority:</strong></td>
						<td style="border-left:1px solid #999; padding-left:3px;"><strong>Fixed By:</strong></td>
					</tr>
					<?php if( $is_admin ) { ?>
					<tr height="30">
						<td style="border-bottom:1px solid #999; padding-left:2px;">
							<select name="assigned_to" style="width:125px; font-size:11px; margin-bottom:6px;">
							<option value="0">Unassigned</option>
							<?= GetAssigned($data['assign_to_forum_id']) ?>
							</select>
						</td>
						<td style="border-left:1px solid #999; border-bottom:1px solid #999; padding-left:2px;">
							<select name="forum_id" style="width:100px; font-size:11px; margin-bottom:6px;">
								<option value="22"<?php if( $data['forum_id']==22 ) print(" selected") ?>>Server Bug</option>
								<option value="23"<?php if( $data['forum_id']==23 ) print(" selected") ?>>Content Bug</option>
								<option value="24"<?php if( $data['forum_id']==24 ) print(" selected") ?>>Tools Bug</option>
							</select>
						</td>
						<td style="border-left:1px solid #999; border-bottom:1px solid #999; padding-left:2px;">
							<select name="priority" style="width:100px; font-size:11px; margin-bottom:6px;">
								<option value="1"<?php if( $data['priority']==1 || $data['priority']==0 ) print(" selected") ?>>Low</option>
								<option value="2"<?php if( $data['priority']==2 ) print(" selected") ?>>Medium</option>
								<option value="3"<?php if( $data['priority']==3 ) print(" selected") ?>>High</option>
								<option value="4"<?php if( $data['priority']==4 ) print(" selected") ?>>Critical</option>
								<option value="5"<?php if( $data['priority']==5 ) print(" selected") ?>>Immediate</option>
							</select>
						 &nbsp;<?= $priority_icon ?>
						</td>
						<td style="border-left:1px solid #999; padding-left:2px;">
							<select name="fixed_by_forum_id" style="width:120px; font-size:11px; margin-bottom:6px;">
							<option value="0">---</option>
							<?= GetAssigned($data['fixed_by_forum_id']) ?>
							</select>
						</td>
					</tr>
					<?php } else { ?>
					<tr height="30">
						<td style="border-bottom:1px solid #999; padding-left:2px;"><? print( ( $data['assign_to_forum_id'] ) ? LookupForumUser($data['assign_to_forum_id']) : "Unassigned"); ?></td>
						<td style="border-left:1px solid #999; border-bottom:1px solid #999; padding-left:2px;"><? print( ( $data['forum_id']==22 ) ? "Server Bug" : "Content Bug"); ?></td>
						<td style="border-left:1px solid #999; border-bottom:1px solid #999; padding-left:2px;"><?= $priority_icon ?></td>
						<td style="border-left:1px solid #999; padding-left:2px;"><? print( ( $data['fixed_by_forum_id'] ) ? LookupForumUser($data['fixed_by_forum_id']) : "Unassigned"); ?></td>
					</tr>
					<?php } ?>
          
					<? if( $is_admin ) { ?>
					<tr>
						<td colspan="3" height="30">
							<input type="submit" name="cmd" value="Assign" style="width:90px; font-size:10px; margin-left:50px;" id="assign" disabled="disabled" title="If disabled, add summary text" />&nbsp;
							<?
							if( $data['post_id'] > 0 ) {
								printf('&nbsp;<strong>Topic ID:</strong> <a href="/phpBB3/viewtopic.php?p=%lu#p%lu" target="_blank">%lu', $data['post_id'], $data['post_id'], $data['post_id']);
								print('<input type="hidden" name="forum_post" value="1" />'); // if there's already a post ID, then forum_post must equal something
							} else {
								print('<input type="checkbox" name="forum_post" value="1" />&nbsp;Create Forum Topic');
							}
							?>
						</td>
						<td style="text-align:center; border-left:1px solid #999; padding-left:2px;">
							<input type="submit" name="cmd" value="Fixed" style="width:90px; font-size:10px" />
						</td>
					</tr>
					<? } // end post/fixed summary ?>
					<script>CheckSummary()</script>
				</table>
			</td>
		</tr>
		<tr>
			<td colspan="3" valign="top" width="200">
				<table width="100%"border="0" cellspacing="0" cellpadding="4" style="border-left:1px solid #789; border-bottom:1px solid #789">
					<tr>
						<td class="ps_category" align="center">Dev Notes</td>
					</tr>
					<tr>
						<td style="padding:10px 0px 10px 5px;"><? DisplayBugNotes($data['bug_id']) ?></td>
					</tr>
					<? if( $is_admin ) { ?>
					<tr>
						<td height="50" valign="top">&nbsp;
							<textarea name="note" style="font-size:12px; width:97%; height:50px; background-color:#999; color:#FFF"></textarea><br />
							<div align="center"><input type="submit" name="cmd" value="Add Note" style="width:90px; font-size:10px" /></div>
						</td>
					</tr>
					<? } // end input dev note ?>
					<tr>
						<td>&nbsp;</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</div>
	<input type="hidden" name="author" value="<?= GetMyName() ?>">
	<input type="hidden" name="orig_id" value="<?php echo $data['bug_id'] ?>">
	<input type="hidden" name="source" value="<?php echo $data['source'] ?>">
	</form>
<?php

}

/* 
 * Note: Do not need to define LS database in queries since $db2 is aimed at that SQL server/database
 */

/*
	Function: GetServersWithBugs
	Purpose	: 
*/
function GetServersWithBugs($server_id)
{
	global $db2;

	$query = sprintf("SELECT DISTINCT server_id, server_name FROM bugs ORDER BY server_name");

	$result = $db2->sql_query($query);
	while( $data = $db2->sql_fetchrow($result) )
		$options .= sprintf('<option value="%s"%s>%s</option>', $data['server_id'], ( $data['server_id'] == $server_id ) ? " selected" : "", $data['server_name']);
	
	return $options;
}


/*
	Function: GetActiveBugCategories
	Purpose	: 
*/
function GetActiveBugCategories($category)
{
	global $db2;

	$query = sprintf("SELECT DISTINCT category FROM bugs ORDER BY category");

	if( !$result = $db2->sql_query($query) )
	{
		$error = $db2->sql_error();
		die($error['message']);
	}
	else
	{
		while( $data = $db2->sql_fetchrow($result) )
		{
			$selected = ( $data['category'] === $category) ? " selected" : "";
			$ret .= sprintf('<option%s>%s</option>', $selected, $data['category']);
		}
		
		return $ret;
	}	
}


/*
	Function: GetActiveBugSubCategories
	Note		: Since VGClient uses sub_id 0, and 0 cannot be used in a combobox (anymore?)
					: sub_id is VGClient ID + 1. Do the math.
*/
function GetActiveBugSubCategories($subcategory)
{
	global $db2, $bug_cat;

	$query = sprintf("SELECT DISTINCT sub_id + 1 AS sub_id FROM bugs WHERE category = 'VGClient' ORDER BY sub_id");

	if( !$result = $db2->sql_query($query) )
	{
		$error = $db2->sql_error();
		die($error['message']);
	}
	else
	{
		while( $data = $db2->sql_fetchrow($result) )
		{
			//printf("Sub: %s, Data: %s<br />", $subcategory, $data['sub_id']);
			
			$selected = ( $data['sub_id'] === $subcategory) ? " selected" : "";
			$ret .= sprintf('<option value="%s"%s>%s</option>', $data['sub_id'], $selected, $bug_cat['VGClient'][$data['sub_id']]);
		}
		
		return $ret;
	}	
}


/*
	Function: GetActiveBugClientVersions
	Purpose	: 
*/
function GetActiveBugClientVersions($val = 0)
{
	global $db2;
	
	return sprintf('<option%s>%s</option>', $val == 1 ? " selected" : "", 1); //there is only 1 client version in VGOEmu
	
	/*$query = sprintf('SELECT DISTINCT MID(`version`, INSTR(`version`, "=")+1, 4) as client_version FROM bugs WHERE LENGTH(`version`) > 0 ORDER BY `version`');

	if( !$result = $db2->sql_query($query) )
	{
		$error = $db2->sql_error();
		die($error['message']);
	}
	else
	{
		while( $data = $db2->sql_fetchrow($result) )
			printf('<option%s>%s</option>', $data['client_version'] == $val ? " selected" : "", $data['client_version']);
	}*/	
}


/*
	Function: GetServersWithBugs
	Purpose	: 
*/
function GetBugAuthors($submitted_by)
{
	global $db2;

	$query = sprintf("SELECT DISTINCT account_id, char_id, c.char_firstname, forum_username, source FROM bugs b LEFT JOIN ls_characters c ON b.char_id = c.server_char_id_fk WHERE server_id = 1 ORDER BY LOWER(char_firstname), LOWER(forum_username)");

	if( !$result = $db2->sql_query($query) )
	{
		$error = $db2->sql_error();
		die($error['message']);
	}
	else
	{
		while( $data = $db2->sql_fetchrow($result) )
		{
			if( $data['source'] == 1 ) // forum submitted bug, handle differently
				$ret .= sprintf('<option%s>%s</option>', ( $data['forum_username'] === $submitted_by ) ? " selected" : "", $data['forum_username']);
			else
				$ret .= sprintf('<option%s>%s</option>', ( $data['char_firstname'] === $submitted_by ) ? " selected" : "", $data['char_firstname']);
		}
		
		return $ret;
	}	
}


/*
	Function: GetAssigned
	Purpose	: Builds a list of options of those forum members on a development team
*/
function GetAssigned($id)
{
	global $db;
	
	$query = sprintf("SELECT DISTINCT u.user_id, u.username
										FROM phpbb3_users u, phpbb3_user_group ug, phpbb3_groups g
										WHERE 
											u.user_id = ug.user_id AND 
											ug.group_id = g.group_id AND
											group_name IN ('Developers', 'Content Designers', 'Team Members')
										ORDER BY LOWER(u.username) ");

	if( !$result = $db->sql_query($query) )
	{
		$error = $db->sql_error();
		die($error['message']);
	}
	else
	{
		while( $data = $db->sql_fetchrow($result) )
		{
			$selected = ( $data['user_id'] === $id) ? " selected" : "";
			$ret .= sprintf('<option value="%lu"%s>%s</option>', $data['user_id'], $selected, $data['username']);
		}
		
		return $ret;
	}	
}


/*
	Function: GetActiveAssigned
	Purpose	: Builds a list of options of those forum members with bugs assigned to them
*/
function GetActiveAssigned($id)
{
	global $db, $db2;
	
	// after splitting MySQL games from web databases, cannot JOIN across servers :( - refactoring
																																									
	// first, fetch vgo_login.bugs assignees
	if( !$result = $db2->sql_query("SELECT DISTINCT assign_to_forum_id AS id FROM vgo_login.bugs") ) {
		$error = $db2->sql_error();
		die($error['message']);
	} else {
		
		while( $rows = $db2->sql_fetchrow($result) ) {
			$id_list[] = $rows['id'];
		}
		
		if( is_array($id_list) ) {
			// now that we know who has bugs assigned to them, we'll go to the Forum database and get the user info
			$query2 = "SELECT DISTINCT " .
								"	u.user_id, u.username " .
								"FROM " .
								"	phpbb3_users u, phpbb3_user_group ug, phpbb3_groups g " .
								"WHERE u.user_id IN (".implode(",",$id_list).") " .
								"	AND u.user_id = ug.user_id " .
								"	AND ug.group_id = g.group_id " .
								"	AND group_name IN ( " .
								"		'Developers', 'Content Designers', 'Team Members' " .
								"	) " .
								"ORDER BY LOWER(u.username);";
			
			if( !$result = $db->sql_query($query2) ) {
				$error = $db->sql_error();
				die($error['message']);
			} else {
				while( $data = $db->sql_fetchrow($result) ) {
					$selected = ( $data['user_id'] === $id) ? " selected" : "";
					$ret .= sprintf('<option value="%lu"%s>%s</option>', $data['user_id'], $selected, $data['username']);
				}
			}
		}
		
		return $ret;
	}	
	
	
	$query = "SELECT DISTINCT " .
						"	u.user_id, u.username " .
						"FROM " .
						"	vgo_login.bugs b, phpbb3_users u, phpbb3_user_group ug, phpbb3_groups g " .
						"WHERE b.assign_to_forum_id = u.user_id " .
						"	AND u.user_id = ug.user_id " .
						"	AND ug.group_id = g.group_id " .
						"	AND group_name IN ( " .
						"		'Developers', 'Content Designers', 'Team Members' " .
						"	) " .
						"ORDER BY LOWER(u.username);";

	if( !$result = $db->sql_query($query) )
	{
		$error = $db->sql_error();
		die($error['message']);
	}
	else
	{
		while( $data = $db->sql_fetchrow($result) )
		{
			$selected = ( $data['user_id'] === $id) ? " selected" : "";
			$ret .= sprintf('<option value="%lu"%s>%s</option>', $data['user_id'], $selected, $data['username']);
		}
		
		return $ret;
	}	
}


/*
	Function: GetAssigned
	Purpose	: Builds a list of options of those forum members on a development team
*/
function GetFixedBy($id)
{
	global $db;
	
	$query = sprintf("SELECT DISTINCT user_id, username
										FROM phpbb3_users
										ORDER BY username");

	if( !$result = $db->sql_query($query) )
	{
		$error = $db->sql_error();
		die($error['message']);
	}
	else
	{
		while( $data = $db->sql_fetchrow($result) )
		{
			$selected = ( $data['user_id'] === $id) ? " selected" : "";
			printf('<option value="%lu"%s>%s</option>', $data['user_id'], $selected, $data['username']);
		}
	}	
}


/*
	Function: GetServersWithBugs
	Purpose	: 
*/
function CheckHasBugNotes($bug_id) {
	global $db2;
	
	$query = sprintf("select count(*) as cnt from bug_notes where bug_id = %lu;", $bug_id);
	$result = $db2->sql_query($query);
	$data = $db2->sql_fetchrow($result);
	return ( $data['cnt'] ) ? 1 : 0;
}


function DisplayBugNotes($id) {
	global $db2;
	
	$query = sprintf("SELECT * FROM bug_notes WHERE bug_id = %lu ORDER BY note_date;", $id);
	$result = $db2->sql_query($query);
	while($data = $db2->sql_fetchrow($result)) {
		printf('<strong>Entered on %s by %s</strong><br />%s<br />', date('M d, Y H:m',$data['note_date']), $data['author'], $data['note']);
	}
	
}


function ListOtherBugsFromSubmitter($data, $current_bug) {
	global $db2, $Link;
	
	if( $data['source'] == 1 )
		$query = sprintf("SELECT bug_id, summary as description FROM bugs WHERE forum_username = '%s';", $data['forum_username']);
	else
		$query = sprintf("SELECT bug_id, description FROM bugs WHERE char_id = '%s';", $data['char_id']);
	
	$result = $db2->sql_query($query);
	
	while($data = $db2->sql_fetchrow($result)) {
		$description = ( strlen($data['description']) > 45 ) ? substr($data['description'], 0, 45) . '...' : $data['description'];
		$selected = ( $data['bug_id'] == $current_bug ) ? " style=\"text-decoration:underline;\"" : " style=\"text-decoration:none;\"";
		printf('<a href="%s&id=%lu" target="_self"%s>%lu. %s</a><br /><br />', $Link, $data['bug_id'], $selected, $data['bug_id'], $description);
	}
	
}


function LookupForumUser($id) {
	global $db;
	
	if( $id == 0 )
		return "Unassigned";
		
	$query = sprintf("SELECT username FROM phpbb3_users WHERE user_id = %s", $id);
	$result = $db->sql_query($query);
	$data = $db->sql_fetchrow();
	
	return ( count($data) > 0 ) ? $data['username'] : "Unassigned";
}	


function GetChunkNameByID($chunk_id) {
	global $db2;

	// read chunk data from New Telon world database
	$query = sprintf("SELECT displayName FROM vgo_world.chunks WHERE chunk_id = %s", $chunk_id);
	$data=$db2->sql_fetchrow($db2->sql_query($query));
	return ( isset($data) ) ? $data['displayName'] : $chunk_id;
}	


function GetEntityNameByID($id) {
	global $db2;
	
	$query="SELECT spawn_name FROM vgo_world.spawn WHERE spawn_id = $id";
	$result=$db2->sql_query($query);
	$data=$db2->sql_fetchrow($result);
	return ( isset($data) ) ? $data['spawn_name'] : "Not Found.";
}	


function GetPriorityName($priority) {
	switch($priority)
	{
		case 5:
			$ret = 'Immediate';
			break;
		case 4:
			$ret = 'Critical';
			break;
		case 3:
			$ret = 'High';
			break;
		case 2:
			$ret = 'Medium';
			break;
		case 1:
			$ret = 'Low';
			break;
	}
	return $ret;
}

function GetPriorityIcon($priority)
{
	switch($priority)
	{
		case 5:
			$ret = '<img src="/phpBB3/images/icons/misc/immediate.png" border="0" width="16" title="Immediate" />';
			break;
		case 4:
			$ret = '<img src="/phpBB3/images/icons/misc/critical.png" border="0" width="16" title="Critical" />';
			break;
		case 3:
			$ret = '<img src="/phpBB3/images/icons/misc/high.png" border="0" width="16" title="High" />';
			break;
		case 2:
			$ret = '<img src="/phpBB3/images/icons/misc/medium.png" border="0" width="16" title="Medium" />';
			break;
		case 1:
			$ret = '<img src="/phpBB3/images/icons/misc/low.png" border="0" width="16" title="Low" />';
			break;
		default:
			$ret = '';
			break;
	}
	return $ret;
}


function GetRecentActiveServer()
{
	global $db2;

	load_configs( "serverlist" );

	if( !defined(MAX_HISTORY_LENGTH) && !defined(MAX_HISTORY_INTERVAL) )
	{
		switch(MAX_HISTORY_INTERVAL)
		{
			case "minutes":
				$max_age = MAX_HISTORY_LENGTH * 60; // how many seconds back in time to go based on X minutes
				break;
			case "hours":
				$max_age = MAX_HISTORY_LENGTH * 60 * 60; // how many seconds back in time to go based on X hours
				break;
			case "days":
				$max_age = MAX_HISTORY_LENGTH * 24 * 60 * 60; // how many seconds back in time to go based on X days
				break;
			case "weeks":
				$max_age = MAX_HISTORY_LENGTH * 7 * 24 * 60 * 60; // how many seconds back in time to go based on X weeks
				break;
			case "months":
				$max_age = MAX_HISTORY_LENGTH * 30 * 24 * 60 * 60; // how many seconds back in time to go based on X months (30 days)
				break;
			case "quarters":
				$max_age = MAX_HISTORY_LENGTH * 90 * 24 * 60 * 60; // how many seconds back in time to go based on X quarters (90 days)
				break;
			case "years":
				$max_age = MAX_HISTORY_LENGTH * 365 * 24 * 60 * 60; // how many seconds back in time to go based on X months (365 days)
				break;
		}
	}
	
	$sql = sprintf("SELECT server_id, server_name FROM ls_server_accounts WHERE server_lastseen >= UNIX_TIMESTAMP(CURRENT_TIMESTAMP) - %s ORDER BY server_name", $max_age);
	//print($sql);
	
	$result = $db2->sql_query($sql);
	while( $row = $db2->sql_fetchrow($result) )
	{
		$data[] = $row;
	}
	
	return ( is_array($data) ) ? $data : "No Worlds Found.";
}

function GetChunks()
{
	global $db2;

	$sql = "SELECT chunk_id, shortname FROM vgo_world.chunks ORDER BY shortname";

	$result = $db2->sql_query($sql);
	while( $row = $db2->sql_fetchrow($result) )
	{
		$data[] = $row;
	}
	
	return ( is_array($data) ) ? $data : "No Zones Found.";
	
}

function GetCharacterName($world_id, $char_id) {
	global $db2;
	
	$sql = sprintf("SELECT char_firstname FROM ls_characters WHERE server_id_fk = %s AND server_char_id_fk = %s;", $world_id, $char_id);

	$data = $db2->sql_fetchrow($db2->sql_query($sql));
	return ( strlen($data['char_firstname']) > 0 ) ? $data['char_firstname'] : "Unknown.";
	
}


?>
