<?php
if( !defined("IN_PORTAL") )
	die("Hacking attempt.");
?>

<div id="section">
	<ul>
		<li class="section-title">EQ2Emulator Source  (Git)</li>
	</ul>
</div>
<div class="post bg1">
	<div class="inner">
		<div class="postbody">
			<div class="content">
				<p> If you are using a Windows-based operating system, a GUI subversion client such as <a href="http://tortoisesvn.tigris.org" onclick="window.open(this.href);return false;" class="postlink">TortoiseSVN</a> or <a href="https://desktop.github.com/" onclick="window.open(this.href);return false;" class="postlink">GitHub Desktop</a> is helpful to retrieve the source code. 
					You may also point a web browser to the repo URL and see the latest revisions, download, view issues and more.</p>
				<p>If your OS is Linux-based, you can install Git package for your OS, if not already installed, and retrieve the latest code with a simple command line:</p>
				<dl class="codebox">
					<dt>Current Code: <a href="#" onclick="selectCode(this); return false;">Select all</a></dt>
					<dd><code style="font-size:1.3em;">git clone http://git.eq2emu.com:3000/devn00b/EQ2EMu.git</code></dd>
				</dl>
				<p>&nbsp;</p>
				
				<dl class="codebox">
					<dt>Alt Code Address: <a href="#" onclick="selectCode(this); return false;">Select all</a></dt>
					<dd><code style="font-size:1.3em;">git clone http://cutpon.com:3000/devn00b/EQ2EMu.git</code></dd>
				</dl>
				<p>&nbsp;</p>

				<dl class="codebox">
					<dt>Rewrite Code: <a href="#" onclick="selectCode(this); return false;">Select all</a></dt>
					<dd><code style="font-size:1.3em;">git clone https://github.com/Jabantiz/EQ2Emulator-Rewrite.git</code></dd>
				</dl>
				<p>&nbsp;</p>
				<h3>Content SVN</h3>
				<br />
				<p>
				<ul>
					<li style="font-size:1.3em;">Scripts: <a href="https://github.com/EQ2Emulator-net/scripts" target="_blank">https://github.com/EQ2Emulator-net/scripts</a></li>

<p>&nbsp;</p>

<li style="font-size:1.3em;">Database: <a href="https://github.com/EQ2Emulator-net/database-full-backup" target="_blank">https://github.com/EQ2Emulator-net/database-full-backup</a></li>
				</ul>
				</p>
				<p>&nbsp;</p>
				<h3>EQ2Emulator Tools</h3>
				<br />
				<p>
				<ul>
					<li style="font-size:1.3em;">Tools: <a href="https://github.com/EQ2Emulator-net/tools-eq2emu" target="_blank">https://github.com/EQ2Emulator-net/tools-eq2emu</a></li>
				</ul>
				</p>
				<p>&nbsp;</p>
				<p>See the <a href="http://eq2emulator.net/wiki/index.php/Admins:Server_Setup_Guide" target="_blank">Server Admins Guide</a> for more information on compiling and setting up your own server. </p>
				<p>&nbsp;</p>
			</div>
		</div>
	</div>
</div>
<?php if( $MOD->is_dev ) { ?>
<div id="section">
	<ul>
		<li class="section-title">Private SVN Information</li>
	</ul>
</div>
<div class="post bg1">
	<div class="inner">
		<div class="postbody">
			<div class="content">
				<p> Private SVN is for Developers only. Do not give out your login information for any reason. Code committed here gets synchronized to the Public SVN (and mirror) weekly - so be sure to thoroughly test your code before committing.</p>
				<p>Developers of Content and Tools have read-write access to the Public Content and Tools SVNs, and should commit content or tools only to those SVN Repositories.</p>
				<p>Private SVN Username and Password have been sent to you via PM</p>
				<p>&nbsp;</p>
				<h3>Developer SVNs</h3>
				<br />
				<p>
				<ul>
					<li style="font-size:1.3em;">Server Code: <a href="https://svn.eq2emulator.net/svn/EQ2" target="_blank">https://svn.eq2emulator.net/svn/EQ2</a></li>
					<li style="font-size:1.3em;">Logs (private): <a href="https://svn.eq2emulator.net/svn/eq2logs" target="_blank">https://svn.eq2emulator.net/svn/eq2logs</a></li>
				</ul>
				</p>
			</div>
		</div>
	</div>
</div>
<?php } ?>
