<?php
if( !defined("IN_PORTAL") )
	die("Hacking attempt.");

/* This seems to be required HERE for every module to be affected - how is this possible? */
error_reporting(E_ALL & ~E_NOTICE ^ E_STRICT);
//print_r($config);
//printf("<p>%s</p>", $phpbb_root_path);

// instantiate Portal class
include_once(PORTAL_ROOT_PATH . "classes/mod.common.php");
$MOD = new MODCls();
include_once(PORTAL_ROOT_PATH."classes/mod.widget.php");			// include Widget class globally
$WGT = new MODWidget();
?>
<!DOCTYPE html>
<html dir="ltr" lang="en-gb">
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="description" content="The Official EQ2Emulator Project. The efforts and goal of EQ2 Emulator are to emulate the Everquest 2 experience as close as possible to the actual live game by SoE/DBG/Darkpaw Games." />
<title>EQ2emulator.net</title>
<link rel="alternate" type="application/atom+xml" title="Feed - " href="<?php print( $phpbb_root_path ) ?>app.php/feed?sid=<?php print($user->data['session_id']) ?>">
<link rel="alternate" type="application/atom+xml" title="Feed - News" href="<?php print( $phpbb_root_path ) ?>app.php/feed/news?sid=<?php print($user->data['session_id']) ?>">
<link rel="alternate" type="application/atom+xml" title="Feed - All forums" href="<?php print( $phpbb_root_path ) ?>app.php/feed/forums?sid=<?php print($user->data['session_id']) ?>">
<link rel="alternate" type="application/atom+xml" title="Feed - New Topics" href="<?php print( $phpbb_root_path ) ?>app.php/feed/topics?sid=<?php print($user->data['session_id']) ?>">
<link rel="alternate" type="application/atom+xml" title="Feed - Active Topics" href="<?php print( $phpbb_root_path ) ?>app.php/feed/topics_active?sid=<?php print($user->data['session_id']) ?>">
<!--
	phpBB style name: prosilver
	Based on style:   prosilver (this is the default phpBB3 style)
	Original author:  Tom Beddard ( http://www.subBlue.com/ )
	Modified by:
-->
<link href="<?php print( $phpbb_root_path ) ?>assets/css/font-awesome.min.css?assets_version=17" rel="stylesheet">
<link href="<?php print( $phpbb_root_path ) ?>styles/se_square_left/theme/stylesheet.css?assets_version=17" rel="stylesheet">
<link href="<?php print( $phpbb_root_path ) ?>styles/se_square_left/theme/en/stylesheet.css?assets_version=17" rel="stylesheet">
<link href="<?php print( PORTAL_RELATIVE_PATH ) ?>css/portal.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="<?php print( PORTAL_RELATIVE_PATH ) ?>js/eq2portal.js"></script>
<!--[if lte IE 9]>
	<link href="./styles/se_square_left/theme/tweaks.css?assets_version=17" rel="stylesheet">
<![endif]-->
<link href="<?php print( $phpbb_root_path ); ?>ext/phpbb/boardannouncements/styles/all/theme/boardannouncements.css?assets_version=17" rel="stylesheet" type="text/css" media="screen" />

<script src="https://cdn.tailwindcss.com">
</script>
</head>
<body id="phpbb" class="nojs notouch section-index ltr ">
<div id="wrap" class="wrap">
<a id="top" class="top-anchor" accesskey="t"></a>
	<div id="page-header">
		<div class="headerbar" role="banner">
			<div class="inner">
				<div id="site-description" class="site-description"> <a id="logo" class="logo" href="index.php" title="Board index"><span class="site_logo"></span></a>
					<h1></h1>
					<p></p>
					<p class="skiplink"><a href="#start_here">Skip to content</a></p>
				</div>
				<div id="search-box" class="search-box search-header" role="search"></div>
			</div>
		</div>

                            
	<?php
                  include_once(PORTAL_ROOT_PATH."common/navbar.php");
              ?>

	<a id="start_here" class="anchor"></a>
	<div id="page-body" class="page-body" role="main">
	<?php if( $config['board_announcements_enable'] == 1 ) { ?>
	<div id="phpbb_announcement" style="background-color:#990000">
		<div><span style="color: #FFFFFF">The EQ2Emulator Portal and it's modules are currently unavailable, undergoing a full rewrite due to changes in PHPBB 3.2+ architecture.<br />
			Watch the <a href="http://eq2emulator.net/phpBB3/viewforum.php?f=2"><span style="color:#FF0">Announcements Forum</span></a> for details.</span></div>
	</div>
	<?php } ?>
