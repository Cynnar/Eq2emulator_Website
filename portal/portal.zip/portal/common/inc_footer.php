	</div><!-- End: page-body -->
	<div id="page-footer" class="page-footer" role="contentinfo">
		<?php if( intval($_SESSION['modules']['config']['debug']) === 1 && $MOD->is_admin ) { ?>
		<div style="background-color:#20354c; color:#ccc;"><h2><span style="color:#ccc;">DEBUG Data:</span></h2><br />
		<?php $MOD->DisplayDebug(); ?>
		</div>
		<?php } ?>
		<div class="navbar" role="navigation">
			<div class="inner">
				<ul id="nav-footer" class="nav-footer linklist" role="menubar">
					<li class="breadcrumbs"> <span class="crumb"><a href="/index.php" data-navbar-reference="index"><i class="icon fa-home fa-fw" aria-hidden="true"></i><span>Portal index</span></a></span> </li>
					<li class="rightside">All times are <span title="UTC-7">UTC-07:00</span></li>
					<li class="rightside"> <a href="<?php print( $phpbb_root_path ); ?>ucp.php?mode=delete_cookies&sid=<?php print($user->data['session_id']) ?>" data-ajax="true" data-refresh="true" role="menuitem"> <i class="icon fa-trash fa-fw" aria-hidden="true"></i><span>Delete all board cookies</span> </a> </li>
					<li class="rightside" data-last-responsive="true"> <a href="<?php print( $phpbb_root_path ); ?>memberlist.php?sid=<?php print($user->data['session_id']) ?>" title="View complete list of members" role="menuitem"> <i class="icon fa-group fa-fw" aria-hidden="true"></i><span>Members</span> </a> </li>
					<li class="rightside" data-last-responsive="true"> <a href="<?php print( $phpbb_root_path ); ?>memberlist.php?mode=team&sid=<?php print($user->data['session_id']) ?>" role="menuitem"> <i class="icon fa-shield fa-fw" aria-hidden="true"></i><span>The team</span> </a> </li>
				</ul>
			</div>
		</div>
		<div class="copyright"> Powered by <a href="https://www.phpbb.com/">phpBB</a>&reg; Forum Software &copy; phpBB Limited | SE Square Left by <a href="http://www.phpbb3bbcodes.com/">PhpBB3 BBCodes</a> <br />
			<strong><a href="<?php print( $phpbb_root_path ); ?>adm/index.php?sid=<?php print($user->data['session_id']) ?>">Administration Control Panel</a></strong>
		</div>
		<?php /*?>insert portal debug messages here <?php */?>
	</div>
</div>
<div> <a id="bottom" class="anchor" accesskey="z"></a></div>
<script type="text/javascript" src="<?php print( $phpbb_root_path ); ?>assets/javascript/jquery.min.js?assets_version=19"></script>
<script type="text/javascript" src="<?php print( $phpbb_root_path ); ?>assets/javascript/core.js?assets_version=19"></script>
<script type="text/javascript" src="<?php print( $phpbb_root_path ); ?>ext/phpbb/boardannouncements/styles/all/template/js/boardannouncements.js?assets_version=19"></script>
<script type="text/javascript" src="<?php print( $phpbb_root_path ); ?>styles/prosilver/template/forum_fn.js?assets_version=19"></script>
<script type="text/javascript" src="<?php print( $phpbb_root_path ); ?>styles/prosilver/template/ajax.js?assets_version=19"></script>
</body>
</html>
