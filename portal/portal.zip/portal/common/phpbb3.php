<?php
define('IN_PHPBB', true);
session_start();
$phpbb_root_path = './phpBB3/';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);
include($phpbb_root_path . 'includes/functions_display.' . $phpEx);
include($phpbb_root_path . 'includes/message_parser.' . $phpEx);
$request->enable_super_globals();									// just turn this shit off, ffs...
// Start session management
$user->session_begin();
$auth->acl($user->data);
$user->setup();
?>

