<div class="navbar" role="navigation">

    <div class="inner">

        <ul id="nav-main" class="nav-main linklist" role="menubar">

            <li id="quick-links" class="quick-links dropdown-container responsive-menu" data-skip-responsive="true">

                <a href="#" class="dropdown-trigger"> <i class="icon fa-bars fa-fw" aria-hidden="true"></i><span>Quick links</span> </a>

                <div class="dropdown">

                    <div class="pointer">
                        <div class="pointer-inner"></div>
                    </div>

                    <ul class="dropdown-contents" role="menu">
                        <li class="separator"></li>
                        <li> <a href="<?php print( $phpbb_root_path ); ?>search.php?search_id=egosearch" role="menuitem"> <i class="icon fa-file-o fa-fw icon-gray" aria-hidden="true"></i><span>Your posts</span> </a> </li>
                        <li> <a href="<?php print( $phpbb_root_path ); ?>search.php?search_id=newposts" role="menuitem"> <i class="icon fa-file-o fa-fw icon-red" aria-hidden="true"></i><span>New posts</span> </a> </li>
                        <li> <a href="<?php print( $phpbb_root_path ); ?>search.php?search_id=unreadposts" role="menuitem"> <i class="icon fa-file-o fa-fw icon-red" aria-hidden="true"></i><span>Unread posts</span> </a> </li>
                        <li> <a href="<?php print( $phpbb_root_path ); ?>search.php?search_id=unanswered" role="menuitem"> <i class="icon fa-file-o fa-fw icon-gray" aria-hidden="true"></i><span>Unanswered topics</span> </a> </li>
                        <li> <a href="<?php print( $phpbb_root_path ); ?>search.php?search_id=active_topics" role="menuitem"> <i class="icon fa-file-o fa-fw icon-blue" aria-hidden="true"></i><span>Active topics</span> </a> </li>
                        <li class="separator"></li>
                        <li> <a href="<?php print( $phpbb_root_path ); ?>search.php" role="menuitem"> <i class="icon fa-search fa-fw" aria-hidden="true"></i><span>Search</span> </a> </li>
                        <li class="separator"></li>
                        <li> <a href="<?php print( $phpbb_root_path ); ?>memberlist.php" role="menuitem"> <i class="icon fa-group fa-fw" aria-hidden="true"></i><span>Members</span> </a> </li>
                        <li> <a href="<?php print( $phpbb_root_path ); ?>memberlist.php?mode=team" role="menuitem"> <i class="icon fa-shield fa-fw" aria-hidden="true"></i><span>The team</span> </a> </li>
                        <li class="separator"></li>
                    </ul>

                </div>
            </li>

            <li data-last-responsive="true"> <a href="<?php print( $phpbb_root_path ); ?>index.php" title="Go to Community Forums" role="menuitem"> <i class="icon fa-users fa-fw" aria-hidden="true"></i><span>Forums</span> </a> </li>
            <li data-last-responsive="true"> <a href="/wiki/index.php" title="EQ2Emulator Wiki" role="menuitem"> <i class="icon fa-info fa-fw" aria-hidden="true"></i><span>Wiki</span> </a> </li>
            <li data-last-responsive="true"> <a href="index.php?p=projman" title="Project Manager" role="menuitem"> <i class="icon fa-tasks fa-fw" aria-hidden="true"></i><span>Project Manager</span> </a> </li>
            <li data-last-responsive="true"> <a href="index.php?p=bugs" title="Bug Tracker" role="menuitem"> <i class="icon fa-gavel fa-fw" aria-hidden="true"></i><span>Bug Tracker</span> </a> </li>
            <li data-last-responsive="true"> <a href="index.php?p=git" title="Source Code" role="menuitem"> <i class="icon fa-folder-open fa-fw" aria-hidden="true"></i><span>Source Code</span> </a> </li>

            <?php if( $user->data['user_id'] > 1 ) { ?>

            <li id="username_logged_in" class="rightside  no-bulletin" data-skip-responsive="true">

            <div class="header-profile dropdown-container">
                <a href="<?php print( $phpbb_root_path ); ?>ucp.php?sid=<?php print($user->data['session_id']) ?>" class="header-avatar dropdown-trigger"> <span style="color: <?php print($user->data['user_color']) ?>;" class="username-coloured"><?php print($user->data['username']) ?></span></a>

                <!-- <a href="<?php print( $phpbb_root_path ); ?>ucp.php?sid=<?php print($user->data['session_id']) ?>" class="header-avatar dropdown-trigger"><img class="avatar" src="<?php print( $phpbb_root_path ); ?>download/file.php?avatar=<?php print($user->data['user_avatar']) ?>" width="100" height="100" alt="User avatar" /> <span style="color: <?php print($user->data['user_color']) ?>;" class="username-coloured"><?php print($user->data['username']) ?></span></a> -->

                <div class="dropdown">

                    <ul class="dropdown-contents" role="menu">

                        <li> <a href="<?php print( $phpbb_root_path ); ?>ucp.php?sid=<?php print($user->data['session_id']) ?>" title="User Control Panel" role="menuitem"> <i class="icon fa-sliders fa-fw" aria-hidden="true"></i><span>User Control Panel</span> </a> </li>
                        <li> <a href="<?php print( $phpbb_root_path ); ?>memberlist.php?mode=viewprofile&amp;u=16&sid=<?php print($user->data['session_id']) ?>" title="Profile" role="menuitem"> <i class="icon fa-user fa-fw" aria-hidden="true"></i><span>Profile</span> </a> </li>
                        <li class="separator"></li>
                        <li> <a href="<?php print( $phpbb_root_path ); ?>ucp.php?mode=logout&sid=<?php print($user->data['session_id']) ?>" title="Logout" accesskey="x" role="menuitem"> <i class="icon fa-power-off fa-fw" aria-hidden="true"></i><span>Logout</span> </a> </li>

                    </ul>

                </div>

            </div>
        </li>

        <?php } else { ?>

        <li class="rightside" data-skip-responsive="true"> <a href="<?php print( $phpbb_root_path ); ?>ucp.php?mode=login" title="Login" accesskey="x" role="menuitem"> <i class="icon fa-power-off fa-fw" aria-hidden="true"></i> <span>Login</span> </a> </li>
        <li class="rightside" data-skip-responsive="true"> <a href="<?php print( $phpbb_root_path ); ?>ucp.php?mode=register" role="menuitem"> <i class="icon fa-pencil-square-o  fa-fw" aria-hidden="true"></i> <span>Register</span> </a> </li>

        <?php } ?>

        <!-- <li class="rightside" data-skip-responsive="true"> <a href="index.php?p=account" role="menuitem" title="Account Manager"> <i class="icon fa-user fa-fw" aria-hidden="true"></i><span>Accounts</span></a> </li> -->

        <!-- <li class="rightside" data-skip-responsive="true"> <a href="index.php?p=servers" title="Server List" role="menuitem"> <i class="icon fa-list fa-fw" aria-hidden="true"></i><span>Server List</span> </a> </li> -->

    </ul>

    <ul id="nav-breadcrumbs" class="nav-breadcrumbs linklist navlinks" role="menubar">

        <li class="breadcrumbs"> <span class="crumb" itemtype="http://data-vocabulary.org/Breadcrumb" itemscope=""><a href="index.php" itemprop="url" accesskey="h" data-navbar-reference="index"><i class="icon fa-home fa-fw"></i><span itemprop="title">Portal index</span></a></span>

            <?php
                switch($MOD->Page) {
                    case "servers": 
            ?>

            <span class="crumb" itemtype="http://data-vocabulary.org/Breadcrumb" itemscope=""><a href="index.php?p=servers" itemprop="url"><span itemprop="title">Server List</span></a></span>

            <?php
                if( intval($_GET['id']) > 0 ) {
            ?>

            <span class="crumb" itemtype="http://data-vocabulary.org/Breadcrumb" itemscope=""><a href="index.php?p=servers&id=<?php print( $_GET['id'] ) ?>" itemprop="url"><span itemprop="title" id="server-list-server-name">server-name</span></a></span>

            <?php
                }
                default:
                    break;
                }
            ?>

        </li>

        <li class="rightside responsive-search"></li>

        </ul>

        </div>

    </div>

</div>