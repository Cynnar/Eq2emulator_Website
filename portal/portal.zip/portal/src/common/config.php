<?php
if( !defined("IN_PORTAL") )
	die("Hacking attempt.");

date_default_timezone_set('America/Phoenix');

/**
 * TODO: Set up multiple connections?
 * phpBB - for forum user/group queries -may not need this if we switch to editor ACL
 * portal - the __portal datbase
 * login - loginservers
 * patch - patchservers
 * world - worldservers (these last 3 should always be on the same mysql isntance)
 * editor - DB editor, if needed for patching (TBD)
 *
 * Design: All DB configs need to become a table in __portal DB so there is only 1 actual config needed here?
 **/

$i=0;
// Define default database $GLOBALS - NEVER display this data in DEBUG unless user_role & 16  (admin)
$_SESSION['modules']['database'][$i]['id'] 		 		= $i;
$_SESSION['modules']['database'][$i]['db_display_name']	= 'EQ2Modules';
$_SESSION['modules']['database'][$i]['db_name'] 		= 'eq2emuweb_portal';
$_SESSION['modules']['database'][$i]['db_host'] 		= 'localhost';
$_SESSION['modules']['database'][$i]['db_port'] 		= '3306';
$_SESSION['modules']['database'][$i]['db_user'] 		= 'eq2emuweb';
$_SESSION['modules']['database'][$i]['db_pass'] 		= 'oBteHJs5y5';
$_SESSION['modules']['database'][$i]['db_charset'] 		= 'utf8';
$_SESSION['modules']['database'][$i]['db_description']	= 'Required DB for EQ2Modules';
$_SESSION['modules']['database'][$i]['db_world_id']		= 0;
$_SESSION['modules']['database'][$i]['is_active']		= 0;

// ALTERNATE database config(s) here
$i++;
$_SESSION['modules']['database'][$i]['id'] 		 		= $i;
$_SESSION['modules']['database'][$i]['db_display_name']	= 'EQ2Servers';
$_SESSION['modules']['database'][$i]['db_name'] 		= 'eq2ls';
$_SESSION['modules']['database'][$i]['db_host'] 		= 'eq2emulator.us.to';
$_SESSION['modules']['database'][$i]['db_port'] 		= '3306';
$_SESSION['modules']['database'][$i]['db_user'] 		= 'eq2portal@ccess';
$_SESSION['modules']['database'][$i]['db_pass'] 		= 'ZBV69vRI1DWcyqah097KhvNV742GFzJaFx59y';
$_SESSION['modules']['database'][$i]['db_charset'] 		= 'utf8';
$_SESSION['modules']['database'][$i]['db_description']	= 'Required DB for EQ2Servers';
$_SESSION['modules']['database'][$i]['db_world_id']		= 1;
$_SESSION['modules']['database'][$i]['is_active']		= 1;
?>
