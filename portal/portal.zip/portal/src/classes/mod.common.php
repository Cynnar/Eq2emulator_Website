<?php
error_reporting(E_ERROR | E_PARSE);
if( !defined("IN_PORTAL") )
	die("Hacking attempt.");

if(!defined("MODCLS_LAYER")) {
define("MODCLS_LAYER","MODCls");


/**
 * TODOs
 */
class MODCls {
	
	// public properties
	public $ObjectName		= NULL;
	public $TableName		= NULL;
	public $SQLQuery		= NULL;
	public $AffectedRows	= NULL;
	public $LastInsertID	= NULL;

	public $DebugGeneral	= NULL;
	public $DebugData		= NULL;
	public $DebugFunctions	= NULL;
	public $DebugForms		= NULL;
	public $DebugQueries	= NULL;

	public $PHPBBTablePrefix = "phpbb3_";	// phpBB integration

	/** 
	 * Access privileges by group assignment in phpBB.
	 */
	public $is_team			= false; // Team Members
	public $is_dev			= false; // Developers (who are also Team Members)
	public $is_dba			= false; // DB Admins (who are also Team Members)
	public $is_admin		= false; // phpBB3 ADMINISTRATORS, who should be in all groups
	
	
	// private properties
	private $max_cache_time	= 5; 			// # of seconds until cache expires
	private $LogArray		= array();

	//
	// Constructor
	//
	public function __construct() {
		global $db, $user;
		
		$this->db = $db; // bring forward the phpBB DB connection
		
		// Load `settings` table into session cache
		$this->LoadConfig();
		//print_r($_SESSION['modules']['privileges']);
		
		// data needed for SQL logging
		$this->ObjectID 	= ( strlen($_POST['object_id']) > 0 ) ? $_POST['object_id'] : $_GET['id'];
		$this->TableName 	= $_POST['table_name'];

		// set the current script name
		$this->Script 		= $this->GetPHPScriptName();
		// do navigation vars here
		$this->Page 		= ( strlen($_GET['p']) > 0 ) ? $_GET['p'] : "";
		$this->Tab  		= ( strlen($_GET['t']) > 0 ) ? $_GET['t'] : "";
		$this->Link 		= sprintf("%s?%s", $this->Script, $_SERVER['QUERY_STRING']);
		$this->FullPage		= ( strlen($this->Page) > 0 ) ? sprintf("%s?p=%s", $this->Script, $this->Page) : sprintf("%s", $this->Script);
		
		// double check, but privileges should get cached in LoadConfig now
		if( count($_SESSION['modules']['privileges']) > 0 ) {
			$this->is_admin = $_SESSION['modules']['privileges']['is_admin'];
			$this->is_dev 	= $_SESSION['modules']['privileges']['is_dev'];
			$this->is_team	= $_SESSION['modules']['privileges']['is_team'];
			$this->is_dba	= $_SESSION['modules']['privileges']['is_dba'];
		}
		
		// add form debugging
		$this->AddDebugForm($_POST);
	}
	
	public function _halt() {
		die('<h2>Access Denied</h2>Team membership required.');
	}

	public function _enable_errors($enable) {
		if( $enable === true ) {
			error_reporting(E_ALL & ~E_NOTICE ^ E_STRICT);
		} else {
			error_reporting(~E_ALL); // hah I have no idea
		}
	}


	/*
		Function: LoadConfig()
		Purpose	: Function call to database to get *portal.settings records and store in Session cache
		Syntax	: $MOD->LoadConfig()
		Note	: Cache times out and gets reloaded according to $this->max_cache_time
	*/
	private function LoadConfig() 
	{
		if( count($_SESSION['modules']['config']) == 0 || $_SESSION['modules']['config']['cachetime'] <= (time() - $this->max_cache_time) ) {
			unset($_SESSION['modules']['config']); // clear previous values
			$this->SQLQuery = "SELECT config_name, config_value FROM " . PORTAL_DATABASE . ".settings";
			$configs = $this->RunQueryMulti();
	
			if( is_array($configs) ) {
				$_SESSION['modules']['config']['cachetime'] = time();
				foreach($configs as $config) {
					$_SESSION['modules']['config'][$config['config_name']] = $config['config_value'];
					if( $_SESSION['modules']['config']['debug_data'] ) {
						$this->AddDebugData($config['config_name'], $_SESSION['modules']['config'][$config['config_name']]);
					}
				}
				
				$this->AddDebugGeneral('Config', sprintf('Config refreshed (time: %s)', date('Y-m-d h:i:s', $_SESSION['modules']['config']['cachetime'])));
			}
			
			// now cache the forum privileges
			$_SESSION['modules']['privileges']['is_admin']	= $this->CheckAccess("ADMINISTRATORS");
			$_SESSION['modules']['privileges']['is_dev'] 	= $this->CheckAccess("Developers");
			$_SESSION['modules']['privileges']['is_team']	= $this->CheckAccess("Team Members");
			$_SESSION['modules']['privileges']['is_dba']	= $this->CheckAccess("DB Editors");
			
		} else {
			$this->AddDebugGeneral('Config', sprintf('Config cached (time: %s)', date('Y-m-d h:i:s', $_SESSION['modules']['config']['cachetime'])));
		}
		
		$this->AddDebugGeneral('Config', sprintf('Max Cached (time: %s)', $this->max_cache_time));
		$this->AddDebugGeneral('Config', sprintf('Est cache refresh @ %s', date('Y-m-d h:i:s', $_SESSION['modules']['config']['cachetime'] + $this->max_cache_time)));
	}


	// TODO: add these to cache
	private function CheckAccess($phpbb_group) {
		global $user;
		
		$this->SQLQuery = sprintf("SELECT COUNT(*) AS is_member " .
								  "FROM " . $this->PHPBBTablePrefix . "users u, " . $this->PHPBBTablePrefix . "user_group ug, " . $this->PHPBBTablePrefix . "groups g " .
								  "WHERE " .
								  "  u.user_id = ug.user_id AND " .
								  "  ug.group_id = g.group_id AND " .
								  "  group_name IN ('%s') AND " .
								  "  u.user_id = %s " .
								  "ORDER BY u.username " .
								  "LIMIT 0,1", $phpbb_group, $user->data['user_id']);
		
		$data = $this->RunQuerySingle();
		return ( $data['is_member'] == 1 ) ? true : false;
	}


	
	/*
		Log functions
	*/
	
	/**
	 * Log is the replacement logger for portal mods for tracking log_array() stuff
	 * Needs access to PORTAL_DATABASE!
	 */
	public function Log( $log_array ) {
		global $user;
		
		if( $_SESSION['modules']['config']['module_log'] == 0 ) {
			// logging disabled in settings
			return;
		}
		
		$log_array['forum_user_id']	= $user->data['user_id'];
		$log_array['log_time']		= time();
		$log_array['log_ip']		= $this->SQLEscape($_SERVER['REMOTE_ADDR']);
	
		/*if( !empty($status) ) { // I was going to save Status data, but never implemented it
			foreach( $status as $key => $val )
				$data['log_data'] .= sprintf("%s:%s", $key, $this->SQLEscape($val));
		}*/
	
		foreach( $log_array as $key => $val ) {
			if( empty($fields) )
				$fields .= $key;
			else
				$fields .= ", " . $key;
	
			if( empty($values) )
				$values .= "'" . $val;
			else
				$values .= "', '" . $val;
		}
		$values .= "'";
		
		$this->SQLQuery = sprintf("INSERT INTO " . PORTAL_DATABASE . ".logs (%s) VALUES (%s);", $fields, $values);
		$this->LogQuery();
	}
	


	/*
		Function: AccessDenied()
		Purpose	: Default Access Denied messaging and page-die
		Syntax	: $MOD->AccessDenied()
	*/
	public function AccessDenied($msg = '') {
		if( strlen($msg) > 0 )
			die('<div id="Grid"><p class="warning">'.$msg.'</p></div>');
		else
			die('<div id="Grid"><p class="warning">Access Denied!</p></div>');
	}


	public function GetPHPScriptName()
	{
		$tmp = explode("/", $_SERVER['SCRIPT_NAME']);
		$this->AddDebugGeneral("ScriptName", $tmp[count($tmp)-1]);
		return $tmp[count($tmp)-1];
	}


	/****************************************************************************
	 * General UI and Debugging
	 ****************************************************************************/
	 
	/**
	 *	@brief Function Trace Debugging
	 *	@detail Traces function enter/exit and timing
	 *	@syntax $MOD( FunctionName, Start|Stop )
	 *	@notes see also: $_SERVER["REQUEST_TIME_FLOAT"] @ 
	 *	@notes http://php.net/manual/en/function.microtime.php
	 *	@notes Example #3 microtime() and REQUEST_TIME_FLOAT (as of PHP 5.4.0)
	 *	@author John Adams, Jan 24 2018
	 */
	public function Trace( $function, $var )
	{
		// if we're not debugging, bail out
		if( intval($_SESSION['modules']['config']['debug_func']) === 1 ) 
		{
			switch( $var ) 
			{
				case "start":
					$this->AddDebugFunction( $function, " trace starting...");
					$this->start_time = microtime(true);
					break;
					
				case "stop": 
					$this->AddDebugFunction( $function, " trace ending...");
					$elapsed = microtime(true) - $this->start_time;
					$this->AddDebugFunction( $function, " elapsed time: " . $elapsed);
					break;
			}
		}
	}
	
	
	public function GetBacktrace()
	{
		$output = '<div style="font-family: monospace; font-size:25px;">';
		$backtrace = debug_backtrace();
		
		// We skip the first one, because it only shows this file/function
		unset($backtrace[0]);
		
		foreach ($backtrace as $trace)
		{
			// Strip the current directory from path
			$trace['file'] = (empty($trace['file'])) ? '(not given by php)' : htmlspecialchars($trace['file']);
			$trace['line'] = (empty($trace['line'])) ? '(not given by php)' : $trace['line'];
		
			// Only show function arguments for include etc.
			// Other parameters may contain sensible information
			$argument = '';
			if (!empty($trace['args'][0]) && in_array($trace['function'], array('include', 'require', 'include_once', 'require_once')))
			{
				$argument = htmlspecialchars($trace['args'][0]);
			}
		
			$trace['class'] = (!isset($trace['class'])) ? '' : $trace['class'];
			$trace['type'] = (!isset($trace['type'])) ? '' : $trace['type'];
		
			$output .= '<br />';
			$output .= '<b>FILE:</b> ' . $trace['file'] . '<br />';
			$output .= '<b>LINE:</b> ' . ((!empty($trace['line'])) ? $trace['line'] : '') . '<br />';
		
			$output .= '<b>CALL:</b> ' . htmlspecialchars($trace['class'] . $trace['type'] . $trace['function']);
			$output .= '(' . (($argument !== '') ? "'$argument'" : '') . ')<br />';
		}
		$output .= '</div>';
		return $output;
	}
	
	public function AddDebugGeneral($label, $var)
	{
		// if we're not debugging, bail out
		if( intval($_SESSION['modules']['config']['debug']) === 1 ) 
		{
			if( is_array($var) )
			{
				$this->DebugGeneral .= '<p>';
				foreach($var as $key=>$val)
					if( is_array($val) )
						foreach($val as $key2=>$val2)
							$this->DebugGeneral .= sprintf("&nbsp;&nbsp;<strong>array[%s]</strong>: %s = %s<br />", $name, $key2, $val2);
					else
						$this->DebugGeneral .= sprintf("&nbsp;&nbsp;<strong>array[%s]</strong>: %s = %s<br />", $name, $key, $val);
				$this->DebugGeneral .= '</p>';
			}
			else
				$this->DebugGeneral .= sprintf("<p>&nbsp;&nbsp;<strong>%s:</strong> %s</p>", $label, $var);
		}
	}
	
	public function AddDebugData($name, $var)
	{
		// if we're not debugging, bail out
		if( intval($_SESSION['modules']['config']['debug_data']) === 1 ) 
		{
			if( is_array($var) )
			{
				$this->DebugData .= '<p>';
				foreach($var as $key=>$val)
					if( is_array($val) )
						foreach($val as $key2=>$val2)
							$this->DebugData .= sprintf("&nbsp;&nbsp;<strong>array[%s]</strong>: %s = %s<br />", $name, $key2, $val2);
					else
						$this->DebugData .= sprintf("&nbsp;&nbsp;<strong>array[%s]</strong>: %s = %s<br />", $name, $key, $val);
				$this->DebugData .= '</p>';
			}
			else
				$this->DebugData .= sprintf("<p>%s = %s</p>", $name, $var);
		}
	}
	
	public function AddDebugFunction($func, $var)
	{
		// if we're not debugging, bail out
		if( intval($_SESSION['modules']['config']['debug_func']) === 1 ) 
		{
			$this->DebugFunctions .= sprintf("<p>&nbsp;&nbsp;<strong>function %s:</strong> %s</p>", $func, $var);
		}
	}
	
	public function AddDebugForm($arr)
	{
		// if we're not debugging, bail out
		if( intval($_SESSION['modules']['config']['debug_forms']) === 1 ) 
		{
			foreach($arr as $key=>$val)
			{
				if( is_array($val) )
					foreach($val as $value)
						$this->DebugForms .= sprintf("<p>&nbsp;&nbsp;ARRAY&nbsp;--&nbsp;<strong>%s:</strong> %s</p>", $key, $value);
				else
					$this->DebugForms .= sprintf("<p>&nbsp;&nbsp;<strong>%s:</strong> %s</p>", $key, $val);
			}
		}
	}

	
	public function AddDebugQuery( $function, $query )
	{
		// if we're not debugging, bail out
		if( intval($_SESSION['modules']['config']['debug_query']) === 1 ) 
		{
			$this->DebugQueries .= sprintf("<p>-- <strong>function %s:</strong><br />%s</p>", $function, $query);
		}
	}

	public function AddDebugQueryNew( $function, $type, $query, $rows, $elapsed )
	{
		// if we're not debugging, bail out
		if( intval($_SESSION['modules']['config']['debug_query']) === 1 ) 
		{
			$this->DebugQueries .= sprintf("<p>-- <strong>function %s:</strong>, type: %s<br />", $function, $type);
			$this->DebugQueries .= sprintf("%s<br />", $query);
			$this->DebugQueries .= sprintf("-- Affected Row(s) %s, Elapsed Time: %s</p>", $rows, $elapsed);
		}
	}

	public function AddStatus($var, $single = 0)
	{
		// only 1 status at a time?
		if( $single == 1 )
			$this->Status = sprintf("&nbsp;&nbsp;%s<br />", $var);
		else 
			$this->Status .= sprintf("&nbsp;&nbsp;%s<br />", $var);
	}

	public function DisplayDebug()
	{
		?>
		<table width="100%" class="debug">
			<tr height="30" valign="bottom">
				<td><strong>STATUS Data:</strong></td>
			</tr>
			<tr>
				<td><?= $this->Status ?></td>
			</tr>
			<?php if( $_SESSION['modules']['config']['debug'] ) { ?>
			<tr height="30" valign="bottom">
				<td><strong>DEBUG General:</strong></td>
			</tr>
			<tr>
				<td><?= $this->DebugGeneral ?></td>
			</tr>
			<?php } ?>
			<?php if( $_SESSION['modules']['config']['debug_func'] ) { ?>

			<tr height="30" valign="bottom">
				<td><strong>DEBUG Functions:</strong></td>
			</tr>
			<tr>
				<td><?= $this->DebugFunctions ?></td>
			</tr>
			<?php } ?>
			<?php if( $_SESSION['modules']['config']['debug_forms'] ) { ?>
			<tr height="30" valign="bottom">
				<td><strong>DEBUG Form Data:</strong></td>
			</tr>
			<tr>
				<td><?= $this->DebugForms ?></td>
			</tr>
			<?php } ?>
			<?php if( $_SESSION['modules']['config']['debug_query'] ) { ?>
			<tr height="30" valign="bottom">
				<td><strong>DEBUG Queries:</strong></td>
			</tr>
			<tr>
				<td><?= $this->DebugQueries ?></td>
			</tr>
			<?php } ?>
			<?php if( $_SESSION['modules']['config']['debug_data'] ) { ?>
			<tr height="30" valign="bottom">
				<td><strong>DEBUG Data:</strong></td>
			</tr>
			<tr>
				<td><?= $this->DebugData ?></td>
			</tr>
			<?php } ?>
		</table>
		<?php
	}

	public function DisplayStatus()
	{
		?>
		<table width="100%" class="warning">
			<tr>
				<td align="center"><strong>Status:</strong> <?= $this->Status ?></td>
			</tr>
		</table>
		<?php
	}
	

	/****************************************************************************
	 * SQL Database Functions
	 ****************************************************************************/
	public function DBError() {
		$error = $this->db->sql_error();
		?>
		<div id="error-box">
		<table cellspacing="0" align="center">
			<tr>
				<td colspan="2" class="title">SQL Error: <?php print($error['code']); ?></td>
			</tr>
			<tr>
				<td class="label">Message:</td>
				<td class="detail"><?php print($error['message']); ?></td>
			</tr>
			<tr>
				<td class="label">Trace:</td>
				<td class="detail">
					<?php 
					print($this->GetBacktrace());
					?>
				</td>
			</tr>
			<tr>
				<td class="label">Query:</td>
				<td><?php print($this->SQLQuery); ?></td>
			</tr>
		</table>
		</div>
		<?php 
		if( $_SESSION['modules']['config']['debug'] == 1 && $_SESSION['modules']['user']['id'] == 2 ) 
			$this->DisplayDebug();
		include("../common/footer.php");
		die();
	}

	/* SELECT: Use this RunQuery to return a single-row result set */
	public function RunQuerySingle($sql = '') {
		
		/*** Override $this with passed parameters ***/
		if( is_null($this->SQLQuery) && strlen($sql) > 6 )
			$this->SQLQuery = $sql;
		/**********************************************/
			
		// add ; to end of query, if missing, just for logging to screen
		if( strpos($this->SQLQuery, ";") == 0 )
			$this->SQLQuery = trim($this->SQLQuery) . ";";
			
		if( $_SESSION['modules']['config']['debug'] ) {
			$start_time = time();
			$this->AddDebugFunction(__FUNCTION__, "Enter");
			$this->AddDebugQuery(__FUNCTION__, $this->SQLQuery);
		}
		
		if( !$result = $this->db->sql_query($this->SQLQuery) ) {
			$this->DBError();
		} else {
			$num_rows = $this->db->sql_affectedrows($result);
			$rtn = $this->db->sql_fetchrow($result);
		}

		if( $_SESSION['modules']['config']['debug'] ) {
			$this->AddDebugData("RunQuerySingle", $rtn);
			$this->AddDebugFunction(__FUNCTION__, $num_rows." row(s)");
			if( $Elapsed > 1 )
				$Exit = sprintf("Exit - Elapsed: %s<br />Slow Query: %s", $Elapsed, $this->SQLQuery);
			else
				$Exit = "Exit";
			$this->AddDebugFunction(__FUNCTION__, $Exit);
		}

		unset($this->SQLQuery);  // nuke the query so it isn't used again
		
		return $rtn;
	}
	
	
	/* SELECT: Use this RunQuery to return a multiple-row result set */
	public function RunQueryMulti($sql = '') {
		
		/*** Override $this with passed parameters ***/
		if( is_null($this->SQLQuery) && strlen($sql) > 6 )
			$this->SQLQuery = $sql;
		/**********************************************/
			
		// add ; to end of query, if missing, just for logging to screen
		if( strpos($this->SQLQuery, ";") == 0 )
			$this->SQLQuery = trim($this->SQLQuery) . ";";
			
		if( $_SESSION['modules']['config']['debug'] ) {
			$start_time = time();
			$this->AddDebugFunction(__FUNCTION__, "Enter");
			$this->AddDebugQuery(__FUNCTION__, $this->SQLQuery);
		}
		
		if( !$result = $this->db->sql_query($this->SQLQuery) ) {
			$this->DBError();
		} else {
			$num_rows = $this->db->sql_affectedrows($result);
			while( $data = $this->db->sql_fetchrow($result) ) 
				$rtn[] = $data;
		}

		if( $_SESSION['modules']['config']['debug'] ) {
			$this->AddDebugData("RunQueryMulti Data", $rtn);
			$this->AddDebugFunction(__FUNCTION__, $num_rows." row(s)");
			$Elapsed = time() - $start_time;
			if( $Elapsed > 1 )
				$Exit = sprintf("Exit - Elapsed: %s<br />Slow Query: %s", $Elapsed, $this->SQLQuery);
			else
				$Exit = "Exit";
			$this->AddDebugFunction(__FUNCTION__, $Exit);
		}

		unset($this->SQLQuery);  // nuke the query so it isn't used again
		
		return $rtn;
	}
	

	public function RunQuery($sql = '') {
		$num_rows = 0;
		
		/*** Override $this with passed parameters ***/
		if( is_null($this->SQLQuery) && strlen($sql) > 6 )
			$this->SQLQuery = $sql;
		/**********************************************/

		// Check if SQLQuery has a valid query
		if( strlen($this->SQLQuery) === 0 )
			die("Invalid SQLQuery: '" . $this->SQLQuery . "'");
			
		// this should set the QueryType always
		$this->QueryType = substr($this->SQLQuery, 0, 6);
		
		// add ; to end of query, if missing, just for logging to screen
		if( strpos($this->SQLQuery, ";") == 0 )
			$this->SQLQuery = trim($this->SQLQuery) . ";";
			
		if( $_SESSION['modules']['config']['debug'] ) {
			$start_time = time();
			$this->AddDebugFunction(__FUNCTION__, "Enter");
			if( $_SESSION['modules']['config']['readonly'] )
				$this->AddDebugQuery(__FUNCTION__, "READ-ONLY: ".$this->SQLQuery);
			else
				$this->AddDebugQuery(__FUNCTION__, $this->SQLQuery);
		}
		
		switch($this->QueryType) {
			
			case "SELECT":
				if( !$result=$this->db->sql_query($this->SQLQuery) )
					$this->DBError();
				else {
					// temp: checking to see if I call RunQuery directly for any select statements
					die("Do not call RunQuery for Selects directly. Use RunQuerySingle, RunQueryMulti");
					$data = $this->db->sql_fetchrow($result);
				}
					
				break;
				
			case "INSERT":
			case "UPDATE":
			case "DELETE":
				if( $_SESSION['modules']['config']['readonly'] ) {
					$this->AddStatus("READ-ONLY MODE (".$this->QueryType.") - No data updated!");
				} else {
					if( !$result = $this->db->sql_query($this->SQLQuery) )
						$this->DBError();
					else {
						$num_rows = $this->db->sql_affectedrows($result);
						
						$this->AffectedRows = $num_rows;
						$this->AddDebugGeneral("Affected Rows", $this->AffectedRows);
						$this->LastInsertID = $this->db->sql_nextid();
						$this->AddDebugGeneral("Last Insert ID", $this->LastInsertID);
					}
				}
				break;
		}
		
		if( $_SESSION['modules']['config']['debug'] )
		{
			$this->AddDebugData("RunQuery Data", $data);
			$this->AddDebugFunction(__FUNCTION__, $num_rows." row(s)");
			if( $Elapsed > 1 ) // i don't think I'm calculating Elapsed?
				$Exit = sprintf("Exit - Elapsed: %s<br />Slow Query: %s", $Elapsed, $this->SQLQuery);
			else
				$Exit = "Exit";
			$this->AddDebugFunction(__FUNCTION__, $Exit);
		}
		
		unset($this->QueryType); // nuke the type so it isn't used again
		unset($this->SQLQuery);  // nuke the query so it isn't used again
		
		return $num_rows;
	}

	public function LogQuery() {
		
		// Check if SQLQuery has a valid query
		if( strlen($this->SQLQuery) === 0 )
			die("Invalid SQLQuery: '" . $this->SQLQuery . "'");
			
		// add ; to end of query, if missing, just for logging to screen
		if( strpos($this->SQLQuery, ";") == 0 )
			$this->SQLQuery = trim($this->SQLQuery) . ";";
			
		if( $_SESSION['modules']['config']['debug'] ) {
			$this->AddDebugFunction(__FUNCTION__, "Enter");
			if( $_SESSION['modules']['config']['readonly'] )
				$this->AddDebugQuery(__FUNCTION__, "READ-ONLY: ".$this->SQLQuery);
			else
				$this->AddDebugQuery(__FUNCTION__, $this->SQLQuery);
		}
		
		if( $_SESSION['modules']['config']['readonly'] ) {
			$this->AddStatus("READ-ONLY MODE (INSERT) - No data updated!");
		} else {
			if( !$result = $this->db->sql_query($this->SQLQuery) )
				$this->DBError();
			// no LastInserID or AffectedRows on Log inserts!
		}
		
		if( $_SESSION['modules']['config']['debug'] )
			$this->AddDebugFunction(__FUNCTION__, "Exit");
		
		unset($this->SQLQuery);  // nuke the query so it isn't used again
	}

	public function GetTotalRows($database, $table) 
	{
		global $vgo;

		$vgo->SQLQuery = sprintf("SELECT count(*) AS num FROM %s.%s;", $database, $table);
		$data = $vgo->RunQuerySingle();
		return ( !empty($data) ) ? $data['num'] : 0;
	}

	private function SQLLog() {
		global $user;
		
		// stuff insert, update, delete queries into VGOeditor.log table
		if( $_SESSION['modules']['config']['debug'] )
			$this->AddDebugFunction(__FUNCTION__, "Enter");
		
		/*
		 * Logging Stuff goes Here
		 */
		if( $_SESSION['modules']['config']['sql_log'] )
		{
			$pattern[0] = "/".DEV_DB."\./i";
			$replace[0] = "";
			
			$log_query = preg_replace($pattern, $replace, $this->SQLQuery);
			
			// can't use RunQuery because we're getting the wrong LastInsertID!
			$log_insert = sprintf("INSERT INTO log (user_id, username, table_name, object_id, update_query, update_date) VALUES ('%s','%s','%s','%s','%s','%s')",
								$data->user['user_id'],
								$this->SQLEscape($data->user['username']),
								$this->SQLEscape($this->TableName),
								$this->SQLEscape($this->ObjectID),
								$this->SQLEscape($log_query),
								time());
			
			if( !$result = $this->db->sql_query($log_insert) )
				$this->DBError();
		}

		/*
		 * File Logging
		 */
		// 2016.10.23 - this needs to be refactored for portal apps
		if( $_SESSION['modules']['config']['sql_log_file'] )
		{
			$logfile = sprintf("logs/session_%s_%s_week%s.txt", 
												 strtolower($_SESSION['modules']['user']['username']), 
												 date("Y", time()), 
												 date("W", time()));

			$log_query .= "\n";
			
			if( $_SESSION['modules']['config']['readonly'] )
				$this->AddStatus("READ-ONLY MODE - ".$logfile." not saved!");
			else
			{
				if( file_exists($logfile) ) 
				{
					if( !$f = fopen($logfile, 'a') ) 
						die("Cannot open existing filename: $logfile");
		
					if( !fwrite($f, $log_query) )
						die("Cannot write to existing filename: $logfile");
		
					fclose($f);
				} 
				else 
				{
					if( !$f = fopen($logfile, 'x') ) 
						die("Cannot create new file: $logfile");
						
					if( !fwrite($f, $log_query) )
							die("Cannot write to new filename: $logfile");
							
					fclose($f);
				}
			}
			
		}

		if( $_SESSION['modules']['config']['debug'] )
			$this->AddDebugFunction(__FUNCTION__, "Exit");
	}

	public function SQLEscape($str) {
		return $this->db->sql_escape($str);
	}


	public function NoResults()
	{
		print("No Results in " . __FUNCTION__ . ", " . __LINE__);
	}

	
	// Builds an array of enums for a field
	public function GetEnum($database, $table, $field) {
		$this->SQLQuery = "SHOW COLUMNS FROM `$database`.`$table` LIKE '$field'";
		$row = $this->RunQuerySingle();
		$options = explode("','", preg_replace("/.*\('(.*)'\)/","$1", $row['Type']));
		foreach ($options as $value)
			$enum_list[] = $value; // $enum_list[] = array('value' => $value, 'display' => htmlentities($value));
		return $enum_list;
	}
	

	public function GetMaxPK($table, $field) {
		$this->SQLQuery = sprintf("SELECT MAX(%s) AS max_id FROM " . PORTAL_DATABASE . ".%s", $field, $table);
		$data = $this->RunQuerySingle();
		return $data['max_id'];
	}
	
	
	/*
		Function: FormatString()
		Purpose	: Strings with special HTML characters can be parsed and reformatted here for proper display
		Params	: $val = the db data to parse
	*/
	public function FormatString($val)
	{
		$ret = '';
		
		$pattern[0] = "/\</i";
		$pattern[1] = "/\>/i";
		
		$replace[0] = "&lt;";
		$replace[1] = "&gt;";
		
		$ret = preg_replace($pattern, $replace, $val);
		
		return $ret;
	}
	

	/****************************************************************************
	 * Common Functions
	 ****************************************************************************/
	
	/*
		Function: GetAssigned
		Purpose	: 
	*/
	public function GetAssignee() {
		$this->SQLQuery = sprintf("SELECT DISTINCT u.username " .
									"FROM " . $this->PHPBBTablePrefix. "users u, " . $this->PHPBBTablePrefix . "user_group ug, " . $this->PHPBBTablePrefix . "groups g " .
									"WHERE " .
									"	u.user_id = ug.user_id AND " .
									"	ug.group_id = g.group_id AND " .
									"	group_name IN ('Team Members') " .
									"ORDER BY u.username");
		$results = $this->RunQueryMulti();
		$ret = array('Unassigned','Me','Previous Developers','Alpha Testers','Beta Testers','Team Members','Developers');
		foreach( $results as $data )
			$ret[] = $data['username'];
		return $ret;
	}
	
	
	/*
		Function: GetAssigned
		Purpose	: 
	*/
	public function GetAssigneeIDList() {
		$this->SQLQuery = sprintf("SELECT DISTINCT u.user_id, u.username " .
									"FROM " . $this->PHPBBTablePrefix. "users u, " . $this->PHPBBTablePrefix . "user_group ug, " . $this->PHPBBTablePrefix . "groups g " .
									"WHERE " .
									"	u.user_id = ug.user_id AND " .
									"	ug.group_id = g.group_id AND " .
									"	group_name IN ('Team Members') " .
									"ORDER BY u.username");
		$results = $this->RunQueryMulti();
		foreach( $results as $data )
			$ret[$data['user_id']] = $data['username'];
		return $ret;
	}
	
	
	public function NotImplemented() {
		print("This feature is not yet implemented.");
	}
	
} // END Class

} // END Define
?>